#!/usr/bin/env python3
"""Kisama Agent controller.

This single-file controller handles ECDSA request signing, ECIES response
 decryption, AES-GCM request encryption, raw file transfer, and the Noise
 terminal protocol. It is intentionally dependency-light and exposes both a
Python API and a CLI for AI-driven control tasks.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import email.utils
import hashlib
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Optional

try:
    from Crypto.Cipher import AES
    from Crypto.Random import get_random_bytes
    from ecdsa import SigningKey
    from ecdsa.util import sigencode_der
    from ecies import decrypt as ecies_decrypt
    import coincurve
    from noise.connection import Keypair, NoiseConnection
    import websockets
except ImportError as exc:
    raise SystemExit(
        "缺少控制端依赖。请安装："
        "python -m pip install ecdsa eciespy coincurve pycryptodome noiseprotocol websockets"
    ) from exc


class KisamaError(RuntimeError):
    pass


# 匿名时钟探测用浏览器 UA，避免被前置 CDN 拦截
_CLOCK_PROBE_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"


class KisamaClient:
    """Authenticated Kisama HTTP client with in-memory session state."""

    def __init__(
        self,
        base_url: str,
        ecdsa_key: str,
        ecies_key: str,
        timeout: float = 30.0,
        session_cache: Optional[str] = None,
        clock_offset: Optional[float] = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.ecdsa = self._load_ecdsa_key(ecdsa_key)
        self.ecies = self._load_ecies_key(ecies_key)
        self.session_key_b64: Optional[str] = None
        self.session_key: Optional[bytes] = None
        self.noise_key: Optional[dict[str, Any]] = None
        self.baseinfo_data: Optional[dict[str, Any]] = None
        self.session_cache = session_cache or os.environ.get("KISAMA_SESSION_CACHE")
        self._cache_state = "none"  # "none" | "loaded" | "fresh"
        if self.session_cache:
            self._load_cache()
        # 时钟同步: 显式 offset 优先; 否则首次签名前自动探测服务器时间
        self._clock_offset = float(clock_offset) if clock_offset is not None else None
        self._clock_synced = False

    def _auth_timestamp(self) -> str:
        if self._clock_offset is None or not self._clock_synced:
            self._sync_clock()
        return str(int(time.time() + (self._clock_offset or 0.0)))

    def _sync_clock(self) -> None:
        """从服务器 Date 头读取时间偏移, 保证签名时间戳在认证窗口内."""
        if self._clock_offset is not None and self._clock_synced:
            return
        try:
            req = urllib.request.Request(
                f"{self.base_url}/api/baseinfo",
                headers={"Accept": "application/json", "User-Agent": _CLOCK_PROBE_UA},
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                date_str = resp.headers.get("Date", "")
            if date_str:
                # email.utils.parsedate_to_datetime 与 locale 无关 (strptime 的
                # %a/%b 在非英文 Windows 上可能解析失败)
                parsed = email.utils.parsedate_to_datetime(date_str)
                server_ts = parsed.timestamp()
                if self._clock_offset is None:
                    self._clock_offset = float(server_ts - int(time.time()))
        except Exception:
            if self._clock_offset is None:
                self._clock_offset = 0.0
        self._clock_synced = True

    @staticmethod
    def _read_secret(value: str) -> str:
        path = Path(value).expanduser()
        if path.is_file():
            return path.read_text(encoding="utf-8").strip()
        return value.strip()

    @classmethod
    def _load_ecdsa_key(cls, value: str) -> SigningKey:
        raw = cls._read_secret(value)
        try:
            return SigningKey.from_pem(raw)
        except Exception:
            try:
                compact = "".join(
                    line.strip()
                    for line in raw.splitlines()
                    if not line.strip().startswith("-----")
                )
                der = base64.b64decode(compact, validate=True)
                try:
                    return SigningKey.from_der(der)
                except Exception:
                    if len(der) >= 3 and der[:2] == b"\x30\x81":
                        declared = der[2]
                        actual = len(der) - 3
                        if declared != actual and actual <= 255:
                            repaired = der[:2] + bytes([actual]) + der[3:]
                            return SigningKey.from_der(repaired)
                    raise
            except Exception as exc:
                raise KisamaError(f"无法加载 ECDSA 私钥: {value}") from exc

    @classmethod
    def _load_ecies_key(cls, value: str) -> coincurve.PrivateKey:
        raw = cls._read_secret(value)
        compact = re.sub(r"^0x", "", raw, flags=re.IGNORECASE).strip()
        if re.fullmatch(r"[0-9a-fA-F]{64}", compact):
            try:
                return coincurve.PrivateKey(bytes.fromhex(compact))
            except Exception as exc:
                raise KisamaError("无法加载 ECIES 私钥：无效的 64 位 hex 私钥") from exc
        b64 = re.sub(r"\s+", "", compact)
        b64 += "=" * (-len(b64) % 4)
        try:
            decoded = base64.b64decode(b64, validate=True)
            if len(decoded) != 32:
                raise ValueError("长度不为 32 字节")
            return coincurve.PrivateKey(decoded)
        except Exception as exc:
            raise KisamaError("无法加载 ECIES 私钥：需要 64 位 hex 或 Base64(32字节) 私钥") from exc

    def _auth_headers(self) -> dict[str, str]:
        nonce = base64.b64encode(os.urandom(16)).decode("ascii")
        timestamp = self._auth_timestamp()
        signature = self.ecdsa.sign(
            f"{nonce}{timestamp}".encode("utf-8"),
            hashfunc=hashlib.sha256,
            sigencode=sigencode_der,
        )
        return {
            "X-Nonce": nonce,
            "X-Timestamp": timestamp,
            "X-Auth-Token": base64.b64encode(signature).decode("ascii"),
            "Accept": "application/json",
            "User-Agent": "KisamaPythonController/1.0",
        }

    @staticmethod
    def _aes_encrypt(plain: bytes, key: bytes) -> bytes:
        cipher = AES.new(key, AES.MODE_GCM, nonce=get_random_bytes(12))
        ciphertext, tag = cipher.encrypt_and_digest(plain)
        payload = {
            "nonce": base64.b64encode(cipher.nonce).decode("ascii"),
            "tag": base64.b64encode(tag).decode("ascii"),
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
        }
        return base64.b64encode(
            json.dumps(payload, separators=(",", ":")).encode("utf-8")
        )

    def _decode_response(self, body: bytes, headers: Any, status: int) -> Any:
        encrypted = str(headers.get("X-Encrypted", "")).lower() == "true"
        content_type = str(headers.get("Content-Type", "")).lower()

        if status >= 400:
            message = body.decode("utf-8", errors="replace")[:1000]
            encrypted = encrypted or (body.startswith(b"{") and b"_encrypted" in body[:256])
            attempts = [body.strip()]
            if body.startswith(b"{"):
                try:
                    attempts.append(json.loads(body).get("_encrypted", "").strip().encode())
                except Exception:
                    pass
            for candidate in attempts:
                if not candidate:
                    continue
                try:
                    decrypted = ecies_decrypt(self.ecies.secret, base64.b64decode(candidate))
                    if not decrypted or decrypted.startswith(b"{"):
                        try:
                            inner = json.loads(decrypted).get("_encrypted")
                        except Exception:
                            inner = None
                        if inner:
                            message = ecies_decrypt(self.ecies.secret, base64.b64decode(inner)).decode("utf-8", errors="replace")[:1000]
                            break
                    message = decrypted.decode("utf-8", errors="replace")[:1000]
                    break
                except Exception:
                    continue
            raise KisamaError(f"HTTP {status}: {message}")

        if "application/octet-stream" in content_type:
            return body

        if encrypted:
            try:
                body = ecies_decrypt(self.ecies.secret, base64.b64decode(body.strip()))
            except Exception as exc:
                raise KisamaError("ECIES 响应解密失败；请确认代理版本和控制端 ECIES 私钥匹配") from exc

        if not body:
            return None
        try:
            return json.loads(body.decode("utf-8"))
        except Exception:
            return {"raw": body.decode("utf-8", errors="replace")}

    def _http(
        self,
        method: str,
        path: str,
        body: Optional[bytes],
        headers: dict[str, str],
        timeout: Optional[float] = None,
    ) -> tuple[Any, Any, int]:
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=body,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout) as response:
                raw = response.read()
                return self._decode_response(raw, response.headers, response.status), response.headers, response.status
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            return self._decode_response(raw, exc.headers, exc.code), exc.headers, exc.code
        except urllib.error.URLError as exc:
            raise KisamaError(f"无法连接 Kisama 代理: {exc.reason}") from exc

    def _load_cache(self) -> None:
        """从缓存文件恢复 session_key/noise_key (代理重启后失效, 由调用方重试刷新)"""
        try:
            data = json.loads(Path(self.session_cache).expanduser().read_text(encoding="utf-8"))
            session_key_b64 = data.get("session_key")
            noise_key = data.get("noise_key")
            if not session_key_b64 or not isinstance(noise_key, dict):
                raise ValueError("缓存缺少 session_key/noise_key")
            session_key = base64.b64decode(session_key_b64, validate=True)
            if len(session_key) != 32:
                raise ValueError("session_key 长度错误")
            self.session_key_b64 = session_key_b64
            self.session_key = session_key
            self.noise_key = noise_key
            self.baseinfo_data = data.get("baseinfo")
            self._cache_state = "loaded"
        except Exception:
            self._cache_state = "none"

    def save_cache(self) -> None:
        if not self.session_cache or self.session_key_b64 is None or self.noise_key is None:
            return
        path = Path(self.session_cache).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "session_key": self.session_key_b64,
                    "noise_key": self.noise_key,
                    "baseinfo": self.baseinfo_data,
                },
                ensure_ascii=False,
                separators=(",", ":"),
            ),
            encoding="utf-8",
        )
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass

    def _dynamic_timeout(self, size: int, base: Optional[float] = None) -> float:
        """按传输字节数放宽超时: 慢链路下小超时不再卡死大文件传输"""
        rate = 256 * 1024  # 保守 256KB/s
        return max(base or self.timeout, size / rate + 15)

    def bootstrap(self) -> dict[str, Any]:
        """Refresh session_key and noise_key from an authenticated baseinfo call."""
        headers = self._auth_headers()
        data, _, _ = self._http("GET", "/api/baseinfo", None, headers)
        if not isinstance(data, dict):
            raise KisamaError("/api/baseinfo 没有返回 JSON 对象")

        session_key_b64 = data.get("session_key")
        noise_key = data.get("noise_key")
        if not session_key_b64 or not isinstance(noise_key, dict):
            raise KisamaError("baseinfo 未返回 session_key/noise_key；请确认请求使用了正确的 ECDSA 私钥")
        try:
            session_key = base64.b64decode(session_key_b64, validate=True)
        except Exception as exc:
            raise KisamaError("baseinfo 的 session_key 不是有效 Base64") from exc
        if len(session_key) != 32:
            raise KisamaError(f"baseinfo 的 session_key 长度错误：{len(session_key)}，应为 32 字节")

        controller = noise_key.get("controller") or {}
        agent = noise_key.get("agent") or {}
        if not controller.get("private") or not agent.get("public"):
            raise KisamaError("baseinfo 的 noise_key 缺少 controller.private 或 agent.public")

        self.session_key_b64 = session_key_b64
        self.session_key = session_key
        self.noise_key = noise_key
        self.baseinfo_data = data
        self._cache_state = "fresh"
        self.save_cache()
        return data

    def _ensure_session(self) -> None:
        if self.session_key is None or self.noise_key is None:
            self.bootstrap()

    def request_json(self, method: str, path: str, payload: Any = None) -> Any:
        self._ensure_session()
        headers = self._auth_headers()
        headers["Content-Type"] = "application/json"
        body = None
        if payload is not None:
            body = self._aes_encrypt(
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                self.session_key,
            )
            headers["X-AES-Encrypted"] = "true"
        data, _, _ = self._http(method, path, body, headers)
        return data

    def request_binary(self, method: str, path: str, payload: Any = None, timeout: Optional[float] = None) -> bytes:
        self._ensure_session()
        headers = self._auth_headers()
        headers["Content-Type"] = "application/json"
        body = None
        if payload is not None:
            body = self._aes_encrypt(
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                self.session_key,
            )
            headers["X-AES-Encrypted"] = "true"
        data, _, _ = self._http(method, path, body, headers, timeout=timeout)
        if not isinstance(data, bytes):
            raise KisamaError(f"接口没有返回二进制内容: {data}")
        return data

    def upload(self, local_file: str, remote_path: str, remote_name: Optional[str] = None, chunk_size: int = 8 * 1024 * 1024, timeout: Optional[float] = None) -> dict[str, Any]:
        source = Path(local_file).expanduser()
        if not source.is_file():
            raise KisamaError(f"本地文件不存在: {source}")
        remote_name = remote_name or source.name
        total_size = source.stat().st_size
        total_chunks = max(1, (total_size + chunk_size - 1) // chunk_size)
        chunk_timeout = timeout or self._dynamic_timeout(chunk_size)
        result: dict[str, Any] = {}

        with source.open("rb") as handle:
            for chunk_id in range(total_chunks):
                chunk = handle.read(chunk_size)
                if not chunk and total_size != 0:
                    raise KisamaError(f"读取本地文件时分片 {chunk_id} 为空")
                headers = self._auth_headers()
                headers.update({
                    "Accept": "application/json",
                    "Content-Type": "application/octet-stream",
                    "X-File-Path": urllib.parse.quote(remote_path, safe="/"),
                    "X-File-Name": urllib.parse.quote(remote_name, safe=""),
                    "X-Chunk-Id": str(chunk_id),
                    "X-Total-Chunks": str(total_chunks),
                })
                data, _, _ = self._http("POST", "/api/fileraw", chunk, headers, timeout=chunk_timeout)
                if not isinstance(data, dict):
                    raise KisamaError(f"上传分片 {chunk_id} 返回格式错误")
                result = data
        return result

    def download(self, remote_path: str, local_file: str, timeout: Optional[float] = None) -> dict[str, Any]:
        data = self.request_binary("POST", "/api/file/download", {"path": remote_path}, timeout=timeout or self._dynamic_timeout(64 * 1024 * 1024))
        destination = Path(local_file).expanduser()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        return {"status": "ok", "path": str(destination), "size": len(data)}

    async def terminal(
        self,
        command: Optional[str] = None,
        raw_input: Optional[str] = None,
        request_id: Optional[str] = None,
        token: Optional[str] = None,
        rows: int = 24,
        cols: int = 80,
        timeout: float = 60.0,
    ) -> dict[str, Any]:
        self._ensure_session()
        request_id = request_id or f"kisama-{uuid.uuid4().hex}"
        query = {"request_id": request_id}
        if token:
            query["token"] = token
        scheme = "wss" if self.base_url.startswith("https://") else "ws"
        host_url = self.base_url.replace("https://", f"{scheme}://", 1).replace("http://", f"{scheme}://", 1)
        ws_url = f"{host_url}/api/ws/terminal?{urllib.parse.urlencode(query)}"

        async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10, max_size=2**22) as websocket:
            cipher: Optional[NoiseConnection] = None
            if not token:
                controller_private = base64.b64decode(self.noise_key["controller"]["private"])
                expected_agent_public = base64.b64decode(self.noise_key["agent"]["public"])
                cipher = NoiseConnection.from_name(b"Noise_XX_25519_ChaChaPoly_BLAKE2s")
                cipher.set_as_initiator()
                cipher.set_keypair_from_private_bytes(Keypair.STATIC, controller_private)
                cipher.set_prologue(b"kisama_terminal_v1")
                cipher.start_handshake()
                await websocket.send(cipher.write_message(b""))
                msg2 = await websocket.recv()
                cipher.read_message(msg2 if isinstance(msg2, bytes) else msg2.encode())
                try:
                    remote_public = cipher.noise_protocol.handshake_state.rs.public_bytes
                except AttributeError as exc:
                    raise KisamaError("Noise 库无法读取代理静态公钥，拒绝继续") from exc
                if remote_public != expected_agent_public:
                    raise KisamaError("Noise 握手中代理静态公钥不匹配")
                await websocket.send(cipher.write_message(b""))
                if not cipher.handshake_finished:
                    raise KisamaError("Noise 握手未完成")

            async def send_payload(payload: bytes) -> None:
                await websocket.send(cipher.encrypt(payload) if cipher else payload)

            async def heartbeat() -> None:
                while True:
                    await asyncio.sleep(10)
                    await send_payload(b'{"type":"heartbeat"}')

            heartbeat_task = asyncio.create_task(heartbeat())
            try:
                marker = f"__KISAMA_DONE__{uuid.uuid4().hex}"
                if command is not None:
                    command_payload = (
                        f"{command}\n"
                        f"printf '\\n{marker}:%s__\\n' \"$?\"\n"
                    ).encode("utf-8")
                    payload = {
                        "type": "input",
                        "data": base64.b64encode(command_payload).decode("ascii"),
                        "encoding": "base64",
                    }
                    await send_payload(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
                    pattern = re.compile(rb"\n" + re.escape(marker.encode()) + rb":(\d+)__\r?\n")
                elif raw_input is not None:
                    await send_payload(raw_input.encode("utf-8"))
                    pattern = None
                else:
                    raise KisamaError("terminal 必须提供 command 或 raw_input")

                await send_payload(json.dumps({"type": "resize", "rows": rows, "cols": cols}, separators=(",", ":")).encode("utf-8"))
                output = bytearray()
                exitcode: Optional[int] = None
                started = time.monotonic()
                while time.monotonic() - started < timeout:
                    remaining = max(0.1, timeout - (time.monotonic() - started))
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=remaining)
                    except asyncio.TimeoutError:
                        break
                    if isinstance(message, str):
                        message = message.encode("utf-8")
                    plain = cipher.decrypt(message) if cipher else message
                    try:
                        obj = json.loads(plain.decode("utf-8"))
                        if obj.get("type") == "heartbeat":
                            continue
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        pass
                    output.extend(plain)
                    if pattern:
                        match = pattern.search(output)
                        if match:
                            exitcode = int(match.group(1))
                            output = output[:match.start()]
                            break
                text = output.decode("utf-8", errors="replace")
                return {
                    "status": "ok" if (pattern is None or exitcode is not None) else "timeout",
                    "request_id": request_id,
                    "output": text,
                    "exitcode": exitcode,
                }
            finally:
                heartbeat_task.cancel()
                try:
                    await heartbeat_task
                except asyncio.CancelledError:
                    pass


def parse_pairs(values: list[str], label: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise KisamaError(f"{label} 参数必须是 key=value: {value}")
        key, val = value.split("=", 1)
        if not key:
            raise KisamaError(f"{label} 的 key 不能为空")
        result[key] = val
    return result


def output(value: Any, pretty: bool = False) -> None:
    if isinstance(value, bytes):
        sys.stdout.buffer.write(value)
        return
    print(json.dumps(value, ensure_ascii=False, indent=2 if pretty else None, default=str))


def _ensure_utf8_stdio() -> None:
    """Windows 控制台默认编码可能是 GBK/cp1252, 打印中文 JSON 会抛
    UnicodeEncodeError（Linux/macOS 默认 UTF-8 无此问题）。这里强制 UTF-8。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="使用 Kisama Python 控制端连接并操作代理")
    parser.add_argument("--url", default=os.getenv("KISAMA_URL"), help="代理地址，例如 http://127.0.0.1:8000")
    parser.add_argument("--ecdsa-key", default=os.getenv("KISAMA_ECDSA_KEY"), help="控制端 ECDSA 私钥文件或 PEM 内容")
    parser.add_argument("--ecies-key", default=os.getenv("KISAMA_ECIES_KEY"), help="控制端 ECIES 私钥文件、64 位 hex 或 Base64(32字节)")
    parser.add_argument("--timeout", type=float, default=30.0, help="每次 HTTP 请求超时(秒), 上传/下载大文件自动放宽")
    parser.add_argument("--session-cache", default=os.getenv("KISAMA_SESSION_CACHE"), help="会话缓存文件(JSON), 复用 session_key/noise_key, 免每次重复 baseinfo")
    parser.add_argument("--pretty", action="store_true")
    parser.add_argument("--clock-offset", type=float, default=None, help="签名时间戳偏移(秒), 默认自动从服务器 Date 头探测")
    sub = parser.add_subparsers(dest="action", required=True)

    sub.add_parser("baseinfo", help="获取代理信息并刷新 session_key/noise_key")

    command = sub.add_parser("exec", help="执行一次非交互式命令")
    command.add_argument("--cmd", required=True)
    command.add_argument("--cwd")
    command.add_argument("--env", action="append", default=[], metavar="KEY=VALUE")

    listing = sub.add_parser("list", help="列出远端文件")
    listing.add_argument("--path", default=".")
    listing.add_argument("--recursive", action="store_true")

    cat = sub.add_parser("cat", help="读取远端文件")
    cat.add_argument("--path", required=True)

    authority_get = sub.add_parser("authority-get", help="查询远端权限")
    authority_get.add_argument("paths", nargs="+")

    authority_set = sub.add_parser("authority-set", help="设置远端权限")
    authority_set.add_argument("permissions", nargs="+", metavar="PATH=MODE")
    authority_set.add_argument("--recursive", action="store_true")

    mkdir = sub.add_parser("mkdir", help="创建远端目录")
    mkdir.add_argument("--path", required=True)

    move = sub.add_parser("move", help="移动或重命名远端文件")
    move.add_argument("mapping", nargs="+", metavar="FROM=TO")

    copy = sub.add_parser("copy", help="复制远端文件")
    copy.add_argument("mapping", nargs="+", metavar="FROM=TO")

    delete = sub.add_parser("delete", help="删除远端文件或目录")
    delete.add_argument("paths", nargs="+")

    upload = sub.add_parser("upload", help="上传本地文件到远端，自动使用裸二进制分片")
    upload.add_argument("--local", required=True)
    upload.add_argument("--remote-path", required=True)
    upload.add_argument("--name")
    upload.add_argument("--chunk-size", type=int, default=8 * 1024 * 1024)

    download = sub.add_parser("download", help="下载远端文件到本地")
    download.add_argument("--remote-path", required=True)
    download.add_argument("--local", required=True)

    terminal = sub.add_parser("terminal", help="通过 Noise 超级终端执行命令")
    group = terminal.add_mutually_exclusive_group(required=True)
    group.add_argument("--command")
    group.add_argument("--input")
    terminal.add_argument("--request-id")
    terminal.add_argument("--token")
    terminal.add_argument("--rows", type=int, default=24)
    terminal.add_argument("--cols", type=int, default=80)
    terminal.add_argument("--terminal-timeout", type=float, default=60.0)
    return parser


def require_options(args: argparse.Namespace) -> None:
    missing = [name for name in ("url", "ecdsa_key", "ecies_key") if not getattr(args, name)]
    if missing:
        raise KisamaError("缺少连接参数: " + ", ".join(missing) + "。可用命令行参数或 KISAMA_URL/KISAMA_ECDSA_KEY/KISAMA_ECIES_KEY 环境变量")


async def run(args: argparse.Namespace) -> Any:
    require_options(args)
    client = KisamaClient(args.url, args.ecdsa_key, args.ecies_key, args.timeout, args.session_cache, args.clock_offset)
    try:
        return await dispatch(client, args)
    except KisamaError as exc:
        if client._cache_state == "loaded":
            client._cache_state = "none"
            client.session_key_b64 = None
            client.session_key = None
            client.noise_key = None
            return await dispatch(client, args)
        raise


async def dispatch(client: KisamaClient, args: argparse.Namespace) -> Any:
    if args.action == "baseinfo":
        data = client.bootstrap()
        if isinstance(data, dict):
            return {
                k: ("***masked***" if k in ("session_key", "noise_key") else v)
                for k, v in data.items()
            }
        return data
    if args.action == "exec":
        return client.request_json("POST", "/api/exec", {"cmd": args.cmd, **({"cwd": args.cwd} if args.cwd else {}), **({"env": parse_pairs(args.env, "env")} if args.env else {})})
    if args.action == "list":
        return client.request_json("POST", "/api/file/list", {"path": args.path, "recursive": args.recursive})
    if args.action == "cat":
        return client.request_json("POST", "/api/file/cat", {"path": args.path})
    if args.action == "authority-get":
        return client.request_json("POST", "/api/file/authority", {"paths": args.paths})
    if args.action == "authority-set":
        return client.request_json("PUT", "/api/file/authority", {"permissions": parse_pairs(args.permissions, "permissions"), "recursive": args.recursive})
    if args.action == "mkdir":
        return client.request_json("POST", "/api/file/new", {"path": args.path})
    if args.action == "move":
        return client.request_json("PUT", "/api/file", parse_pairs(args.mapping, "mapping"))
    if args.action == "copy":
        return client.request_json("POST", "/api/file/cp", parse_pairs(args.mapping, "mapping"))
    if args.action == "delete":
        return client.request_json("DELETE", "/api/file", {"paths": args.paths})
    if args.action == "upload":
        return client.upload(args.local, args.remote_path, args.name, args.chunk_size)
    if args.action == "download":
        return client.download(args.remote_path, args.local)
    if args.action == "terminal":
        return await client.terminal(args.command, args.input, args.request_id, args.token, args.rows, args.cols, args.terminal_timeout)
    raise KisamaError(f"未知操作: {args.action}")


def main() -> int:
    _ensure_utf8_stdio()
    parser = build_parser()
    args = parser.parse_args()
    try:
        result = asyncio.run(run(args))
        output(result, args.pretty)
        return 0
    except KeyboardInterrupt:
        return 130
    except KisamaError as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    except Exception as exc:
        print(json.dumps({"status": "error", "message": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
