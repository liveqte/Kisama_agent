#!/usr/bin/env python3
"""Kisama Agent controller.

This single-file controller handles ECDSA request signing, ECIES response
 decryption, AES-GCM request encryption, raw file transfer, and the Noise
 terminal protocol. It is intentionally dependency-light and exposes both a
Python API and a CLI for AI-driven control tasks.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import email.utils
import hashlib
import hmac
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Optional

# 核心依赖: ecdsa(纯Python)/cryptography(abi3 wheel)/noise/websockets —— 任意 CPython 含 3.14 免编译可装
try:
    from ecdsa import NIST256p, SigningKey
    from ecdsa.util import sigencode_der
    from noise.connection import Keypair, NoiseConnection
    import websockets
except ImportError as exc:
    raise SystemExit(
        "缺少控制端依赖。请安装："
        "python -m pip install ecdsa cryptography noiseprotocol websockets"
    ) from exc

# ============================================================================
# 原生加密库兼容层: coincurve/eciespy/pycryptodome 优先 (libsecp256k1 快),
# 缺失时 (如 Python 3.14 无 wheel、无编译工具链) 自动回退
# ecdsa(纯Python secp256k1 点运算) + cryptography(abi3 wheel AES-GCM)。
# 回退实现与 eciespy 线上格式逐字节兼容: eph_pub(65) + nonce(16) + tag(16) + ct
# ============================================================================
try:
    from ecies import decrypt as ecies_decrypt
except Exception:
    ecies_decrypt = None

try:
    import coincurve as _coincurve
except Exception:
    _coincurve = None

try:
    from Crypto.Cipher import AES  # noqa: F401  (原生优先, 缺失时下方垫片接管)
    from Crypto.Random import get_random_bytes as _native_random
    get_random_bytes = _native_random
except Exception:
    def get_random_bytes(n: int) -> bytes:
        return os.urandom(n)

    class _AESGCMCipherShim:
        def __init__(self, key: bytes, nonce: bytes):
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            self._aesgcm = AESGCM(key)
            self.nonce = nonce

        def encrypt_and_digest(self, plaintext: bytes):
            sealed = self._aesgcm.encrypt(self.nonce, plaintext, None)  # ct||tag
            return sealed[:-16], sealed[-16:]

        def decrypt_and_verify(self, ciphertext: bytes, tag: bytes) -> bytes:
            return self._aesgcm.decrypt(self.nonce, ciphertext + tag, None)

    class AES:
        MODE_GCM = "gcm"

        @staticmethod
        def new(key: bytes, mode, nonce: bytes = None):
            if nonce is None:
                raise ValueError("兼容垫片仅支持 AES-GCM 且必须提供 nonce")
            return _AESGCMCipherShim(key, nonce)

if ecies_decrypt is None:
    import hmac as _hmac_mod
    import hashlib as _hashlib_mod

    _SECP_P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F

    def _secp_decompress_pub(pub: bytes):
        from ecdsa import SECP256k1, VerifyingKey
        from ecdsa.ellipticcurve import Point
        if len(pub) == 65 and pub[0] == 0x04:
            return VerifyingKey.from_string(pub[1:], curve=SECP256k1).pubkey.point
        if len(pub) == 33 and pub[0] in (0x02, 0x03):
            x = int.from_bytes(pub[1:], "big")
            y_sq = (pow(x, 3, _SECP_P) + 7) % _SECP_P
            y = pow(y_sq, (_SECP_P + 1) // 4, _SECP_P)
            if y * y % _SECP_P != y_sq:
                raise ValueError("invalid compressed public key")
            if (y & 1) != (pub[0] - 0x02):
                y = _SECP_P - y
            return Point(SECP256k1.curve, x, y)
        raise ValueError("unsupported public key format")

    def _hkdf_sha256(master: bytes, length: int = 32) -> bytes:
        # 与 pycryptodome HKDF(master, len, salt=b"", SHA256) 一致 (info=空)
        prk = _hmac_mod.new(b"", master, _hashlib_mod.sha256).digest()
        okm = b""
        block = b""
        counter = 1
        while len(okm) < length:
            block = _hmac_mod.new(prk, block + bytes([counter]), _hashlib_mod.sha256).digest()
            okm += block
            counter += 1
        return okm[:length]

    def _secp_point_bytes(point) -> bytes:
        return b"\x04" + point.x().to_bytes(32, "big") + point.y().to_bytes(32, "big")

    def ecies_decrypt(secret: bytes, payload: bytes) -> bytes:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        if len(payload) < 97:
            raise ValueError("密文长度不合法")
        eph_pub, nonce, tag, ct = payload[:65], payload[65:81], payload[81:97], payload[97:]
        shared = _secp_point_bytes(_secp_decompress_pub(eph_pub) * int.from_bytes(secret, "big"))
        key = _hkdf_sha256(eph_pub + shared)
        return AESGCM(key).decrypt(nonce, ct + tag, None)


class _EciesKeyShim:
    """coincurve.PrivateKey 的最小兼容 (.secret)"""

    def __init__(self, secret: bytes):
        if len(secret) != 32:
            raise ValueError("ECIES 私钥必须为 32 字节")
        self.secret = secret


def _new_ecies_key(secret: bytes):
    """coincurve 优先, 缺失时回退垫片 (仅 .secret 属性)"""
    if _coincurve is not None:
        return _coincurve.PrivateKey(secret)
    return _EciesKeyShim(secret)


class KisamaError(RuntimeError):
    pass


# 匿名时钟探测用浏览器 UA，避免被前置 CDN 拦截
_CLOCK_PROBE_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"


class KisamaClient:
    """Authenticated Kisama HTTP client with in-memory session state."""

    def __init__(
        self,
        base_url: str,
        ecdsa_key: str,
        ecies_key: str,
        timeout: float = 30.0,
        session_cache: Optional[str] = None,
        clock_offset: Optional[float] = None,
    ) -> None:
        # 支持 "scheme://网关主机[:端口]#目标主机[/路径前缀]" 格式:
        # "#" 后的目标主机放入 X-Target-Host 头由网关路由, 路径前缀拼在所有请求路径之前
        self.target_host: Optional[str] = None
        self.path_prefix: str = ""
        if "#" in base_url:
            front, _, target = base_url.partition("#")
            target = target.strip("/")
            host, _, prefix = target.partition("/")
            if host:
                self.target_host = host
                self.path_prefix = f"/{prefix}" if prefix else ""
            base_url = front
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        # 🔐 密钥改为惰性加载: DEBUG 模式代理 (x-encrypted: false) 无需密钥即可通信,
        # 启动阶段不得因缺钥/密钥无效而拦截 (否则连 baseinfo 探测都发不出去, 永远
        # 察觉不了对端是 DEBUG)。生产模式首次签名/解密时才加载并报错。
        self._ecdsa_raw = ecdsa_key
        self._ecies_raw = ecies_key
        self.ecdsa: Optional[SigningKey] = None
        self.ecies = None
        self._ecdsa_unavailable: bool = False   # 已尝试加载但失败/未提供, 避免重复告警
        self._ecies_unavailable: bool = False
        self.session_key_b64: Optional[str] = None
        self.session_key: Optional[bytes] = None
        self.noise_key: Optional[dict[str, Any]] = None
        self.baseinfo_data: Optional[dict[str, Any]] = None
        # 🔐 0.5.6 协议 (docs/API.MD 十二): 代理版本号 (baseinfo 响应携带)。
        # 版本数字前缀 >= 0.5.6 且非 baseinfo 端点的加密响应为 session_key AES-256-GCM;
        # baseinfo 恒为 ECIES; 版本未知/旧版按 ECIES 处理。
        self.agent_version: Optional[str] = None
        # 🌟 DEBUG 模式 (x-encrypted: false): 认证形同虚设, 所有响应为明文且恒不下发
        # session_key/noise_key (规范见 docs/API.MD 第十节)。明文 HTTP 业务 (exec/list/上传
        # 下载等) 照常可用; terminal 因无 noise_key/session_key 不可用。
        self.debug_mode: bool = False
        self.session_cache = session_cache or os.environ.get("KISAMA_SESSION_CACHE")
        self._cache_state = "none"  # "none" | "loaded" | "fresh"
        # 🔐 0.4.8 签名协议协商: "v2"=0.4.8 五段签名, "v1"=旧版 nonce+timestamp;
        # None=自动 (首次请求按 v2 发送, 401 则回退 v1 并记忆)。KISAMA_SIG_MODE 可强制。
        env_mode = os.environ.get("KISAMA_SIG_MODE", "").strip().lower()
        self._sig_mode_forced: bool = env_mode in ("v1", "v2")
        self._sig_mode: Optional[str] = env_mode if self._sig_mode_forced else None
        if self.session_cache:
            self._load_cache()
        # 时钟同步: 显式 offset 优先; 否则首次签名前自动探测服务器时间
        self._clock_offset = float(clock_offset) if clock_offset is not None else None
        self._clock_synced = False

    def _auth_timestamp(self) -> str:
        if self._clock_offset is None or not self._clock_synced:
            self._sync_clock()
        return str(int(time.time() + (self._clock_offset or 0.0)))

    def _sync_clock(self) -> None:
        """从服务器 Date 头读取时间偏移, 保证签名时间戳在认证窗口内."""
        if self._clock_offset is not None and self._clock_synced:
            return
        try:
            req = urllib.request.Request(
                f"{self.base_url}{self.path_prefix}/api/baseinfo",
                headers={
                    "Accept": "application/json",
                    "User-Agent": _CLOCK_PROBE_UA,
                    **({"X-Target-Host": self.target_host} if self.target_host else {}),
                },
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                date_str = resp.headers.get("Date", "")
            if date_str:
                # email.utils.parsedate_to_datetime 与 locale 无关 (strptime 的
                # %a/%b 在非英文 Windows 上可能解析失败)
                parsed = email.utils.parsedate_to_datetime(date_str)
                server_ts = parsed.timestamp()
                if self._clock_offset is None:
                    self._clock_offset = float(server_ts - int(time.time()))
        except Exception:
            if self._clock_offset is None:
                self._clock_offset = 0.0
        self._clock_synced = True

    @staticmethod
    def _read_secret(value: str) -> str:
        path = Path(value).expanduser()
        if path.is_file():
            return path.read_text(encoding="utf-8").strip()
        return value.strip()

    @classmethod
    def _maybe_ecdsa_scalar(cls, raw: str) -> Optional[SigningKey]:
        """短格式 ECDSA P-256 私钥 (0.5.8 tempkey format=short 下发): 64 位 hex 或
        Base64(32字节) 标量 → SigningKey; 非短格式返回 None, 格式像短格式但标量无效抛 KisamaError。"""
        compact = re.sub(r"\s+", "", raw)
        if re.fullmatch(r"[0-9a-fA-F]{64}", compact):
            try:
                return SigningKey.from_string(bytes.fromhex(compact), curve=NIST256p)
            except Exception as exc:
                raise KisamaError("无效的 64 位 hex ECDSA 私钥标量 (P-256)") from exc
        b64 = compact + "=" * (-len(compact) % 4)
        try:
            decoded = base64.b64decode(b64, validate=True)
        except Exception:
            return None
        if len(decoded) != 32:
            return None
        try:
            return SigningKey.from_string(decoded, curve=NIST256p)
        except Exception as exc:
            raise KisamaError("无效的 Base64(32字节) ECDSA 私钥标量 (P-256)") from exc

    @classmethod
    def _load_ecdsa_key(cls, value: str) -> SigningKey:
        raw = cls._read_secret(value)
        # 0.5.8 短格式优先识别 (tempkey format=short): 64 位 hex / Base64(32字节) 标量
        scalar = cls._maybe_ecdsa_scalar(raw)
        if scalar is not None:
            return scalar
        try:
            return SigningKey.from_pem(raw)
        except Exception:
            try:
                compact = "".join(
                    line.strip()
                    for line in raw.splitlines()
                    if not line.strip().startswith("-----")
                )
                der = base64.b64decode(compact, validate=True)
                try:
                    return SigningKey.from_der(der)
                except Exception:
                    if len(der) >= 3 and der[:2] == b"\x30\x81":
                        declared = der[2]
                        actual = len(der) - 3
                        if declared != actual and actual <= 255:
                            repaired = der[:2] + bytes([actual]) + der[3:]
                            return SigningKey.from_der(repaired)
                    raise
            except Exception as exc:
                raise KisamaError(f"无法加载 ECDSA 私钥: {value}") from exc

    @classmethod
    def _load_ecies_key(cls, value: str):
        raw = cls._read_secret(value)
        compact = re.sub(r"^0x", "", raw, flags=re.IGNORECASE).strip()
        if re.fullmatch(r"[0-9a-fA-F]{64}", compact):
            try:
                return _new_ecies_key(bytes.fromhex(compact))
            except Exception as exc:
                raise KisamaError("无法加载 ECIES 私钥：无效的 64 位 hex 私钥") from exc
        b64 = re.sub(r"\s+", "", compact)
        b64 += "=" * (-len(b64) % 4)
        try:
            decoded = base64.b64decode(b64, validate=True)
            if len(decoded) != 32:
                raise ValueError("长度不为 32 字节")
            return _new_ecies_key(decoded)
        except Exception as exc:
            raise KisamaError("无法加载 ECIES 私钥：需要 64 位 hex 或 Base64(32字节) 私钥") from exc

    def _ensure_ecdsa(self) -> Optional[SigningKey]:
        """惰性加载 ECDSA 私钥。缺钥/密钥无效时返回 None (不签名直发):
        DEBUG 模式代理全信任放行, 照常可用; 生产代理会 401, 属预期报错。"""
        if self.ecdsa is not None:
            return self.ecdsa
        if self._ecdsa_unavailable:
            return None
        raw = (self._ecdsa_raw or "").strip()
        if not raw or raw == "dummy":
            self._ecdsa_unavailable = True
            return None
        try:
            self.ecdsa = self._load_ecdsa_key(raw)
            return self.ecdsa
        except KisamaError:
            print(f"[warn] ECDSA 私钥无法加载 ({self._ecdsa_raw})，请求将不带签名直发（仅 DEBUG 代理可用）", file=sys.stderr)
            self._ecdsa_unavailable = True
            return None

    def _ensure_ecies(self):
        """惰性加载 ECIES 私钥。缺钥/密钥无效时返回 None (不解密, 明文透出):
        DEBUG 模式响应恒为明文, 照常可用; 生产加密响应会按原文解析失败, 属预期。"""
        if self.ecies is not None:
            return self.ecies
        if self._ecies_unavailable:
            return None
        raw = (self._ecies_raw or "").strip()
        if not raw or raw == "dummy" or re.fullmatch(r"0{4,}", raw):
            self._ecies_unavailable = True
            return None
        try:
            self.ecies = self._load_ecies_key(raw)
            return self.ecies
        except KisamaError:
            print(f"[warn] ECIES 私钥无法加载 ({self._ecies_raw})，响应将不解密直读（仅 DEBUG 代理可用）", file=sys.stderr)
            self._ecies_unavailable = True
            return None

    def _auth_headers(
        self, mode: str = "v2", method: str = "", path: str = "", sig_body: bytes = b""
    ) -> dict[str, str]:
        """生成签名请求头 (兼容 0.4.8 新签名与旧版签名).

        v2 (0.4.8+): message = METHOD\\nPATH\\nsha256hex(sig_body)\\nnonce\\ntimestamp
        v1 (0.4.7-): message = nonce + timestamp
        sig_body 为参与签名的请求体字节: AES 加密体签密文, 无体签 sha256(""),
        /api/fileraw 按约定签空体 (大文件不参与签名)。
        ECDSA 私钥缺失/无效时不生成 X-Auth-Token 三件套 (DEBUG 代理免验签直连)。
        """
        sign_key = self._ensure_ecdsa()
        if sign_key is None:
            return {
                "Accept": "application/json",
                "User-Agent": "KisamaPythonController/1.0",
            }
        nonce = base64.b64encode(os.urandom(16)).decode("ascii")
        timestamp = self._auth_timestamp()
        if mode == "v1":
            message = f"{nonce}{timestamp}".encode("utf-8")
        else:
            body_hash = hashlib.sha256(sig_body if sig_body else b"").hexdigest()
            message = f"{method}\n{path}\n{body_hash}\n{nonce}\n{timestamp}".encode("utf-8")
        signature = sign_key.sign(
            message,
            hashfunc=hashlib.sha256,
            sigencode=sigencode_der,
        )
        return {
            "X-Nonce": nonce,
            "X-Timestamp": timestamp,
            "X-Auth-Token": base64.b64encode(signature).decode("ascii"),
            "Accept": "application/json",
            "User-Agent": "KisamaPythonController/1.0",
        }

    def _send_authenticated(self, method: str, path: str, build_fn, timeout: Optional[float] = None):
        """发送带签名的请求, 并在签名协议未知时自动完成 v2/v1 协商.

        首次请求按 v2 发送; 收到 401 时自动回退 v1 重试一次并记忆协商结果,
        之后固定使用该结果 (可用环境变量 KISAMA_SIG_MODE=v1|v2 跳过协商).
        build_fn(mode) -> (data, headers): mode 决定签名格式, data 为实际发送的请求体.
        """
        mode = self._sig_mode or "v2"
        data, headers = build_fn(mode)
        try:
            result = self._http(method, path, data, headers, timeout=timeout)
        except KisamaError as exc:
            if self._sig_mode is None and "HTTP 401" in str(exc):
                self._sig_mode = "v1"
                data, headers = build_fn("v1")
                result = self._http(method, path, data, headers, timeout=timeout)
            else:
                raise
        if self._sig_mode is None:
            self._sig_mode = "v2"
        return result

    def ws_downgrade_token(self) -> str:
        """0.4.8 明文降级模式令牌: Base64(HMAC-SHA256(session_key原始字节, "kisama-ws-token-v1")).

        0.4.8 起终端 WS 的 token 不再接受 agent 公钥; 旧版代理仍使用
        noise_key.agent.public 作为 token (两种写法均保留, 见 terminal 文档).
        """
        if self.session_key is None:
            raise KisamaError("无 session_key 可计算 WS 降级令牌 (DEBUG 代理恒不下发 session_key, 不支持 terminal)")
        return base64.b64encode(
            hmac.new(self.session_key, b"kisama-ws-token-v1", hashlib.sha256).digest()
        ).decode("ascii")

    @staticmethod
    def _aes_encrypt(plain: bytes, key: bytes) -> bytes:
        cipher = AES.new(key, AES.MODE_GCM, nonce=get_random_bytes(12))
        ciphertext, tag = cipher.encrypt_and_digest(plain)
        payload = {
            "nonce": base64.b64encode(cipher.nonce).decode("ascii"),
            "tag": base64.b64encode(tag).decode("ascii"),
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
        }
        return base64.b64encode(
            json.dumps(payload, separators=(",", ":")).encode("utf-8")
        )

    @staticmethod
    def _aes_decrypt(payload_b64: bytes, key: bytes) -> bytes:
        """🔐 0.5.6 响应密文解密: Base64(JSON{nonce, tag, ciphertext}) -> 明文字节
        (与 _aes_encrypt 对称; 代理端 encryptData 输出同容器, docs/API.MD 十二)。"""
        payload = json.loads(base64.b64decode(payload_b64).decode("utf-8"))
        cipher = AES.new(key, AES.MODE_GCM, nonce=base64.b64decode(payload["nonce"]))
        return cipher.decrypt_and_verify(
            base64.b64decode(payload["ciphertext"]),
            base64.b64decode(payload["tag"]),
        )

    @staticmethod
    def _version_tuple(version: Optional[str]):
        """解析版本号数字前缀: "0.5.6-python" -> (0, 5, 6); 无法解析返回 None"""
        if not version:
            return None
        m = re.match(r"(\d+)\.(\d+)\.(\d+)", str(version))
        return tuple(int(g) for g in m.groups()) if m else None

    def _use_aes_response(self, path: str) -> bool:
        """🔐 0.5.6 协议 (docs/API.MD 十二): 代理版本数字前缀 >= 0.5.6 且请求路径非
        /api/baseinfo 时, 加密响应为 session_key AES-256-GCM; baseinfo 恒为 ECIES
        (密钥分发握手, 临时持有者也经它取得 session_key); 版本未知或旧版按 ECIES。"""
        if path.split("?", 1)[0].rstrip("/") == "/api/baseinfo":
            return False
        vt = self._version_tuple(self.agent_version)
        return vt is not None and vt >= (0, 5, 6)

    def _decode_response(self, body: bytes, headers: Any, status: int, path: str = "") -> Any:
        encrypted = str(headers.get("X-Encrypted", "")).lower() == "true"
        # 🌟 DEBUG 模式位 (x-encrypted: false, docs/API.MD 第十节): 响应恒为明文,
        # 不得进入 ECIES 解密分支; 首个响应即可信, 置位后全程按明文处理。
        if str(headers.get("X-Encrypted", "")).lower() == "false":
            self.debug_mode = True
        content_type = str(headers.get("Content-Type", "")).lower()

        if status >= 400:
            message = body.decode("utf-8", errors="replace")[:1000]
            encrypted = encrypted or (body.startswith(b"{") and b"_encrypted" in body[:256])
            ecies_key = self._ensure_ecies()
            attempts = [body.strip()]
            if body.startswith(b"{"):
                try:
                    attempts.append(json.loads(body).get("_encrypted", "").strip().encode())
                except Exception:
                    pass
            # 🔐 0.5.6: 非 baseinfo 的加密错误体优先按 session_key AES 解密 (失败回退 ECIES)
            try_aes_error = self._use_aes_response(path) and self.session_key is not None
            if try_aes_error or ecies_key is not None:
                for candidate in attempts:
                    if not candidate:
                        continue
                    if try_aes_error:
                        try:
                            message = self._aes_decrypt(candidate, self.session_key).decode("utf-8", errors="replace")[:1000]
                            break
                        except Exception:
                            pass
                    if ecies_key is None:
                        continue
                    try:
                        decrypted = ecies_decrypt(self.ecies.secret, base64.b64decode(candidate))
                        if not decrypted or decrypted.startswith(b"{"):
                            try:
                                inner = json.loads(decrypted).get("_encrypted")
                            except Exception:
                                inner = None
                            if inner:
                                message = ecies_decrypt(self.ecies.secret, base64.b64decode(inner)).decode("utf-8", errors="replace")[:1000]
                                break
                        message = decrypted.decode("utf-8", errors="replace")[:1000]
                        break
                    except Exception:
                        continue
            raise KisamaError(f"HTTP {status}: {message}")

        if "application/octet-stream" in content_type:
            return body

        # DEBUG 模式响应为明文 JSON, 直接解析 (与 encrypted=True 分支互斥)
        if encrypted and not self.debug_mode:
            if self._use_aes_response(path):
                # 🔐 0.5.6 (docs/API.MD 十二): 非 baseinfo 认证响应为 session_key AES-256-GCM
                if self.session_key is None:
                    raise KisamaError(
                        "代理 >= 0.5.6 响应使用 session_key AES 加密，但本地尚未取得 session_key"
                        "（请先完成 baseinfo 握手；控制端与代理版本混布时需成对升级）"
                    )
                try:
                    body = self._aes_decrypt(body.strip(), self.session_key)
                except Exception as exc:
                    raise KisamaError("AES 响应解密失败；请确认代理版本 >= 0.5.6 且已通过 baseinfo 取得 session_key") from exc
            else:
                ecies_key = self._ensure_ecies()
                if ecies_key is None:
                    raise KisamaError("代理返回了加密响应但未提供有效 ECIES 私钥（--ecies-key）；生产模式通信必须配置该密钥")
                try:
                    body = ecies_decrypt(self.ecies.secret, base64.b64decode(body.strip()))
                except Exception as exc:
                    raise KisamaError("ECIES 响应解密失败；请确认代理版本和控制端 ECIES 私钥匹配") from exc

        if not body:
            return None
        try:
            return json.loads(body.decode("utf-8"))
        except Exception:
            return {"raw": body.decode("utf-8", errors="replace")}

    def _http(
        self,
        method: str,
        path: str,
        body: Optional[bytes],
        headers: dict[str, str],
        timeout: Optional[float] = None,
    ) -> tuple[Any, Any, int]:
        request = urllib.request.Request(
            f"{self.base_url}{self.path_prefix}{path}",
            data=body,
            headers={
                **({"X-Target-Host": self.target_host} if self.target_host else {}),
                **headers,
            },
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout) as response:
                raw = response.read()
                return self._decode_response(raw, response.headers, response.status, path), response.headers, response.status
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            return self._decode_response(raw, exc.headers, exc.code, path), exc.headers, exc.code
        except urllib.error.URLError as exc:
            raise KisamaError(f"无法连接 Kisama 代理: {exc.reason}") from exc

    def _load_cache(self) -> None:
        """从缓存文件恢复 session_key/noise_key (代理重启后失效, 由调用方重试刷新)"""
        try:
            data = json.loads(Path(self.session_cache).expanduser().read_text(encoding="utf-8"))
            session_key_b64 = data.get("session_key")
            noise_key = data.get("noise_key")
            if not session_key_b64:
                raise ValueError("缓存缺少 session_key")
            session_key = base64.b64decode(session_key_b64, validate=True)
            if len(session_key) != 32:
                raise ValueError("session_key 长度错误")
            self.session_key_b64 = session_key_b64
            self.session_key = session_key
            # php 版代理无 noise_key, 允许缺失 (仅 terminal 需要)
            self.noise_key = noise_key if isinstance(noise_key, dict) else None
            self.baseinfo_data = data.get("baseinfo")
            # 🔐 0.5.6: 从缓存 baseinfo 恢复代理版本号 (判定响应解密算法)
            if isinstance(self.baseinfo_data, dict) and self.baseinfo_data.get("version"):
                self.agent_version = str(self.baseinfo_data.get("version"))
            self._cache_state = "loaded"
        except Exception:
            self._cache_state = "none"

    def save_cache(self) -> None:
        if not self.session_cache or self.session_key_b64 is None:
            return
        path = Path(self.session_cache).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "session_key": self.session_key_b64,
                    "noise_key": self.noise_key,
                    "baseinfo": self.baseinfo_data,
                },
                ensure_ascii=False,
                separators=(",", ":"),
            ),
            encoding="utf-8",
        )
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass

    def _dynamic_timeout(self, size: int, base: Optional[float] = None) -> float:
        """按传输字节数放宽超时: 慢链路下小超时不再卡死大文件传输"""
        rate = 256 * 1024  # 保守 256KB/s
        return max(base or self.timeout, size / rate + 15)

    def bootstrap(self) -> dict[str, Any]:
        """Refresh session_key and noise_key from an authenticated baseinfo call."""
        data, _, _ = self._send_authenticated(
            "GET", "/api/baseinfo",
            lambda mode: (None, self._auth_headers(mode, "GET", "/api/baseinfo")),
        )
        # 🔐 兼容: baseinfo 是匿名白名单路由, 旧代理 (0.4.7-) 对无效签名不返回 401 而是
        # 按匿名放行 (响应无 session_key)。v2 首发失败时回退 v1 重试一次 (自动模式才回退;
        # 用户用 KISAMA_SIG_MODE 强制 v2 时不回退)。DEBUG 代理 (x-encrypted: false) 恒无
        # session_key, 属正常现象, 不得触发 v1 回退。
        if (
            isinstance(data, dict)
            and not data.get("session_key")
            and not self.debug_mode
            and not self._sig_mode_forced
            and self._sig_mode != "v1"
        ):
            self._sig_mode = "v1"
            data, _, _ = self._send_authenticated(
                "GET", "/api/baseinfo",
                lambda mode: (None, self._auth_headers(mode, "GET", "/api/baseinfo")),
            )
        if not isinstance(data, dict):
            raise KisamaError("/api/baseinfo 没有返回 JSON 对象")

        # 🌟 DEBUG 模式 (x-encrypted: false, 响应明文): 认证形同虚设, session_key/noise_key
        # 恒为 null (规范设计, docs/API.MD 第十节)。明文 HTTP 业务可用, 不视为错误;
        # baseinfo 数据本身仍返回给调用方。
        if self.debug_mode:
            self.session_key_b64 = None
            self.session_key = None
            self.noise_key = None
            self.baseinfo_data = data
            # 🔐 0.5.6: DEBUG 明文 baseinfo 同样携带 version (缓存供后续判定)
            if data.get("version"):
                self.agent_version = str(data.get("version"))
            self._cache_state = "fresh"
            return data

        session_key_b64 = data.get("session_key")
        if not session_key_b64:
            raise KisamaError("baseinfo 未返回 session_key；请确认请求使用了正确的 ECDSA 私钥")
        try:
            session_key = base64.b64decode(session_key_b64, validate=True)
        except Exception as exc:
            raise KisamaError("baseinfo 的 session_key 不是有效 Base64") from exc
        if len(session_key) != 32:
            raise KisamaError(f"baseinfo 的 session_key 长度错误：{len(session_key)}，应为 32 字节")

        # noise_key 可选: php 版代理不提供 (不支持 terminal), 仅在返回时校验结构
        noise_key = data.get("noise_key")
        if isinstance(noise_key, dict):
            controller = noise_key.get("controller") or {}
            agent = noise_key.get("agent") or {}
            if not controller.get("private") or not agent.get("public"):
                noise_key = None
        else:
            noise_key = None

        self.session_key_b64 = session_key_b64
        self.session_key = session_key
        self.noise_key = noise_key
        self.baseinfo_data = data
        # 🔐 0.5.6: 捕获代理版本号, 供后续非 baseinfo 响应的解密算法判定
        if data.get("version"):
            self.agent_version = str(data.get("version"))
        self._cache_state = "fresh"
        self.save_cache()
        return data

    def _ensure_session(self) -> None:
        if self.session_key is None and not self.debug_mode:
            self.bootstrap()

    def request_json(self, method: str, path: str, payload: Any = None) -> Any:
        self._ensure_session()

        def build(mode: str):
            headers: dict[str, str] = {}
            body = None
            if payload is not None:
                if self.debug_mode or self.session_key is None:
                    # 🌟 DEBUG 模式: 无 session_key, 请求体按明文 JSON 直发
                    # (agent DEBUG 全信任放行, 不做 AES 解密)
                    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                else:
                    body = self._aes_encrypt(
                        json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                        self.session_key,
                    )
                    headers["X-AES-Encrypted"] = "true"
                headers["Content-Type"] = "application/json"
            # v2 签名覆盖实际发送的请求体 (AES 加密体签密文); 无体签 sha256("")
            headers.update(self._auth_headers(mode, method, path, body if body else b""))
            return body, headers

        data, _, _ = self._send_authenticated(method, path, build)
        return data

    def request_binary(self, method: str, path: str, payload: Any = None, timeout: Optional[float] = None) -> bytes:
        self._ensure_session()

        def build(mode: str):
            headers: dict[str, str] = {"Content-Type": "application/json"}
            body = None
            if payload is not None:
                if self.debug_mode or self.session_key is None:
                    # 🌟 DEBUG 模式: 无 session_key, 请求体按明文 JSON 直发
                    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                else:
                    body = self._aes_encrypt(
                        json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                        self.session_key,
                    )
                    headers["X-AES-Encrypted"] = "true"
            headers.update(self._auth_headers(mode, method, path, body if body else b""))
            return body, headers

        data, _, _ = self._send_authenticated(method, path, build, timeout=timeout)
        if not isinstance(data, bytes):
            raise KisamaError(f"接口没有返回二进制内容: {data}")
        return data

    def upload(self, local_file: str, remote_path: str, remote_name: Optional[str] = None, chunk_size: int = 8 * 1024 * 1024, timeout: Optional[float] = None) -> dict[str, Any]:
        # 🔐 0.5.6 协议 (docs/API.MD 十二): /api/fileraw 的响应也是 session_key AES 加密,
        # 必须先完成 baseinfo 握手取得 session_key 与代理版本号 (0.5.5- 响应为 ECIES,
        # 不握手也能解, 因此旧版不需要此调用; 缺了它 0.5.6+ 的上传会按 ECIES 解密失败)
        self._ensure_session()
        source = Path(local_file).expanduser()
        if not source.is_file():
            raise KisamaError(f"本地文件不存在: {source}")
        # 🌟 --remote-path 是"目标目录"（相对 FILE_ROOT），最终文件 = <remote-path>/<--name>。
        # 误传已存在的文件路径（如 --remote-path info.php）时，代理端会把 <dir>/<name> 拼成
        # "info.php/diag.php"——目录型代理 (go/py/js) 会尝试建目录但最终写出 nested 文件，
        # PHP 代理则把分片写进无法合并的隐藏暂存目录，恒返回 completed:false。
        # 列父目录探测 remote_path 末段是否为已存在文件，提前拦下给出明确指引。
        probe_dir, _, leaf = (remote_path or "").strip("/").rpartition("/")
        probe_dir = probe_dir or "."
        if leaf and leaf not in (".", ".."):
            try:
                listing = self.request_json("POST", "/api/file/list", {"path": probe_dir, "recursive": False})
            except KisamaError:
                listing = None  # 目录不存在等异常交由代理端上传时自行报错
            if isinstance(listing, dict) and isinstance(listing.get("files"), list):
                for entry in listing["files"]:
                    if entry.get("name") == leaf and entry.get("type") != "directory":
                        raise KisamaError(
                            f"--remote-path '{remote_path}' 在远端是一个已存在的文件；"
                            f"该参数应为目标目录（最终文件 = 目录/--name）。"
                            f"要传到此目录或用新名字请写 --remote-path '.' --name '<目标文件名>'"
                        )
        remote_name = remote_name or source.name
        total_size = source.stat().st_size
        total_chunks = max(1, (total_size + chunk_size - 1) // chunk_size)
        chunk_timeout = timeout or self._dynamic_timeout(chunk_size)
        result: dict[str, Any] = {}

        with source.open("rb") as handle:
            for chunk_id in range(total_chunks):
                chunk = handle.read(chunk_size)
                if not chunk and total_size != 0:
                    raise KisamaError(f"读取本地文件时分片 {chunk_id} 为空")
                # 🔐 0.4.8: /api/fileraw 按约定签空体; 旧代理 v1 签名不涉及 body
                headers = self._auth_headers(self._sig_mode or "v2", "POST", "/api/fileraw", b"")
                headers.update({
                    "Accept": "application/json",
                    "Content-Type": "application/octet-stream",
                    "X-File-Path": urllib.parse.quote(remote_path, safe="/"),
                    "X-File-Name": urllib.parse.quote(remote_name, safe=""),
                    "X-Chunk-Id": str(chunk_id),
                    "X-Total-Chunks": str(total_chunks),
                })
                data, _, _ = self._http("POST", "/api/fileraw", chunk, headers, timeout=chunk_timeout)
                if not isinstance(data, dict):
                    raise KisamaError(f"上传分片 {chunk_id} 返回格式错误")
                result = data
        # 全部 5 端代理 (py/go/js/java) 与 PHP 代理在合并成功时都会置 completed:true;
        # 若末片返回后仍未合并 (completed:false)，说明分片被写进了无法合并的暂存目录，
        # 最常见原因是 --remote-path 误传了远端已存在的文件路径（应为目录）。此时不能
        # 把底层响应当成功透传给上层，必须报错以免 AI 误以为上传完成。
        if not result.get("completed"):
            raise KisamaError(
                f"上传分片已全部发出但代理端未完成合并 (completed=false: {result.get('message', '')})；"
                f"请确认 --remote-path 是目标目录（最终文件 = 目录/--name）而非已存在的文件路径，"
                f"可先 list 父目录确认后重试"
            )
        return result

    def download(self, remote_path: str, local_file: str, timeout: Optional[float] = None) -> dict[str, Any]:
        data = self.request_binary("POST", "/api/file/download", {"path": remote_path}, timeout=timeout or self._dynamic_timeout(64 * 1024 * 1024))
        destination = Path(local_file).expanduser()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        return {"status": "ok", "path": str(destination), "size": len(data)}

    async def terminal(
        self,
        command: Optional[str] = None,
        raw_input: Optional[str] = None,
        request_id: Optional[str] = None,
        token: Optional[str] = None,
        rows: int = 24,
        cols: int = 80,
        timeout: float = 60.0,
    ) -> dict[str, Any]:
        """超级终端 (带 0.4.8 密钥轮换恢复).

        token 取值兼容两种代理:
          - 0.4.8+: 传 "auto" 或 self.ws_downgrade_token() (HMAC(session_key));
          - 0.4.7-: 传 noise_key.agent.public (旧行为不变);
          - None:   走 Noise 加密模式 (两端通用).
        0.4.8 代理在 tempkey 过期时会轮换 session_key/控制端密钥对: 首次尝试若因
        Noise 公钥不匹配或 token 校验失败 (close 1008) 失败, 自动重拉 baseinfo
        刷新密钥后重试一次。
        """
        self._ensure_session()
        # 🌟 DEBUG 代理: baseinfo 恒无 noise_key (规范设计), 无法建立 Noise/Token 终端会话。
        # 提前给出明确指引, 避免深入 WS 握手后报出晦涩的密钥错误。
        if self.debug_mode and self.noise_key is None:
            raise KisamaError("该代理处于 DEBUG 模式 (x-encrypted: false)，不下发 session_key/noise_key，不支持 terminal；请改用 exec")
        if token == "auto":
            token = self.ws_downgrade_token()
        try:
            return await self._terminal_once(command, raw_input, request_id, token, rows, cols, timeout)
        except Exception as exc:
            msg = str(exc)
            stale_key = "不匹配" in msg or "1008" in msg
            if stale_key:
                self.bootstrap()
                return await self._terminal_once(command, raw_input, request_id, token, rows, cols, timeout)
            raise

    async def _terminal_once(
        self,
        command: Optional[str] = None,
        raw_input: Optional[str] = None,
        request_id: Optional[str] = None,
        token: Optional[str] = None,
        rows: int = 24,
        cols: int = 80,
        timeout: float = 60.0,
    ) -> dict[str, Any]:
        self._ensure_session()
        request_id = request_id or f"kisama-{uuid.uuid4().hex}"
        query = {"request_id": request_id, "meta": "1"}
        if token:
            query["token"] = token
        scheme = "wss" if self.base_url.startswith("https://") else "ws"
        host_url = self.base_url.replace("https://", f"{scheme}://", 1).replace("http://", f"{scheme}://", 1)
        ws_url = f"{host_url}{self.path_prefix}/api/ws/terminal?{urllib.parse.urlencode(query)}"
        ws_headers = {"X-Target-Host": self.target_host} if self.target_host else None

        async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10, max_size=2**22, additional_headers=ws_headers) as websocket:
            cipher: Optional[NoiseConnection] = None
            if not token:
                if not isinstance(self.noise_key, dict):
                    raise KisamaError("该代理未提供 noise_key (常见于 php 版代理)，不支持 terminal，请改用 exec")
                controller_private = base64.b64decode(self.noise_key["controller"]["private"])
                expected_agent_public = base64.b64decode(self.noise_key["agent"]["public"])
                cipher = NoiseConnection.from_name(b"Noise_XX_25519_ChaChaPoly_BLAKE2s")
                cipher.set_as_initiator()
                cipher.set_keypair_from_private_bytes(Keypair.STATIC, controller_private)
                cipher.set_prologue(b"kisama_terminal_v1")
                cipher.start_handshake()
                await websocket.send(cipher.write_message(b""))
                msg2 = await websocket.recv()
                cipher.read_message(msg2 if isinstance(msg2, bytes) else msg2.encode())
                try:
                    remote_public = cipher.noise_protocol.handshake_state.rs.public_bytes
                except AttributeError as exc:
                    raise KisamaError("Noise 库无法读取代理静态公钥，拒绝继续") from exc
                if remote_public != expected_agent_public:
                    raise KisamaError("Noise 握手中代理静态公钥不匹配")
                await websocket.send(cipher.write_message(b""))
                if not cipher.handshake_finished:
                    raise KisamaError("Noise 握手未完成")

            async def send_payload(payload: bytes) -> None:
                await websocket.send(cipher.encrypt(payload) if cipher else payload)

            async def recv_plain(timeout_s: float) -> bytes:
                msg = await asyncio.wait_for(websocket.recv(), timeout=timeout_s)
                if isinstance(msg, str):
                    msg = msg.encode("utf-8")
                return cipher.decrypt(msg) if cipher else msg

            # 🔤 shell 自适配 (0.5.8): meta=1 请求 welcome 元数据帧 (0.5.5+, 先于 PTY 首字节)，
            # 拿到 shell 类型再注入命令——Windows 代理 PTY 是 PowerShell，POSIX 标记包装必超时。
            # 老代理无 welcome 帧: 首帧即 PTY 数据，落缓冲后按 baseinfo os 兜底判断。
            shell_kind: Optional[str] = None
            output = bytearray()
            try:
                while True:
                    first_plain = await recv_plain(1.5)
                    try:
                        obj = json.loads(first_plain.decode("utf-8"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        output.extend(first_plain)
                        break
                    if obj.get("type") == "welcome":
                        shell_kind = _resolve_terminal_shell(str(obj.get("shell") or ""), None)
                        continue
                    if obj.get("type") == "heartbeat":
                        continue
                    output.extend(first_plain)
                    break
            except asyncio.TimeoutError:
                pass
            if shell_kind is None:
                shell_kind = _resolve_terminal_shell(None, (self.baseinfo_data or {}).get("os"))

            async def heartbeat() -> None:
                while True:
                    await asyncio.sleep(10)
                    await send_payload(b'{"type":"heartbeat"}')

            heartbeat_task = asyncio.create_task(heartbeat())
            try:
                marker = f"__KISAMA_DONE__{uuid.uuid4().hex}"
                # resize 先于命令注入: 避免执行期 conpty 重绘把 ANSI 序列插进标记输出破坏匹配
                await send_payload(json.dumps({"type": "resize", "rows": rows, "cols": cols}, separators=(",", ":")).encode("utf-8"))
                if command is not None:
                    payload = {
                        "type": "input",
                        "data": base64.b64encode(_terminal_command_payload(command, marker, shell_kind)).decode("ascii"),
                        "encoding": "base64",
                    }
                    await send_payload(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
                    # 不要求行首 \n: 回显行内标记后跟的是未求值文本 (冒号后非数字), 本就不会误匹配;
                    # 这样即使 PSReadLine 续行提示符/重绘把标记顶到行中也能匹配
                    pattern = re.compile(re.escape(marker.encode()) + rb":(\d+)__\r?\n")
                elif raw_input is not None:
                    await send_payload(raw_input.encode("utf-8"))
                    pattern = None
                else:
                    raise KisamaError("terminal 必须提供 command 或 raw_input")

                exitcode: Optional[int] = None
                started = time.monotonic()
                while time.monotonic() - started < timeout:
                    remaining = max(0.1, timeout - (time.monotonic() - started))
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=remaining)
                    except asyncio.TimeoutError:
                        break
                    if isinstance(message, str):
                        message = message.encode("utf-8")
                    plain = cipher.decrypt(message) if cipher else message
                    try:
                        obj = json.loads(plain.decode("utf-8"))
                        if obj.get("type") in ("heartbeat", "welcome"):
                            continue
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        pass
                    output.extend(plain)
                    if pattern:
                        # 匹配在剥离 ANSI/OSC 序列后的缓冲上进行 (conpty 重绘会把光标序列
                        # 插进标记文本中间, 原始字节流上匹配会随时序抖动)
                        searchable = _TERMINAL_ANSI_RE.sub(b"", bytes(output))
                        match = pattern.search(searchable)
                        if match:
                            exitcode = int(match.group(1))
                            text = searchable[:match.start()].decode("utf-8", errors="replace")
                            return {
                                "status": "ok",
                                "request_id": request_id,
                                "output": text,
                                "exitcode": exitcode,
                            }
                text = output.decode("utf-8", errors="replace")
                return {
                    "status": "ok" if (pattern is None or exitcode is not None) else "timeout",
                    "request_id": request_id,
                    "output": text,
                    "exitcode": exitcode,
                }
            finally:
                heartbeat_task.cancel()
                try:
                    await heartbeat_task
                except asyncio.CancelledError:
                    pass


def parse_pairs(values: list[str], label: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise KisamaError(f"{label} 参数必须是 key=value: {value}")
        key, val = value.split("=", 1)
        if not key:
            raise KisamaError(f"{label} 的 key 不能为空")
        result[key] = val
    return result


def output(value: Any, pretty: bool = False) -> None:
    if isinstance(value, bytes):
        sys.stdout.buffer.write(value)
        return
    print(json.dumps(value, ensure_ascii=False, indent=2 if pretty else None, default=str))


def _ensure_utf8_stdio() -> None:
    """Windows 控制台默认编码可能是 GBK/cp1252, 打印中文 JSON 会抛
    UnicodeEncodeError（Linux/macOS 默认 UTF-8 无此问题）。这里强制 UTF-8。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


# ============================================================================
# 🔗 Kisama 分享链接 (kisama://) 与连接档案 (0.5.8)
# ============================================================================
# 链接格式 (脚本为权威解析器, 兼容两种生成端写法):
#   kisama://node?domain=<值>&ecdsaprikey=<64位hex>&eciesprikey=<64位hex>[&tls=1][&扩展参数...]
# - 值先手工按 & 与第一个 = 切分, 再做百分号解码 (unquote, 不转 + 为空格):
#   生成端既可标准 URL 编码 (domain=https%3A%2F%2F...%23...), 也可原样携带 '#' 直接传
# - domain: host[:port] (缺省拼 http://) 或完整 URL (http(s):// 开头则原样, 可含 # 网关路由);
#   tls=1 / secure=1 → 强制 https:// 前缀
# - ecdsaprikey: P-256 私钥标量 64 位 hex (tempkey?format=short 下发, 兼容 Base64(32字节))
# - eciesprikey: 64 位 hex (兼容 Base64(32字节))
# - 未知参数不报错, 原样存入连接档案 extra 字段 (前向兼容)
# - netloc (node) 不参与语义; 链接两端空白容忍
CONNECT_REQUIRED_PARAMS = ("domain", "ecdsaprikey", "eciesprikey")

# 终端输出中的 ANSI CSI/OSC 控制序列 (done 标记匹配前剥离, conpty 重绘会插在任意字节之间)
_TERMINAL_ANSI_RE = re.compile(rb"\x1b\[[0-9;?]*[a-zA-Z]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")


def parse_share_link(link: str) -> dict[str, Any]:
    """解析 kisama:// 分享链接 → {url, ecdsa_key, ecies_key, extra}。

    手工按 & 与第一个 = 切分键值 (不经 parse_qs, 因此值内的 '#' 不会被误当片段),
    再对值做 unquote 百分号解码 (不转 + 为空格, 兼容 Base64 密钥材料)——
    已编码与原样两种生成端写法均可。缺必填参数抛 KisamaError 并指出缺哪个。
    """
    raw = (link or "").strip()
    if not raw.lower().startswith("kisama://"):
        raise KisamaError("分享链接必须以 kisama:// 开头")
    _, _, query = raw.partition("?")
    if not query:
        raise KisamaError("分享链接缺少查询参数 (kisama://node?domain=...&ecdsaprikey=...&eciesprikey=...)")
    params: dict[str, str] = {}
    for pair in query.split("&"):
        if not pair:
            continue
        key, sep, value = pair.partition("=")
        if not sep:
            continue
        params[key.strip()] = urllib.parse.unquote(value.strip())

    missing = [name for name in CONNECT_REQUIRED_PARAMS if not params.get(name)]
    if missing:
        raise KisamaError("分享链接缺少参数: " + ", ".join(missing))

    domain = params["domain"]
    force_tls = params.get("tls", "").lower() in ("1", "true", "yes") or params.get("secure", "").lower() in ("1", "true", "yes")
    if domain.lower().startswith(("http://", "https://")):
        url = domain
    elif force_tls:
        url = f"https://{domain}"
    else:
        url = f"http://{domain}"

    extra = {k: v for k, v in params.items() if k not in CONNECT_REQUIRED_PARAMS and k not in ("tls", "secure")}
    return {
        "url": url,
        "ecdsa_key": params["ecdsaprikey"],
        "ecies_key": params["eciesprikey"],
        "extra": extra,
    }


def _resolve_terminal_shell(shell_name: Optional[str], baseinfo_os: Optional[str]) -> str:
    """归一化终端 shell 类型 → "powershell" | "cmd" | "posix"。

    优先取 welcome 元数据帧 (0.5.5+, meta=1) 上报的 shell 归一化名 (powershell/pwsh/cmd/bash...)；
    无帧时 (旧代理) 按 baseinfo os 字段兜底 —— 各语言 Windows 代理 PTY 均优先 PowerShell。
    """
    name = (shell_name or "").strip().lower()
    if name.startswith("powershell") or name == "pwsh":
        return "powershell"
    if name == "cmd":
        return "cmd"
    if name:
        return "posix"
    return "powershell" if "windows" in str(baseinfo_os or "").lower() else "posix"


def _terminal_command_payload(command: str, marker: str, shell_kind: str) -> bytes:
    r"""构造"用户命令 + done 标记"注入载荷 (按 shell 自适配)。

    marker 为完整标记串 (__KISAMA_DONE__<uuid>)。
    - posix: printf + "$?" (现状, Linux 全家桶)
    - powershell: 无 printf 命令、"$?" 是布尔、且 LF 不是 Enter (PSReadLine 视为续行) ——
      必须 CRLF 行尾 + Write-Output + "$?" 布尔转 0/1 (实测 $LASTEXITCODE 在部分环境展开为空)
    - cmd: echo. 空行 + %errorlevel% 展开
    标记的回显行内是未求值文本 (冒号后无纯数字), 不会误触发匹配模式中的 (\d+)。
    """
    if shell_kind == "powershell":
        # 单语句: "$(if ($?) ...)" 在字符串构造时求值, 此时前一语句正是用户命令;
        # 若前面再插任何语句 (如空行 Write-Output '') 会把 $? 重置为 True → 退码恒 0。
        return (
            f"{command}\r\n"
            f"Write-Output \"{marker}:$(if ($?) {{0}} else {{1}})__\"\r\n"
        ).encode("utf-8")
    if shell_kind == "cmd":
        return (
            f"{command}\r\n"
            f"echo.\r\necho {marker}:%errorlevel%__\r\n"
        ).encode("utf-8")
    return (
        f"{command}\n"
        f"printf '\\n{marker}:%s__\\n' \"$?\"\n"
    ).encode("utf-8")


def _profile_path(name_or_path: Optional[str]) -> Path:
    """解析连接档案路径: 缺省 ~/.kisama/profile.json; 传名称 → ~/.kisama/profiles/<名>.json;
    传 .json 路径 (绝对或相对) 原样。"""
    base = Path.home() / ".kisama"
    raw = (name_or_path or "").strip()
    if not raw:
        return base / "profile.json"
    p = Path(raw)
    if p.suffix == ".json" or str(p.parent) not in (".", ""):
        return p if p.is_absolute() else Path.cwd() / p
    return base / "profiles" / f"{raw}.json"


def load_profile(name_or_path: Optional[str] = None) -> Optional[dict[str, Any]]:
    """读取连接档案; 缺失/损坏/无 url 返回 None (绝不抛错, 档案仅是便捷层)。"""
    try:
        data = json.loads(_profile_path(name_or_path).read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(data, dict) or not data.get("url"):
        return None
    return data


def save_profile(name_or_path: Optional[str], profile: dict[str, Any]) -> Path:
    """写入连接档案 (JSON, UTF-8), POSIX 下收敛权限为 0600 (Windows 忽略)。"""
    path = _profile_path(name_or_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def delete_profile(name_or_path: Optional[str] = None) -> bool:
    """删除连接档案及同名会话缓存; 档案不存在返回 False。"""
    path = _profile_path(name_or_path)
    removed = False
    for target in (path, Path(str(path) + ".session.json")):
        try:
            target.unlink()
            removed = True
        except OSError:
            pass
    return removed


def _mask_secret(value: Optional[str]) -> str:
    if not value:
        return "(未配置)"
    if len(value) <= 10:
        return value[:3] + "***"
    return f"{value[:6]}...{value[-4:]} (len={len(value)})"


def resolve_connection(args: argparse.Namespace) -> None:
    """就地补全 args.url / args.ecdsa_key / args.ecies_key / args.session_cache。

    优先级: CLI 显式 > --link/KISAMA_LINK > 环境变量 > 连接档案。
    档案存在且未 --no-session-cache 时, 会话缓存默认启用 (档案同名 .session.json)。
    """
    profile = load_profile(args.profile)
    link_raw = getattr(args, "link", None) or os.environ.get("KISAMA_LINK")
    link = parse_share_link(link_raw) if link_raw else None
    if link_raw and link is None:
        link = {}

    def pick(attr: str, env: str, link_key: str, profile_key: str) -> None:
        value = getattr(args, attr, None)
        if value:
            return
        if link and link.get(link_key):
            value = link[link_key]
        if not value:
            value = os.environ.get(env)
        if not value and profile:
            value = profile.get(profile_key)
        setattr(args, attr, value or None)

    pick("url", "KISAMA_URL", "url", "url")
    pick("ecdsa_key", "KISAMA_ECDSA_KEY", "ecdsa_key", "ecdsa_key")
    pick("ecies_key", "KISAMA_ECIES_KEY", "ecies_key", "ecies_key")

    if not args.session_cache and not getattr(args, "no_session_cache", False):
        env_cache = os.environ.get("KISAMA_SESSION_CACHE")
        if env_cache:
            args.session_cache = env_cache
        elif profile:
            # 仅连接档案模式默认启用会话缓存; --link 一次性用法不落盘
            args.session_cache = str(_profile_path(args.profile)) + ".session.json"


def do_connect(args: argparse.Namespace) -> dict[str, Any]:
    """connect: 解析分享链接/手工参数 → baseinfo 握手校验 → 保存连接档案 → 播种会话缓存。"""
    if getattr(args, "show", False):
        profile = load_profile(args.profile)
        if not profile:
            raise KisamaError(f"连接档案不存在: {_profile_path(args.profile)} (先执行 connect 保存)")
        return {
            "status": "ok",
            "action": "connect",
            "mode": "show",
            "profile_path": str(_profile_path(args.profile)),
            "url": profile.get("url"),
            "agent_version": profile.get("agent_version"),
            "debug_mode": profile.get("debug_mode"),
            "key_id": profile.get("key_id"),
            "saved_at": profile.get("saved_at"),
            "source": profile.get("source"),
            "ecdsa_key": _mask_secret(profile.get("ecdsa_key")),
            "ecies_key": _mask_secret(profile.get("ecies_key")),
            "extra": profile.get("extra") or {},
        }

    link_raw = getattr(args, "link", None)
    link = parse_share_link(link_raw) if link_raw else None
    url = args.url or os.environ.get("KISAMA_URL") or (link or {}).get("url") or (load_profile(args.profile) or {}).get("url")
    if not url:
        raise KisamaError("connect 需要 --url 或整条 kisama:// 分享链接 (链接作为位置参数传入)")

    ecdsa_key = args.ecdsa_key or os.environ.get("KISAMA_ECDSA_KEY") or (link or {}).get("ecdsa_key")
    ecies_key = args.ecies_key or os.environ.get("KISAMA_ECIES_KEY") or (link or {}).get("ecies_key")

    # 校验: 完成 baseinfo 握手 (DEBUG 代理同样成功; 密钥错误当场报错)。校验握手不落缓存。
    client = KisamaClient(url, ecdsa_key, ecies_key, args.timeout, None, args.clock_offset)
    data = client.bootstrap()

    profile: dict[str, Any] = {
        "url": url,
        "ecdsa_key": ecdsa_key or "",
        "ecies_key": ecies_key or "",
        "agent_version": client.agent_version,
        "debug_mode": client.debug_mode,
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source": "link" if link else "manual",
    }
    if link:
        profile["link"] = link_raw.strip()
        if link.get("extra"):
            profile["extra"] = link["extra"]
        profile["key_id"] = link["extra"].get("key_id") if link.get("extra") else None
    path = save_profile(args.profile, profile)

    # 会话缓存: 档案同名 .session.json, 播种校验握手的 session_key, 下一命令免重复握手
    sess_path = Path(str(path) + ".session.json")
    try:
        if sess_path.exists():
            sess_path.unlink()
        if not getattr(args, "no_session_cache", False):
            client.session_cache = str(sess_path)
            client.save_cache()
    except OSError:
        pass

    return {
        "status": "ok",
        "action": "connect",
        "profile_path": str(path),
        "url": url,
        "agent_version": client.agent_version,
        "debug_mode": client.debug_mode,
        "key_id": profile.get("key_id"),
        "source": profile["source"],
        "ecdsa_key": _mask_secret(ecdsa_key),
        "ecies_key": _mask_secret(ecies_key),
        "session_cached": bool(client.session_cache) and client.session_key_b64 is not None,
    }


def do_disconnect(args: argparse.Namespace) -> dict[str, Any]:
    """disconnect: 删除连接档案与同名会话缓存。"""
    path = _profile_path(args.profile)
    removed = delete_profile(args.profile)
    return {
        "status": "ok" if removed else "noop",
        "action": "disconnect",
        "profile_path": str(path),
        "message": "连接档案已删除" if removed else "连接档案不存在 (无需清除)",
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="使用 Kisama Python 控制端连接并操作代理")
    parser.add_argument("--url", default=None, help="代理地址，例如 http://127.0.0.1:8000（必填；或先 connect 保存连接档案 / 用 --link 传入 kisama:// 分享链接）")
    parser.add_argument("--ecdsa-key", default=None, help="控制端 ECDSA 私钥文件或内容：PEM/DER，或 64 位 hex / Base64(32字节) 短格式标量（tempkey?format=short 下发，0.5.8 起支持）（可省略：DEBUG 代理免签名；生产代理会 401）")
    parser.add_argument("--ecies-key", default=None, help="控制端 ECIES 私钥文件、64 位 hex 或 Base64(32字节)（可省略：DEBUG 代理响应恒明文；生产代理必须提供）")
    parser.add_argument("--timeout", type=float, default=30.0, help="每次 HTTP 请求超时(秒), 上传/下载大文件自动放宽")
    parser.add_argument("--session-cache", default=None, help="会话缓存文件(JSON), 复用 session_key/noise_key, 免每次重复 baseinfo; 连接档案模式下缺省启用(档案同名 .session.json)")
    parser.add_argument("--no-session-cache", dest="no_session_cache", action="store_true", help="禁用会话缓存 (连接档案模式下默认启用)")
    parser.add_argument("--link", default=os.getenv("KISAMA_LINK"), help="kisama:// 分享链接整条传入 (任意命令可用, 免 connect 建档); KISAMA_LINK 环境变量等效")
    parser.add_argument("--profile", default=os.getenv("KISAMA_PROFILE"), help="连接档案: 名称(存 ~/.kisama/profiles/<名>.json)或 .json 文件路径; 缺省 ~/.kisama/profile.json; KISAMA_PROFILE 环境变量等效")
    parser.add_argument("--pretty", action="store_true")
    parser.add_argument("--clock-offset", type=float, default=None, help="签名时间戳偏移(秒), 默认自动从服务器 Date 头探测")
    sub = parser.add_subparsers(dest="action", required=True)

    sub.add_parser("baseinfo", help="获取代理信息并刷新 session_key/noise_key")

    command = sub.add_parser("exec", help="执行一次非交互式命令")
    command.add_argument("--cmd", required=True)
    command.add_argument("--cwd")
    command.add_argument("--env", action="append", default=[], metavar="KEY=VALUE")
    command.add_argument("--route", default="/api/exec",
                         choices=["/api/exec", "/api/do", "/api/run", "/api/work"],
                         help="exec 路由 (0.5.7+ 代理)。WAF/审计规则拦截 /api/exec 时优先 --route /api/do，备选 /api/run、/api/work；别名与默认路由完全等价，签名按实际路径自动处理")

    listing = sub.add_parser("list", help="列出远端文件")
    listing.add_argument("--path", default=".")
    listing.add_argument("--recursive", action="store_true")

    cat = sub.add_parser("cat", help="读取远端文件")
    cat.add_argument("--path", required=True)

    authority_get = sub.add_parser("authority-get", help="查询远端权限")
    authority_get.add_argument("paths", nargs="+")

    authority_set = sub.add_parser("authority-set", help="设置远端权限")
    authority_set.add_argument("permissions", nargs="+", metavar="PATH=MODE")
    authority_set.add_argument("--recursive", action="store_true")

    mkdir = sub.add_parser("mkdir", help="创建远端目录")
    mkdir.add_argument("--path", required=True)

    move = sub.add_parser("move", help="移动或重命名远端文件")
    move.add_argument("mapping", nargs="+", metavar="FROM=TO")

    copy = sub.add_parser("copy", help="复制远端文件")
    copy.add_argument("mapping", nargs="+", metavar="FROM=TO")

    delete = sub.add_parser("delete", help="删除远端文件或目录")
    delete.add_argument("paths", nargs="+")

    upload = sub.add_parser("upload", help="上传本地文件到远端，自动使用裸二进制分片")
    upload.add_argument("--local", required=True)
    upload.add_argument("--remote-path", required=True)
    upload.add_argument("--name")
    upload.add_argument("--chunk-size", type=int, default=8 * 1024 * 1024)

    download = sub.add_parser("download", help="下载远端文件到本地")
    download.add_argument("--remote-path", required=True)
    download.add_argument("--local", required=True)

    zipcmd = sub.add_parser("zip", help="打包远端文件/目录为 zip (需代理端 0.5.4+)")
    zipcmd.add_argument("--path", required=True, help="目标 zip 路径 (相对 FILE_ROOT); 已存在时覆盖重建")
    zipcmd.add_argument("items", nargs="+", help="待压缩文件/目录 (相对 FILE_ROOT); 目录递归打包")
    zipcmd.add_argument("--flat", action="store_true", help="目录内容不带顶层目录名前缀")

    unzip = sub.add_parser("unzip", help="解压远端 zip 包 (需代理端 0.5.4+)")
    unzip.add_argument("--path", required=True, help="zip 压缩包路径 (相对 FILE_ROOT)")
    unzip.add_argument("--dest", help="解压目标目录, 缺省为 zip 所在目录 (解压到此处)")
    unzip.add_argument("--no-overwrite", action="store_true", help="目标文件已存在时跳过 (缺省覆盖)")
    unzip.add_argument("--entries", nargs="+", metavar="NAME", help="仅解压匹配条目 (精确名或不带路径匹配)")

    terminal = sub.add_parser("terminal", help="通过 Noise 超级终端执行命令")
    group = terminal.add_mutually_exclusive_group(required=True)
    group.add_argument("--command")
    group.add_argument("--input")
    terminal.add_argument("--request-id")
    terminal.add_argument("--token", help="明文降级模式令牌: 0.4.8+ 用 auto (自动按 HMAC(session_key) 计算); 旧版代理传 agent 公钥; 不传走 Noise 加密模式")
    terminal.add_argument("--rows", type=int, default=24)
    terminal.add_argument("--cols", type=int, default=80)
    terminal.add_argument("--terminal-timeout", type=float, default=60.0)

    sub.add_parser("tunnel-list", help="查询临时隧道列表 (GET /api/argo)")
    tunnel_create = sub.add_parser("tunnel-create", help="创建临时隧道 (POST /api/argo)")
    tunnel_create.add_argument("--port", type=int, help="隧道转发端口 1~65535, 缺省用 agent 自身监听端口")
    tunnel_create.add_argument("--duplicate", action="store_true", help="允许同一端口重复创建隧道")
    tunnel_delete = sub.add_parser("tunnel-delete", help="删除临时隧道 (DELETE /api/argo)")
    tunnel_delete.add_argument("--port", type=int, required=True, help="要删除的隧道转发端口 1~65535")
    tunnel_delete.add_argument("--tunnel-domain", help="同端口存在多条隧道时用于精确定位")

    connect = sub.add_parser("connect", help="整条 kisama:// 分享链接(或 --url/--ecdsa-key/--ecies-key)一次完成校验并保存连接档案, 之后所有命令免密钥参数")
    connect.add_argument("link", nargs="?", default=None, metavar="LINK", help="kisama:// 分享链接整条传入 (引号包裹); 省略时用 --url 等参数手工连接")
    connect.add_argument("--url", default=argparse.SUPPRESS, help="手工连接: 代理地址 (省略链接时使用)")
    connect.add_argument("--ecdsa-key", default=argparse.SUPPRESS, help="手工连接: ECDSA 私钥 (省略链接时使用)")
    connect.add_argument("--ecies-key", default=argparse.SUPPRESS, help="手工连接: ECIES 私钥 (省略链接时使用)")
    connect.add_argument("--show", action="store_true", help="仅显示当前连接档案 (脱敏), 不联网")
    sub.add_parser("disconnect", help="删除连接档案与同名会话缓存")
    return parser


def require_options(args: argparse.Namespace) -> None:
    # 🌟 仅 --url 必填: 密钥改惰性加载, DEBUG 模式代理 (x-encrypted: false) 免验签/免解密,
    # 无密钥也能探测与操作; 生产模式首次签名/解密时才因缺钥报出明确错误。
    missing = [name for name in ("url",) if not getattr(args, name)]
    if missing:
        raise KisamaError(
            "缺少连接参数: " + ", ".join(missing)
            + "。可先执行 connect \"kisama://...\" 保存连接档案, 或用 --link 传整条分享链接, 或用命令行参数 / KISAMA_URL 环境变量"
        )


async def run(args: argparse.Namespace) -> Any:
    # 🔗 连接档案管理命令: 不走常规连接解析
    if args.action == "connect":
        return do_connect(args)
    if args.action == "disconnect":
        return do_disconnect(args)

    # 其余命令: CLI 显式 > --link/KISAMA_LINK > 环境变量 > 连接档案
    resolve_connection(args)
    require_options(args)
    client = KisamaClient(args.url, args.ecdsa_key, args.ecies_key, args.timeout, args.session_cache, args.clock_offset)
    try:
        return await dispatch(client, args)
    except KisamaError as exc:
        # 缓存密钥失效时清空重试一次 (重拉 baseinfo 刷新)。
        # 🌟 生产缓存撞上 DEBUG 代理的场景依赖这次重试: 首个请求用缓存密钥 AES 加密会被
        # DEBUG 代理原样透传给路由 (DEBUG 分支跳过解密) 而报错, 但响应已置位 debug_mode,
        # 重试后走明文直发即可成功。bootstrap 成功后 _cache_state 变为 "fresh", 不会重试第二次。
        if client._cache_state == "loaded":
            client._cache_state = "none"
            client.session_key_b64 = None
            client.session_key = None
            client.noise_key = None
            return await dispatch(client, args)
        raise


async def dispatch(client: KisamaClient, args: argparse.Namespace) -> Any:
    if args.action == "baseinfo":
        data = client.bootstrap()
        if isinstance(data, dict):
            return {
                k: ("***masked***" if k in ("session_key", "noise_key") else v)
                for k, v in data.items()
            }
        return data
    if args.action == "exec":
        return client.request_json("POST", getattr(args, "route", None) or "/api/exec", {"cmd": args.cmd, **({"cwd": args.cwd} if args.cwd else {}), **({"env": parse_pairs(args.env, "env")} if args.env else {})})
    if args.action == "list":
        return client.request_json("POST", "/api/file/list", {"path": args.path, "recursive": args.recursive})
    if args.action == "cat":
        return client.request_json("POST", "/api/file/cat", {"path": args.path})
    if args.action == "authority-get":
        return client.request_json("POST", "/api/file/authority", {"paths": args.paths})
    if args.action == "authority-set":
        return client.request_json("PUT", "/api/file/authority", {"permissions": parse_pairs(args.permissions, "permissions"), "recursive": args.recursive})
    if args.action == "mkdir":
        return client.request_json("POST", "/api/file/new", {"path": args.path})
    if args.action == "move":
        return client.request_json("PUT", "/api/file", parse_pairs(args.mapping, "mapping"))
    if args.action == "copy":
        return client.request_json("POST", "/api/file/cp", parse_pairs(args.mapping, "mapping"))
    if args.action == "delete":
        return client.request_json("DELETE", "/api/file", {"paths": args.paths})
    if args.action == "upload":
        return client.upload(args.local, args.remote_path, args.name, args.chunk_size)
    if args.action == "download":
        return client.download(args.remote_path, args.local)
    if args.action == "zip":
        return client.request_json("POST", "/api/file/zip", {"path": args.path, "items": list(args.items), "flat": args.flat})
    if args.action == "unzip":
        payload: dict[str, Any] = {"path": args.path, "overwrite": not args.no_overwrite}
        if args.dest:
            payload["dest_path"] = args.dest
        if args.entries:
            payload["entries"] = list(args.entries)
        return client.request_json("POST", "/api/file/unzip", payload)
    if args.action == "terminal":
        return await client.terminal(args.command, args.input, args.request_id, args.token, args.rows, args.cols, args.terminal_timeout)
    if args.action == "tunnel-list":
        return client.request_json("GET", "/api/argo", None)
    if args.action == "tunnel-create":
        payload: dict[str, Any] = {}
        if args.port is not None:
            payload["port"] = args.port
        if args.duplicate:
            payload["duplicate"] = True
        return client.request_json("POST", "/api/argo", payload)
    if args.action == "tunnel-delete":
        payload = {"port": args.port}
        if args.tunnel_domain:
            payload["tunnel_domain"] = args.tunnel_domain
        return client.request_json("DELETE", "/api/argo", payload)
    raise KisamaError(f"未知操作: {args.action}")


def main() -> int:
    _ensure_utf8_stdio()
    parser = build_parser()
    args = parser.parse_args()
    try:
        result = asyncio.run(run(args))
        output(result, args.pretty)
        return 0
    except KeyboardInterrupt:
        return 130
    except KisamaError as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    except Exception as exc:
        print(json.dumps({"status": "error", "message": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
