#!/usr/bin/env python3
"""Kisama Agent controller.

This single-file controller handles ECDSA request signing, ECIES response
 decryption, AES-GCM request encryption, raw file transfer, and the Noise
 terminal protocol. It is intentionally dependency-light and exposes both a
Python API and a CLI for AI-driven control tasks.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import email.utils
import hashlib
import hmac
import json
import os
import re
import shlex
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Optional

# 核心依赖: ecdsa(纯Python)/cryptography(abi3 wheel)/noise/websockets —— 任意 CPython 含 3.14 免编译可装
try:
    from ecdsa import NIST256p, SigningKey
    from ecdsa.util import sigencode_der
    from noise.connection import Keypair, NoiseConnection
    import websockets
except ImportError as exc:
    raise SystemExit(
        "缺少控制端依赖。请安装："
        "python -m pip install ecdsa cryptography noiseprotocol websockets"
    ) from exc

# ============================================================================
# 远端条目"是不是目录"的判定标准 (跨实现, 规范见 docs/API.MD 三-4「列出文件/目录」)
#
# file/list 与部分实现的 file/authority 响应里 type 字段用词不统一:
#   go            : "dir"        / "file"
#   py            : "directory"  / "file" / "symlink"
#   js            : "directory"  / "file"
#   java / java11 : "directory " / "file "   (⚠️ 带尾随空格)
#   php (四变体)   : "directory"  / "file"
# 因此判断"是不是目录"必须 strip + 小写后比对集合, 且只白名单"目录"取值:
# 非目录(文件/符号链接/未知/缺失)一律按"不是目录"处理 —— 这是更安全的失败方向,
# 避免把已存在的文件当成目录, 使 <file>/<name> 被拼成嵌套路径写入。
# ============================================================================
_REMOTE_DIR_TYPE_VALUES = frozenset({"dir", "directory"})


def is_remote_dir_entry(entry: Any) -> bool:
    """判断 file/list 的一个条目是否为目录 (跨实现兼容, 规范见 docs/API.MD 三-4)。"""
    if not isinstance(entry, dict):
        return False
    value = entry.get("type")
    return isinstance(value, str) and value.strip().lower() in _REMOTE_DIR_TYPE_VALUES


# ============================================================================
# 大文件下载 (控制端): /api/file/download 无区间语义 (docs/API.MD 九, 请求体只有 path),
# 单次整取会把整个响应读进内存, 且超时此前按"假定 64MiB"计算、与文件真实大小无关。
# 这里在控制端补上自足的方案: 先用 file/list 的父目录条目预检真实大小 (协议无 stat 路由),
# 按真实字节数定超时; 大于 DOWNLOAD_CHUNK_DEFAULT 则走"远端切片 -> 逐片取回 -> 本地拼接
# -> 逐片删除"的内置流水线, 凭本地 .part 可续传, 远端峰值占用恒为一个分片。
# ============================================================================
DOWNLOAD_CHUNK_DEFAULT = 32 * 1024 * 1024
DOWNLOAD_DIRECT_ASSUMED = 64 * 1024 * 1024   # 预检失败时的兜底假定大小 (等价旧行为)
PARTS_ROOT = ".kisama_parts"                 # FILE_ROOT 下的临时分片目录


def _remote_join(root: str, *parts: str) -> str:
    """远端路径拼接 (分片流水线只在 POSIX 代理端使用, 统一 / 分隔)。"""
    base = (root or "").rstrip("/")
    for item in parts:
        item = (item or "").strip("/")
        if item:
            base = f"{base}/{item}"
    return base


def _safe_part_name(name: str) -> str:
    """把远端文件名压成可安全用于目录名的片段 (仅保留字母数字与 . _ -)。"""
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", name or "file")
    return cleaned[:64] or "file"


def _first_int(text: str) -> Optional[int]:
    """取输出里第一个整数 (兼容 `wc -c 路径` 的 "123 /path" 与 `wc -c <路径` 的 "123")。"""
    found = re.search(r"\d+", text or "")
    return int(found.group()) if found else None


# ============================================================================
# 原生加密库兼容层: coincurve/eciespy/pycryptodome 优先 (libsecp256k1 快),
# 缺失时 (如 Python 3.14 无 wheel、无编译工具链) 自动回退
# ecdsa(纯Python secp256k1 点运算) + cryptography(abi3 wheel AES-GCM)。
# 回退实现与 eciespy 线上格式逐字节兼容: eph_pub(65) + nonce(16) + tag(16) + ct
# ============================================================================
try:
    from ecies import decrypt as ecies_decrypt
except Exception:
    ecies_decrypt = None

try:
    import coincurve as _coincurve
except Exception:
    _coincurve = None

try:
    from Crypto.Cipher import AES  # noqa: F401  (原生优先, 缺失时下方垫片接管)
    from Crypto.Random import get_random_bytes as _native_random
    get_random_bytes = _native_random
except Exception:
    def get_random_bytes(n: int) -> bytes:
        return os.urandom(n)

    class _AESGCMCipherShim:
        def __init__(self, key: bytes, nonce: bytes):
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            self._aesgcm = AESGCM(key)
            self.nonce = nonce

        def encrypt_and_digest(self, plaintext: bytes):
            sealed = self._aesgcm.encrypt(self.nonce, plaintext, None)  # ct||tag
            return sealed[:-16], sealed[-16:]

        def decrypt_and_verify(self, ciphertext: bytes, tag: bytes) -> bytes:
            return self._aesgcm.decrypt(self.nonce, ciphertext + tag, None)

    class AES:
        MODE_GCM = "gcm"

        @staticmethod
        def new(key: bytes, mode, nonce: bytes = None):
            if nonce is None:
                raise ValueError("兼容垫片仅支持 AES-GCM 且必须提供 nonce")
            return _AESGCMCipherShim(key, nonce)

if ecies_decrypt is None:
    import hmac as _hmac_mod
    import hashlib as _hashlib_mod

    _SECP_P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F

    def _secp_decompress_pub(pub: bytes):
        from ecdsa import SECP256k1, VerifyingKey
        from ecdsa.ellipticcurve import Point
        if len(pub) == 65 and pub[0] == 0x04:
            return VerifyingKey.from_string(pub[1:], curve=SECP256k1).pubkey.point
        if len(pub) == 33 and pub[0] in (0x02, 0x03):
            x = int.from_bytes(pub[1:], "big")
            y_sq = (pow(x, 3, _SECP_P) + 7) % _SECP_P
            y = pow(y_sq, (_SECP_P + 1) // 4, _SECP_P)
            if y * y % _SECP_P != y_sq:
                raise ValueError("invalid compressed public key")
            if (y & 1) != (pub[0] - 0x02):
                y = _SECP_P - y
            return Point(SECP256k1.curve, x, y)
        raise ValueError("unsupported public key format")

    def _hkdf_sha256(master: bytes, length: int = 32) -> bytes:
        # 与 pycryptodome HKDF(master, len, salt=b"", SHA256) 一致 (info=空)
        prk = _hmac_mod.new(b"", master, _hashlib_mod.sha256).digest()
        okm = b""
        block = b""
        counter = 1
        while len(okm) < length:
            block = _hmac_mod.new(prk, block + bytes([counter]), _hashlib_mod.sha256).digest()
            okm += block
            counter += 1
        return okm[:length]

    def _secp_point_bytes(point) -> bytes:
        return b"\x04" + point.x().to_bytes(32, "big") + point.y().to_bytes(32, "big")

    def ecies_decrypt(secret: bytes, payload: bytes) -> bytes:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        if len(payload) < 97:
            raise ValueError("密文长度不合法")
        eph_pub, nonce, tag, ct = payload[:65], payload[65:81], payload[81:97], payload[97:]
        shared = _secp_point_bytes(_secp_decompress_pub(eph_pub) * int.from_bytes(secret, "big"))
        key = _hkdf_sha256(eph_pub + shared)
        return AESGCM(key).decrypt(nonce, ct + tag, None)


class _EciesKeyShim:
    """coincurve.PrivateKey 的最小兼容 (.secret)"""

    def __init__(self, secret: bytes):
        if len(secret) != 32:
            raise ValueError("ECIES 私钥必须为 32 字节")
        self.secret = secret


def _new_ecies_key(secret: bytes):
    """coincurve 优先, 缺失时回退垫片 (仅 .secret 属性)"""
    if _coincurve is not None:
        return _coincurve.PrivateKey(secret)
    return _EciesKeyShim(secret)


class KisamaError(RuntimeError):
    pass


class PreflightUncertainError(KisamaError):
    """大小预检"取不到信息"(而非"信息说它有问题"): 如旧代理 list 无 size 字段。

    download 的 auto/direct 模式下这类失败只降级为单次整取并回显 preflight_error;
    路径不存在、是目录等确定结论仍按 KisamaError 直接失败。
    """


class SplitUnavailableError(KisamaError):
    """分片前提不成立 (exec 不是 POSIX shell、远端不支持管道、FILE_ROOT 定位不到)。

    只在"一片字节都还没取回"时判定, 因此 auto 模式可以安全回退单次整取并在结果里
    留痕 split_fallback; 显式 --mode split 仍按错误硬失败, 不静默换路径。
    """


# 匿名时钟探测用浏览器 UA，避免被前置 CDN 拦截
_CLOCK_PROBE_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"


class KisamaClient:
    """Authenticated Kisama HTTP client with in-memory session state."""

    def __init__(
        self,
        base_url: str,
        ecdsa_key: str,
        ecies_key: str,
        timeout: float = 30.0,
        session_cache: Optional[str] = None,
        clock_offset: Optional[float] = None,
        insecure: bool = False,
    ) -> None:
        # 支持 "scheme://网关主机[:端口]#目标主机[/路径前缀]" 格式:
        # "#" 后的目标主机放入 X-Target-Host 头由网关路由, 路径前缀拼在所有请求路径之前
        self.target_host: Optional[str] = None
        self.path_prefix: str = ""
        if "#" in base_url:
            front, _, target = base_url.partition("#")
            target = target.strip("/")
            host, _, prefix = target.partition("/")
            if host:
                self.target_host = host
                self.path_prefix = f"/{prefix}" if prefix else ""
            base_url = front
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        # 🔓 insecure: 跳过服务端证书校验 (自签证书/证书链不完整的主机)。
        # None 时 urllib 与 websockets 走默认证书校验; 机密性仍由 TLS 承担, 但不验对端身份。
        self.insecure = bool(insecure)
        self.ssl_context: Optional[ssl.SSLContext] = None
        if self.insecure:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            self.ssl_context = ctx
        # 🔐 密钥改为惰性加载: DEBUG 模式代理 (x-encrypted: false) 无需密钥即可通信,
        # 启动阶段不得因缺钥/密钥无效而拦截 (否则连 baseinfo 探测都发不出去, 永远
        # 察觉不了对端是 DEBUG)。生产模式首次签名/解密时才加载并报错。
        self._ecdsa_raw = ecdsa_key
        self._ecies_raw = ecies_key
        self.ecdsa: Optional[SigningKey] = None
        self.ecies = None
        self._ecdsa_unavailable: bool = False   # 已尝试加载但失败/未提供, 避免重复告警
        self._ecies_unavailable: bool = False
        self.session_key_b64: Optional[str] = None
        self.session_key: Optional[bytes] = None
        self.noise_key: Optional[dict[str, Any]] = None
        self.baseinfo_data: Optional[dict[str, Any]] = None
        # 🔐 0.5.6 协议 (docs/API.MD 十二): 代理版本号 (baseinfo 响应携带)。
        # 版本数字前缀 >= 0.5.6 且非 baseinfo 端点的加密响应为 session_key AES-256-GCM;
        # baseinfo 恒为 ECIES; 版本未知/旧版按 ECIES 处理。
        self.agent_version: Optional[str] = None
        # 🌟 DEBUG 模式 (x-encrypted: false): 认证形同虚设, 所有响应为明文且恒不下发
        # session_key/noise_key (规范见 docs/API.MD 第十节)。明文 HTTP 业务 (exec/list/上传
        # 下载等) 照常可用; terminal 因无 noise_key/session_key 不可用。
        self.debug_mode: bool = False
        # 🌟 生产明文认证模式 (x-encrypted: plain, 仅 PHP 版提供, docs/API.MD 十): 认证与
        # ECDSA 验签照常强制, 但双向体加密关闭——请求体发明文 JSON (不发 X-AES-Encrypted),
        # 响应按明文 JSON 解析。代理端恒不下发 session_key/noise_key (据此判定, 与 DEBUG
        # 的区别是"缺密钥不是错误"且必须继续签名)。
        self.plain_mode: bool = False
        self.session_cache = session_cache or os.environ.get("KISAMA_SESSION_CACHE")
        self._cache_state = "none"  # "none" | "loaded" | "fresh"
        # 🔐 0.4.8 签名协议协商: "v2"=0.4.8 五段签名, "v1"=旧版 nonce+timestamp;
        # None=自动 (首次请求按 v2 发送, 401 则回退 v1 并记忆)。KISAMA_SIG_MODE 可强制。
        env_mode = os.environ.get("KISAMA_SIG_MODE", "").strip().lower()
        self._sig_mode_forced: bool = env_mode in ("v1", "v2")
        self._sig_mode: Optional[str] = env_mode if self._sig_mode_forced else None
        if self.session_cache:
            self._load_cache()
        # 时钟同步: 显式 offset 优先; 否则首次签名前自动探测服务器时间
        self._clock_offset = float(clock_offset) if clock_offset is not None else None
        self._clock_synced = False

    def _auth_timestamp(self) -> str:
        if self._clock_offset is None or not self._clock_synced:
            self._sync_clock()
        return str(int(time.time() + (self._clock_offset or 0.0)))

    def _sync_clock(self) -> None:
        """从服务器 Date 头读取时间偏移, 保证签名时间戳在认证窗口内."""
        if self._clock_offset is not None and self._clock_synced:
            return
        try:
            req = urllib.request.Request(
                f"{self.base_url}{self.path_prefix}/api/baseinfo",
                headers={
                    "Accept": "application/json",
                    "User-Agent": _CLOCK_PROBE_UA,
                    **({"X-Target-Host": self.target_host} if self.target_host else {}),
                },
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=10, context=self.ssl_context) as resp:
                date_str = resp.headers.get("Date", "")
            if date_str:
                # email.utils.parsedate_to_datetime 与 locale 无关 (strptime 的
                # %a/%b 在非英文 Windows 上可能解析失败)
                parsed = email.utils.parsedate_to_datetime(date_str)
                server_ts = parsed.timestamp()
                if self._clock_offset is None:
                    self._clock_offset = float(server_ts - int(time.time()))
        except Exception:
            if self._clock_offset is None:
                self._clock_offset = 0.0
        self._clock_synced = True

    @staticmethod
    def _read_secret(value: str) -> str:
        path = Path(value).expanduser()
        if path.is_file():
            return path.read_text(encoding="utf-8").strip()
        return value.strip()

    @classmethod
    def _maybe_ecdsa_scalar(cls, raw: str) -> Optional[SigningKey]:
        """短格式 ECDSA P-256 私钥 (0.5.8 tempkey format=short 下发): 64 位 hex 或
        Base64(32字节) 标量 → SigningKey; 非短格式返回 None, 格式像短格式但标量无效抛 KisamaError。"""
        compact = re.sub(r"\s+", "", raw)
        if re.fullmatch(r"[0-9a-fA-F]{64}", compact):
            try:
                return SigningKey.from_string(bytes.fromhex(compact), curve=NIST256p)
            except Exception as exc:
                raise KisamaError("无效的 64 位 hex ECDSA 私钥标量 (P-256)") from exc
        b64 = compact + "=" * (-len(compact) % 4)
        try:
            decoded = base64.b64decode(b64, validate=True)
        except Exception:
            return None
        if len(decoded) != 32:
            return None
        try:
            return SigningKey.from_string(decoded, curve=NIST256p)
        except Exception as exc:
            raise KisamaError("无效的 Base64(32字节) ECDSA 私钥标量 (P-256)") from exc

    @classmethod
    def _load_ecdsa_key(cls, value: str) -> SigningKey:
        raw = cls._read_secret(value)
        # 0.5.8 短格式优先识别 (tempkey format=short): 64 位 hex / Base64(32字节) 标量
        scalar = cls._maybe_ecdsa_scalar(raw)
        if scalar is not None:
            return scalar
        try:
            return SigningKey.from_pem(raw)
        except Exception:
            try:
                compact = "".join(
                    line.strip()
                    for line in raw.splitlines()
                    if not line.strip().startswith("-----")
                )
                der = base64.b64decode(compact, validate=True)
                try:
                    return SigningKey.from_der(der)
                except Exception:
                    if len(der) >= 3 and der[:2] == b"\x30\x81":
                        declared = der[2]
                        actual = len(der) - 3
                        if declared != actual and actual <= 255:
                            repaired = der[:2] + bytes([actual]) + der[3:]
                            return SigningKey.from_der(repaired)
                    raise
            except Exception as exc:
                raise KisamaError(f"无法加载 ECDSA 私钥: {value}") from exc

    @classmethod
    def _load_ecies_key(cls, value: str):
        raw = cls._read_secret(value)
        compact = re.sub(r"^0x", "", raw, flags=re.IGNORECASE).strip()
        if re.fullmatch(r"[0-9a-fA-F]{64}", compact):
            try:
                return _new_ecies_key(bytes.fromhex(compact))
            except Exception as exc:
                raise KisamaError("无法加载 ECIES 私钥：无效的 64 位 hex 私钥") from exc
        b64 = re.sub(r"\s+", "", compact)
        b64 += "=" * (-len(b64) % 4)
        try:
            decoded = base64.b64decode(b64, validate=True)
            if len(decoded) != 32:
                raise ValueError("长度不为 32 字节")
            return _new_ecies_key(decoded)
        except Exception as exc:
            raise KisamaError("无法加载 ECIES 私钥：需要 64 位 hex 或 Base64(32字节) 私钥") from exc

    def _ensure_ecdsa(self) -> Optional[SigningKey]:
        """惰性加载 ECDSA 私钥。缺钥/密钥无效时返回 None (不签名直发):
        DEBUG 模式代理全信任放行, 照常可用; 生产代理会 401, 属预期报错。"""
        if self.ecdsa is not None:
            return self.ecdsa
        if self._ecdsa_unavailable:
            return None
        raw = (self._ecdsa_raw or "").strip()
        if not raw or raw == "dummy":
            self._ecdsa_unavailable = True
            return None
        try:
            self.ecdsa = self._load_ecdsa_key(raw)
            return self.ecdsa
        except KisamaError:
            print(f"[warn] ECDSA 私钥无法加载 ({self._ecdsa_raw})，请求将不带签名直发（仅 DEBUG 代理可用）", file=sys.stderr)
            self._ecdsa_unavailable = True
            return None

    def _ensure_ecies(self):
        """惰性加载 ECIES 私钥。缺钥/密钥无效时返回 None (不解密, 明文透出):
        DEBUG 模式响应恒为明文, 照常可用; 生产加密响应会按原文解析失败, 属预期。"""
        if self.ecies is not None:
            return self.ecies
        if self._ecies_unavailable:
            return None
        raw = (self._ecies_raw or "").strip()
        if not raw or raw == "dummy" or re.fullmatch(r"0{4,}", raw):
            self._ecies_unavailable = True
            return None
        try:
            self.ecies = self._load_ecies_key(raw)
            return self.ecies
        except KisamaError:
            print(f"[warn] ECIES 私钥无法加载 ({self._ecies_raw})，响应将不解密直读（仅 DEBUG 代理可用）", file=sys.stderr)
            self._ecies_unavailable = True
            return None

    def _auth_headers(
        self, mode: str = "v2", method: str = "", path: str = "", sig_body: bytes = b""
    ) -> dict[str, str]:
        """生成签名请求头 (兼容 0.4.8 新签名与旧版签名).

        v2 (0.4.8+): message = METHOD\\nPATH\\nsha256hex(sig_body)\\nnonce\\ntimestamp
        v1 (0.4.7-): message = nonce + timestamp
        sig_body 为参与签名的请求体字节: AES 加密体签密文, 无体签 sha256(""),
        /api/fileraw (大文件裸流) 与 /api/proxy 数据面 (反代透传体任意二进制) 统一
        按空 body 摘要; /api/proxy/config 管理端点无特例 (0.6.7 续批四: 与十二节
        v2 规范一致签真实 body) —— 与服务端四端中间件及 tools/control.py
        build_signature_message 同口径 (docs/API.MD 二十)。
        ECDSA 私钥缺失/无效时不生成 X-Auth-Token 三件套 (DEBUG 代理免验签直连)。
        """
        # agent 验签路径不含 query (py/agent.py verify_signature: "请求路径 (不含 query)"),
        # 带 query 的请求 (如 /api/task/log/cron?limit=50) 签名前剥掉, URL 里保留。
        path = path.split("?", 1)[0]
        sign_key = self._ensure_ecdsa()
        if sign_key is None:
            return {
                "Accept": "application/json",
                "User-Agent": "KisamaPythonController/1.0",
            }
        nonce = base64.b64encode(os.urandom(16)).decode("ascii")
        timestamp = self._auth_timestamp()
        if mode == "v1":
            message = f"{nonce}{timestamp}".encode("utf-8")
        else:
            if path == "/api/fileraw" or (path.startswith("/api/proxy/") and path != "/api/proxy/config"):
                body_hash = hashlib.sha256(b"").hexdigest()  # 反代数据面透传体不参与签名 (path 已剥 query)
            else:
                body_hash = hashlib.sha256(sig_body if sig_body else b"").hexdigest()
            message = f"{method}\n{path}\n{body_hash}\n{nonce}\n{timestamp}".encode("utf-8")
        signature = sign_key.sign(
            message,
            hashfunc=hashlib.sha256,
            sigencode=sigencode_der,
        )
        return {
            "X-Nonce": nonce,
            "X-Timestamp": timestamp,
            "X-Auth-Token": base64.b64encode(signature).decode("ascii"),
            "Accept": "application/json",
            "User-Agent": "KisamaPythonController/1.0",
        }

    def _send_authenticated(self, method: str, path: str, build_fn, timeout: Optional[float] = None):
        """发送带签名的请求, 并在签名协议未知时自动完成 v2/v1 协商.

        首次请求按 v2 发送; 收到 401 时自动回退 v1 重试一次并记忆协商结果,
        之后固定使用该结果 (可用环境变量 KISAMA_SIG_MODE=v1|v2 跳过协商).
        build_fn(mode) -> (data, headers): mode 决定签名格式, data 为实际发送的请求体.
        """
        mode = self._sig_mode or "v2"
        data, headers = build_fn(mode)
        try:
            result = self._http(method, path, data, headers, timeout=timeout)
        except KisamaError as exc:
            if self._sig_mode is None and "HTTP 401" in str(exc):
                self._sig_mode = "v1"
                data, headers = build_fn("v1")
                result = self._http(method, path, data, headers, timeout=timeout)
            else:
                raise
        if self._sig_mode is None:
            self._sig_mode = "v2"
        return result

    def ws_downgrade_token(self) -> str:
        """0.4.8 明文降级模式令牌: Base64(HMAC-SHA256(session_key原始字节, "kisama-ws-token-v1")).

        0.4.8 起终端 WS 的 token 不再接受 agent 公钥; 旧版代理仍使用
        noise_key.agent.public 作为 token (两种写法均保留, 见 terminal 文档).
        """
        if self.session_key is None:
            raise KisamaError("无 session_key 可计算 WS 降级令牌 (DEBUG/plain 代理恒不下发 session_key, 不支持 terminal)")
        return base64.b64encode(
            hmac.new(self.session_key, b"kisama-ws-token-v1", hashlib.sha256).digest()
        ).decode("ascii")

    @staticmethod
    def _aes_encrypt(plain: bytes, key: bytes) -> bytes:
        cipher = AES.new(key, AES.MODE_GCM, nonce=get_random_bytes(12))
        ciphertext, tag = cipher.encrypt_and_digest(plain)
        payload = {
            "nonce": base64.b64encode(cipher.nonce).decode("ascii"),
            "tag": base64.b64encode(tag).decode("ascii"),
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
        }
        return base64.b64encode(
            json.dumps(payload, separators=(",", ":")).encode("utf-8")
        )

    @staticmethod
    def _aes_decrypt(payload_b64: bytes, key: bytes) -> bytes:
        """🔐 0.5.6 响应密文解密: Base64(JSON{nonce, tag, ciphertext}) -> 明文字节
        (与 _aes_encrypt 对称; 代理端 encryptData 输出同容器, docs/API.MD 十二)。"""
        payload = json.loads(base64.b64decode(payload_b64).decode("utf-8"))
        cipher = AES.new(key, AES.MODE_GCM, nonce=base64.b64decode(payload["nonce"]))
        return cipher.decrypt_and_verify(
            base64.b64decode(payload["ciphertext"]),
            base64.b64decode(payload["tag"]),
        )

    @staticmethod
    def _version_tuple(version: Optional[str]):
        """解析版本号数字前缀: "0.5.6-python" -> (0, 5, 6); 无法解析返回 None"""
        if not version:
            return None
        m = re.match(r"(\d+)\.(\d+)\.(\d+)", str(version))
        return tuple(int(g) for g in m.groups()) if m else None

    def _use_aes_response(self, path: str) -> bool:
        """🔐 0.5.6 协议 (docs/API.MD 十二): 代理版本数字前缀 >= 0.5.6 且请求路径非
        /api/baseinfo 时, 加密响应为 session_key AES-256-GCM; baseinfo 恒为 ECIES
        (密钥分发握手, 临时持有者也经它取得 session_key); 版本未知或旧版按 ECIES。"""
        if path.split("?", 1)[0].rstrip("/") == "/api/baseinfo":
            return False
        vt = self._version_tuple(self.agent_version)
        return vt is not None and vt >= (0, 5, 6)

    def _decode_response(self, body: bytes, headers: Any, status: int, path: str = "") -> Any:
        x_encrypted = str(headers.get("X-Encrypted", "")).lower()
        encrypted = x_encrypted == "true"
        # 🌟 运行模式位 (docs/API.MD 第十节): 响应恒为明文,
        # 不得进入 ECIES 解密分支; 首个响应即可信, 置位后全程按明文处理。
        if x_encrypted == "false":
            self.debug_mode = True
        elif x_encrypted == "plain":
            # 生产明文认证模式 (PHP 独有): 响应明文但签名照常, 不得判为 DEBUG
            self.plain_mode = True
        content_type = str(headers.get("Content-Type", "")).lower()

        if status >= 400:
            message = body.decode("utf-8", errors="replace")[:1000]
            encrypted = encrypted or (body.startswith(b"{") and b"_encrypted" in body[:256])
            ecies_key = self._ensure_ecies()
            attempts = [body.strip()]
            if body.startswith(b"{"):
                try:
                    attempts.append(json.loads(body).get("_encrypted", "").strip().encode())
                except Exception:
                    pass
            # 🔐 0.5.6: 非 baseinfo 的加密错误体优先按 session_key AES 解密 (失败回退 ECIES)
            try_aes_error = self._use_aes_response(path) and self.session_key is not None
            if try_aes_error or ecies_key is not None:
                for candidate in attempts:
                    if not candidate:
                        continue
                    if try_aes_error:
                        try:
                            message = self._aes_decrypt(candidate, self.session_key).decode("utf-8", errors="replace")[:1000]
                            break
                        except Exception:
                            pass
                    if ecies_key is None:
                        continue
                    try:
                        decrypted = ecies_decrypt(self.ecies.secret, base64.b64decode(candidate))
                        if not decrypted or decrypted.startswith(b"{"):
                            try:
                                inner = json.loads(decrypted).get("_encrypted")
                            except Exception:
                                inner = None
                            if inner:
                                message = ecies_decrypt(self.ecies.secret, base64.b64decode(inner)).decode("utf-8", errors="replace")[:1000]
                                break
                        message = decrypted.decode("utf-8", errors="replace")[:1000]
                        break
                    except Exception:
                        continue
            raise KisamaError(f"HTTP {status}: {message}")

        if "application/octet-stream" in content_type:
            return body

        # DEBUG 模式响应为明文 JSON, 直接解析 (与 encrypted=True 分支互斥)
        if encrypted and not self.debug_mode:
            if self._use_aes_response(path):
                # 🔐 0.5.6 (docs/API.MD 十二): 非 baseinfo 认证响应为 session_key AES-256-GCM
                if self.session_key is None:
                    raise KisamaError(
                        "代理 >= 0.5.6 响应使用 session_key AES 加密，但本地尚未取得 session_key"
                        "（请先完成 baseinfo 握手；控制端与代理版本混布时需成对升级）"
                    )
                try:
                    body = self._aes_decrypt(body.strip(), self.session_key)
                except Exception as exc:
                    raise KisamaError("AES 响应解密失败；请确认代理版本 >= 0.5.6 且已通过 baseinfo 取得 session_key") from exc
            else:
                ecies_key = self._ensure_ecies()
                if ecies_key is None:
                    raise KisamaError("代理返回了加密响应但未提供有效 ECIES 私钥（--ecies-key）；生产模式通信必须配置该密钥")
                try:
                    body = ecies_decrypt(self.ecies.secret, base64.b64decode(body.strip()))
                except Exception as exc:
                    raise KisamaError("ECIES 响应解密失败；请确认代理版本和控制端 ECIES 私钥匹配") from exc

        if not body:
            return None
        try:
            return json.loads(body.decode("utf-8"))
        except Exception:
            return {"raw": body.decode("utf-8", errors="replace")}

    def _http(
        self,
        method: str,
        path: str,
        body: Optional[bytes],
        headers: dict[str, str],
        timeout: Optional[float] = None,
    ) -> tuple[Any, Any, int]:
        request = urllib.request.Request(
            f"{self.base_url}{self.path_prefix}{path}",
            data=body,
            headers={
                **({"X-Target-Host": self.target_host} if self.target_host else {}),
                **headers,
            },
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout, context=self.ssl_context) as response:
                raw = response.read()
                return self._decode_response(raw, response.headers, response.status, path), response.headers, response.status
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            return self._decode_response(raw, exc.headers, exc.code, path), exc.headers, exc.code
        except urllib.error.URLError as exc:
            if isinstance(exc.reason, ssl.SSLCertVerificationError):
                raise KisamaError(
                    f"无法连接 Kisama 代理: 服务端 TLS 证书校验失败 ({exc.reason}); "
                    "自签/证书链不完整的主机可加 --insecure 跳过校验"
                ) from exc
            raise KisamaError(f"无法连接 Kisama 代理: {exc.reason}") from exc

    def _load_cache(self) -> None:
        """从缓存文件恢复 session_key/noise_key (代理重启后失效, 由调用方重试刷新)"""
        try:
            data = json.loads(Path(self.session_cache).expanduser().read_text(encoding="utf-8"))
            # 🌐 会话缓存绑定解析结果: 间接域名 (shz.al/~名称) 下代理重启会换隧道域名,
            # 解析地址变了就视为缓存失效 (交给 bootstrap 重握手), 避免拿旧代理的 session_key 打新代理。
            # 旧版缓存无该字段 (直连地址场景) 视为兼容, 照常接受。
            cached_resolved = data.get("resolved_url")
            if cached_resolved and cached_resolved != self.base_url:
                raise ValueError("会话缓存属于另一解析地址 (隧道域名已变更)")
            session_key_b64 = data.get("session_key")
            noise_key = data.get("noise_key")
            if not session_key_b64:
                raise ValueError("缓存缺少 session_key")
            session_key = base64.b64decode(session_key_b64, validate=True)
            if len(session_key) != 32:
                raise ValueError("session_key 长度错误")
            self.session_key_b64 = session_key_b64
            self.session_key = session_key
            # php 版代理无 noise_key, 允许缺失 (仅 terminal 需要)
            self.noise_key = noise_key if isinstance(noise_key, dict) else None
            self.baseinfo_data = data.get("baseinfo")
            # 🔐 0.5.6: 从缓存 baseinfo 恢复代理版本号 (判定响应解密算法)
            if isinstance(self.baseinfo_data, dict) and self.baseinfo_data.get("version"):
                self.agent_version = str(self.baseinfo_data.get("version"))
            self._cache_state = "loaded"
        except Exception:
            self._cache_state = "none"

    def save_cache(self) -> None:
        if not self.session_cache or self.session_key_b64 is None:
            return
        path = Path(self.session_cache).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(
                {
                    "session_key": self.session_key_b64,
                    "noise_key": self.noise_key,
                    "baseinfo": self.baseinfo_data,
                    "resolved_url": self.base_url,
                },
                ensure_ascii=False,
                separators=(",", ":"),
            ),
            encoding="utf-8",
        )
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass

    def _dynamic_timeout(self, size: int, base: Optional[float] = None) -> float:
        """按传输字节数放宽超时: 慢链路下小超时不再卡死大文件传输"""
        rate = 256 * 1024  # 保守 256KB/s
        return max(base or self.timeout, size / rate + 15)

    def bootstrap(self) -> dict[str, Any]:
        """Refresh session_key and noise_key from an authenticated baseinfo call."""
        data, _, _ = self._send_authenticated(
            "GET", "/api/baseinfo",
            lambda mode: (None, self._auth_headers(mode, "GET", "/api/baseinfo")),
        )
        # 🔐 兼容: baseinfo 是匿名白名单路由, 旧代理 (0.4.7-) 对无效签名不返回 401 而是
        # 按匿名放行 (响应无 session_key)。v2 首发失败时回退 v1 重试一次 (自动模式才回退;
        # 用户用 KISAMA_SIG_MODE 强制 v2 时不回退)。DEBUG 代理 (x-encrypted: false) 恒无
        # session_key, 属正常现象, 不得触发 v1 回退; 生产明文认证模式 (plain) 同理。
        if (
            isinstance(data, dict)
            and not data.get("session_key")
            and not self.debug_mode
            and not self.plain_mode
            and not self._sig_mode_forced
            and self._sig_mode != "v1"
        ):
            self._sig_mode = "v1"
            data, _, _ = self._send_authenticated(
                "GET", "/api/baseinfo",
                lambda mode: (None, self._auth_headers(mode, "GET", "/api/baseinfo")),
            )
        if not isinstance(data, dict):
            raise KisamaError("/api/baseinfo 没有返回 JSON 对象")

        # 🌟 DEBUG 模式 (x-encrypted: false) / 生产明文认证模式 (x-encrypted: plain):
        # session_key/noise_key 恒为 null (规范设计, docs/API.MD 第十节)。明文 HTTP 业务
        # 可用, 不视为错误; baseinfo 数据本身仍返回给调用方。两者的差别只在 DEBUG 不校验
        # 签名, plain 仍强制 ECDSA 验签 (后续请求照常签名)。
        if self.debug_mode or self.plain_mode:
            self.session_key_b64 = None
            self.session_key = None
            self.noise_key = None
            self.baseinfo_data = data
            # 🔐 0.5.6: 明文 baseinfo 同样携带 version (缓存供后续判定)
            if data.get("version"):
                self.agent_version = str(data.get("version"))
            self._cache_state = "fresh"
            return data

        session_key_b64 = data.get("session_key")
        if not session_key_b64:
            raise KisamaError("baseinfo 未返回 session_key；请确认请求使用了正确的 ECDSA 私钥")
        try:
            session_key = base64.b64decode(session_key_b64, validate=True)
        except Exception as exc:
            raise KisamaError("baseinfo 的 session_key 不是有效 Base64") from exc
        if len(session_key) != 32:
            raise KisamaError(f"baseinfo 的 session_key 长度错误：{len(session_key)}，应为 32 字节")

        # noise_key 可选: php 版代理不提供 (不支持 terminal), 仅在返回时校验结构
        noise_key = data.get("noise_key")
        if isinstance(noise_key, dict):
            controller = noise_key.get("controller") or {}
            agent = noise_key.get("agent") or {}
            if not controller.get("private") or not agent.get("public"):
                noise_key = None
        else:
            noise_key = None

        self.session_key_b64 = session_key_b64
        self.session_key = session_key
        self.noise_key = noise_key
        self.baseinfo_data = data
        # 🔐 0.5.6: 捕获代理版本号, 供后续非 baseinfo 响应的解密算法判定
        if data.get("version"):
            self.agent_version = str(data.get("version"))
        self._cache_state = "fresh"
        self.save_cache()
        return data

    def _ensure_session(self) -> None:
        if self.session_key is None and not (self.debug_mode or self.plain_mode):
            self.bootstrap()

    def request_json(self, method: str, path: str, payload: Any = None) -> Any:
        self._ensure_session()

        def build(mode: str):
            headers: dict[str, str] = {}
            body = None
            if payload is not None:
                if self.debug_mode or self.plain_mode or self.session_key is None:
                    # 🌟 DEBUG 模式: 无 session_key, 请求体按明文 JSON 直发
                    # (agent DEBUG 全信任放行, 不做 AES 解密)
                    # 🌟 plain 模式: 签名照常但请求体明文直发 (docs/API.MD 十)
                    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                else:
                    body = self._aes_encrypt(
                        json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                        self.session_key,
                    )
                    headers["X-AES-Encrypted"] = "true"
                headers["Content-Type"] = "application/json"
            # v2 签名覆盖实际发送的请求体 (AES 加密体签密文); 无体签 sha256("")
            headers.update(self._auth_headers(mode, method, path, body if body else b""))
            return body, headers

        data, _, _ = self._send_authenticated(method, path, build)
        return data

    def request_binary(self, method: str, path: str, payload: Any = None, timeout: Optional[float] = None) -> bytes:
        self._ensure_session()

        def build(mode: str):
            headers: dict[str, str] = {"Content-Type": "application/json"}
            body = None
            if payload is not None:
                if self.debug_mode or self.plain_mode or self.session_key is None:
                    # 🌟 DEBUG 模式 / plain 模式: 无 session_key, 请求体按明文 JSON 直发
                    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                else:
                    body = self._aes_encrypt(
                        json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                        self.session_key,
                    )
                    headers["X-AES-Encrypted"] = "true"
            headers.update(self._auth_headers(mode, method, path, body if body else b""))
            return body, headers

        data, _, _ = self._send_authenticated(method, path, build, timeout=timeout)
        if not isinstance(data, bytes):
            raise KisamaError(f"接口没有返回二进制内容: {data}")
        return data

    def proxy_relay(
        self,
        port: int,
        method: str = "GET",
        rest: str = "",
        body: Optional[bytes] = None,
        extra_headers: Optional[dict[str, str]] = None,
        out_file: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> dict[str, Any]:
        """📡 经 agent 本地反代路由透传一次 HTTP 请求 (ANY /api/proxy/{port}[/{rest}], 0.6.7).

        白名单唯一门禁 (匿名放行不验签, docs/API.MD 20.1): 不发认证三件套 —— 路由层
        本就会剥除认证头 (防签名材料泄漏给被代理服务), 不发是更干净的默认; 响应加密
        阶段对该前缀豁免, 上游字节原样返回, 因此这里不做任何解密/JSON 解包, 状态码
        与响应体照实上抛 (agent 门禁错误体 JSON 的 code/message 提升到输出顶层)。
        """
        method = method.upper()
        if method not in PROXY_METHODS:
            raise KisamaError(f"不支持的方法: {method} (反代路由支持 {'/'.join(PROXY_METHODS)})")
        rest = (rest or "").strip().lstrip("/")
        path = f"/api/proxy/{port}" + (f"/{rest}" if rest else "")
        headers = {"Accept": "*/*", "User-Agent": "KisamaPythonController/1.0"}
        for key, value in (extra_headers or {}).items():
            headers[key] = value
        if body is not None and not any(k.lower() == "content-type" for k in headers):
            headers["Content-Type"] = "application/octet-stream"
        request = urllib.request.Request(
            f"{self.base_url}{self.path_prefix}{path}",
            data=body,
            headers={**({"X-Target-Host": self.target_host} if self.target_host else {}), **headers},
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout or self.timeout, context=self.ssl_context) as response:
                raw = response.read()
                status = response.status
                resp_headers = {k.lower(): v for k, v in response.headers.items()}
        except urllib.error.HTTPError as exc:
            # 403/404/413/502 等门禁与转发错误是反代语义的一部分, 照实上抛不当作异常
            raw = exc.read()
            status = exc.code
            resp_headers = {k.lower(): v for k, v in (exc.headers or {}).items()}
        except urllib.error.URLError as exc:
            if isinstance(exc.reason, ssl.SSLCertVerificationError):
                raise KisamaError(
                    f"无法连接 Kisama 代理: 服务端 TLS 证书校验失败 ({exc.reason}); "
                    "自签/证书链不完整的主机可加 --insecure 跳过校验"
                ) from exc
            raise KisamaError(f"无法连接 Kisama 代理: {exc.reason}") from exc

        result: dict[str, Any] = {
            "action": "proxy",
            "port": port,
            "method": method,
            "path": path,
            "upstream_status": status,
            "ok": 200 <= status < 400,
            "content_type": resp_headers.get("content-type"),
            "body_size": len(raw),
        }
        if not result["ok"] and raw[:1] == b"{":
            try:
                err = json.loads(raw.decode("utf-8", errors="replace"))
            except Exception:
                err = None
            if isinstance(err, dict) and err.get("code"):
                result["code"] = err.get("code")
                result["message"] = err.get("message")
        if out_file:
            target = Path(out_file).expanduser()
            target.write_bytes(raw)
            result["saved_to"] = str(target)
            result["sha256"] = hashlib.sha256(raw).hexdigest()
            return result
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = None
        if text is not None:
            # 文本响应内联; 超上限截断并标注 (完整取回用 --out)
            if len(raw) > PROXY_INLINE_LIMIT:
                result["body"] = text[:PROXY_INLINE_LIMIT]
                result["body_truncated"] = True
            else:
                result["body"] = text
        elif len(raw) > PROXY_INLINE_LIMIT:
            result["body_omitted"] = True
            result["hint"] = "响应为二进制且超过内联上限, 加 --out 保存完整响应体 (输出含 sha256)"
        else:
            result["body_base64"] = base64.b64encode(raw).decode("ascii")
        return result

    def upload(self, local_file: str, remote_path: str, remote_name: Optional[str] = None, chunk_size: int = 8 * 1024 * 1024, timeout: Optional[float] = None) -> dict[str, Any]:
        # 🔐 0.5.6 协议 (docs/API.MD 十二): /api/fileraw 的响应也是 session_key AES 加密,
        # 必须先完成 baseinfo 握手取得 session_key 与代理版本号 (0.5.5- 响应为 ECIES,
        # 不握手也能解, 因此旧版不需要此调用; 缺了它 0.5.6+ 的上传会按 ECIES 解密失败)
        self._ensure_session()
        source = Path(local_file).expanduser()
        if not source.is_file():
            raise KisamaError(f"本地文件不存在: {source}")
        # 🌟 --remote-path 是"目标目录"（相对 FILE_ROOT），最终文件 = <remote-path>/<--name>。
        # 误传已存在的文件路径（如 --remote-path info.php）时，代理端会把 <dir>/<name> 拼成
        # "info.php/diag.php"——目录型代理 (go/py/js) 会尝试建目录但最终写出 nested 文件，
        # PHP 代理则把分片写进无法合并的隐藏暂存目录，恒返回 completed:false。
        # 列父目录探测 remote_path 末段是否为已存在文件，提前拦下给出明确指引。
        probe_dir, _, leaf = (remote_path or "").strip("/").rpartition("/")
        probe_dir = probe_dir or "."
        if leaf and leaf not in (".", ".."):
            try:
                listing = self.request_json("POST", "/api/file/list", {"path": probe_dir, "recursive": False})
            except KisamaError:
                listing = None  # 目录不存在等异常交由代理端上传时自行报错
            if isinstance(listing, dict) and isinstance(listing.get("files"), list):
                for entry in listing["files"]:
                    # type 用词跨实现不统一 (go "dir" / py·js·php "directory" / java "directory "),
                    # 统一按"是不是目录"判定, 说明见文件头的 _REMOTE_DIR_TYPE_VALUES
                    if entry.get("name") == leaf and not is_remote_dir_entry(entry):
                        raise KisamaError(
                            f"--remote-path '{remote_path}' 在远端是一个已存在的文件；"
                            f"该参数应为目标目录（最终文件 = 目录/--name）。"
                            f"要传到此目录或用新名字请写 --remote-path '.' --name '<目标文件名>'"
                        )
        remote_name = remote_name or source.name
        total_size = source.stat().st_size
        total_chunks = max(1, (total_size + chunk_size - 1) // chunk_size)
        chunk_timeout = timeout or self._dynamic_timeout(chunk_size)
        result: dict[str, Any] = {}

        with source.open("rb") as handle:
            for chunk_id in range(total_chunks):
                chunk = handle.read(chunk_size)
                if not chunk and total_size != 0:
                    raise KisamaError(f"读取本地文件时分片 {chunk_id} 为空")
                # 🔐 0.4.8: /api/fileraw 按约定签空体; 旧代理 v1 签名不涉及 body
                headers = self._auth_headers(self._sig_mode or "v2", "POST", "/api/fileraw", b"")
                headers.update({
                    "Accept": "application/json",
                    "Content-Type": "application/octet-stream",
                    "X-File-Path": urllib.parse.quote(remote_path, safe="/"),
                    "X-File-Name": urllib.parse.quote(remote_name, safe=""),
                    "X-Chunk-Id": str(chunk_id),
                    "X-Total-Chunks": str(total_chunks),
                })
                data, _, _ = self._http("POST", "/api/fileraw", chunk, headers, timeout=chunk_timeout)
                if not isinstance(data, dict):
                    raise KisamaError(f"上传分片 {chunk_id} 返回格式错误")
                result = data
        # 全部 5 端代理 (py/go/js/java) 与 PHP 代理在合并成功时都会置 completed:true;
        # 若末片返回后仍未合并 (completed:false)，说明分片被写进了无法合并的暂存目录，
        # 最常见原因是 --remote-path 误传了远端已存在的文件路径（应为目录）。此时不能
        # 把底层响应当成功透传给上层，必须报错以免 AI 误以为上传完成。
        if not result.get("completed"):
            raise KisamaError(
                f"上传分片已全部发出但代理端未完成合并 (completed=false: {result.get('message', '')})；"
                f"请确认 --remote-path 是目标目录（最终文件 = 目录/--name）而非已存在的文件路径，"
                f"可先 list 父目录确认后重试"
            )
        return result

    def exec_once(self, cmd: str, route: str = "/api/exec") -> tuple[int, str]:
        """跑一条远端命令并返回 (exitcode, 输出文本); 供下载分片等控制端流程使用。"""
        data = self.request_json("POST", route, {"cmd": cmd})
        if not isinstance(data, dict):
            raise KisamaError(f"exec 返回格式异常: {data!r}")
        try:
            code = int(data.get("exitcode"))
        except (TypeError, ValueError):
            code = -1
        out = data.get("result")
        return code, out if isinstance(out, str) else ""

    def file_stat(self, remote_path: str) -> dict[str, Any]:
        """预检远端单个文件的大小 (类型/不存在也在这里判掉)。

        协议没有 stat 路由, file/list 的父目录条目是唯一可用的元数据来源。
        """
        clean = (remote_path or "").strip().replace("\\", "/").strip("/")
        if not clean:
            raise KisamaError("远端文件路径不能为空")
        parent, _, leaf = clean.rpartition("/")
        listing = self.request_json("POST", "/api/file/list", {"path": parent or ".", "recursive": False})
        files = listing.get("files") if isinstance(listing, dict) else None
        if not isinstance(files, list):
            raise PreflightUncertainError(f"远端 file/list 未返回 files, 无法预检 {leaf} 的大小")
        for entry in files:
            if isinstance(entry, dict) and entry.get("name") == leaf:
                if is_remote_dir_entry(entry):
                    raise KisamaError(f"{clean} 在远端是目录: download 只取单个文件, 整目录请先 zip 再下载")
                size = entry.get("size")
                if isinstance(size, bool) or not isinstance(size, int):
                    raise PreflightUncertainError(f"远端 file/list 未给出 {clean} 的 size, 无法预检")
                return {"path": clean, "dir": parent or ".", "name": leaf, "size": size}
        raise KisamaError(f"远端文件不存在: {clean} (父目录 {parent or '.'} 的列表里没有该名字)")

    def discover_file_root(self, info: dict[str, Any], route: str = "/api/exec") -> str:
        """确定代理端 FILE_ROOT 的绝对路径 (分片要用它拼源文件路径与分片落地目录)。

        候选按 exec 的当前目录、$HOME 依次探测 (代理端 FILE_ROOT 的两种常见来源), 每个候选
        立刻用"该候选下同一相对路径的字节数 == file/list 报出的大小"校验, 通过即返回、不再
        探下一个; 全部对不上就报错, 不猜。
        """
        tried: list[str] = []
        for cmd in ("pwd", "printenv HOME"):
            code, out = self.exec_once(cmd, route)
            candidate = out.strip().splitlines()[0].strip() if code == 0 and out.strip() else ""
            if not candidate.startswith("/") or candidate in tried:
                continue
            tried.append(candidate)
            code, out = self.exec_once(f"wc -c {shlex.quote(_remote_join(candidate, info['path']))}", route)
            if code == 0 and _first_int(out) == info["size"]:
                return candidate
        raise SplitUnavailableError(
            f"未能确定代理端 FILE_ROOT 的绝对路径 (试过的候选: {tried or '无'}; 其下按相对路径取到的"
            "字节数都与 file/list 报出的大小不符)。分片下载要求 exec 能在 shell 里访问该文件: "
            "确认代理端 exec 可用且为 POSIX shell, 或用 --root-abs <FILE_ROOT 绝对路径> 指定; "
            "只想单次整取则用 --mode direct"
        )

    def _drop_remote_part(self, part_abs: Optional[str], exec_route: str, keep_parts: bool) -> None:
        """删除远端临时分片; 清理失败不掩盖下载结果 (分片留在 .kisama_parts 下可手工回收)。"""
        if keep_parts or not part_abs:
            return
        try:
            self.exec_once(f"rm -f {shlex.quote(part_abs)}", exec_route)
        except KisamaError:
            pass

    def _sweep_parts_dir(self, parts_rel: str) -> None:
        """分片判定不可用而回退时, 用文件 API 收掉刚为自己创建的临时目录。

        这类节点的 exec 做不了 rm/rmdir, 只剩文件 API 可用。只删本次自己的目录;
        父目录 .kisama_parts 可能正被别的下载共用, 仅在列表确认它为空时才删。
        """
        try:
            do_delete_paths(self, [parts_rel], None)
        except KisamaError:
            return
        try:
            listing = self.request_json("POST", "/api/file/list", {"path": PARTS_ROOT, "recursive": False})
        except KisamaError:
            return
        files = listing.get("files") if isinstance(listing, dict) else None
        if files != []:   # 还有别人的分目录/读不到列表 -> 只删自己的, 不动父目录
            return
        try:
            do_delete_paths(self, [PARTS_ROOT], None)
        except KisamaError:
            pass

    def download(
        self,
        remote_path: str,
        local_file: str,
        timeout: Optional[float] = None,
        chunk_size: int = DOWNLOAD_CHUNK_DEFAULT,
        mode: str = "auto",
        root_abs: Optional[str] = None,
        exec_route: str = "/api/exec",
        keep_parts: bool = False,
    ) -> dict[str, Any]:
        """下载远端单个文件: 先预检真实大小, 再按大小选择单次整取或分片流水线。

        auto 选到分片而分片前提不成立时 (Windows 代理、PHP 仿真层等无管道/非 POSIX shell
        的节点) 自动回退单次整取, 保持旧行为可用; 结果里的 split_fallback 写明原因。
        显式 --mode split 不回退, 直接报错。
        """
        chunk_size = max(1, int(chunk_size))
        auto_mode = mode == "auto"
        info: Optional[dict[str, Any]] = None
        preflight_error: Optional[str] = None
        split_fallback: Optional[str] = None
        try:
            info = self.file_stat(remote_path)
        except KisamaError as exc:
            # 显式 --mode direct 保持旧行为: 预检失败只记录进结果, 报错仍由代理端给出。
            # auto 下"取不到信息"(PreflightUncertain) 同样降级单次整取; "信息说它有问题"
            # (不存在/是目录) 则直接失败, 不再让请求打到代理端撞 400/404。
            if mode == "split":
                raise
            if mode == "direct":
                preflight_error = str(exc)
            elif isinstance(exc, PreflightUncertainError):
                mode, preflight_error = "direct", str(exc)
            else:
                raise
        if mode == "auto":
            mode = "split" if info is not None and info["size"] > chunk_size else "direct"
        if mode == "split":
            try:
                return self._download_split(
                    local_file, info, chunk_size, timeout, root_abs, exec_route, keep_parts
                )
            except SplitUnavailableError as exc:
                if not auto_mode:
                    raise
                split_fallback = str(exc)

        size = info["size"] if info is not None else None
        eff_timeout = timeout or self._dynamic_timeout(
            size if size is not None else DOWNLOAD_DIRECT_ASSUMED
        )
        data = self.request_binary("POST", "/api/file/download", {"path": remote_path}, timeout=eff_timeout)
        destination = Path(local_file).expanduser()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        result: dict[str, Any] = {"status": "ok", "path": str(destination), "size": len(data), "mode": "direct"}
        if size is not None:
            result["remote_size"] = size
        else:
            result["preflight_error"] = preflight_error
        if split_fallback is not None:
            result["split_fallback"] = split_fallback
        return result

    def _download_split(
        self,
        local_file: str,
        info: dict[str, Any],
        chunk_size: int,
        timeout: Optional[float],
        root_abs: Optional[str],
        exec_route: str,
        keep_parts: bool,
    ) -> dict[str, Any]:
        """分片流水线: 远端 tail|head 切片 -> 逐片取回 -> 本地 .part 拼接 -> 逐片删除远端分片。

        末片字节数与总长都按 file/list 预检的真实大小核对, 拼接结果不等于远端大小时保留 .part
        并报错, 以便修正后原地续传。
        """
        size = info["size"]
        dest = Path(local_file).expanduser()
        dest.parent.mkdir(parents=True, exist_ok=True)
        part_local = dest.with_name(dest.name + ".part")
        root = (root_abs or "").strip().rstrip("/") or self.discover_file_root(info, exec_route)
        src_abs = _remote_join(root, info["path"])
        digest = hashlib.sha256(f"{info['path']}\n{dest}".encode("utf-8")).hexdigest()[:12]
        parts_rel = _remote_join(PARTS_ROOT, f"{_safe_part_name(info['name'])}-{digest}")
        try:
            self.request_json("POST", "/api/file/new", {"path": parts_rel})
        except KisamaError as exc:
            if "HTTP 409" not in str(exc):   # 上次中断留下的目录, 续传时属正常前提
                raise
        total_chunks = (size + chunk_size - 1) // chunk_size
        start = 0
        if part_local.exists():
            start = min(part_local.stat().st_size // chunk_size, total_chunks) * chunk_size
            with part_local.open("r+b") as handle:
                handle.truncate(start)
        fetched = 0
        current_abs: Optional[str] = None
        unavailable: Optional[str] = None
        try:
            with part_local.open("ab" if start else "wb") as handle:
                for index in range(start // chunk_size, total_chunks):
                    offset = index * chunk_size
                    length = min(chunk_size, size - offset)
                    part_name = f"{index:05d}.part"
                    current_abs = _remote_join(root, parts_rel, part_name)
                    cut = (
                        f"tail -c +{offset + 1} {shlex.quote(src_abs)} | head -c {length}"
                        f" > {shlex.quote(current_abs)} && wc -c < {shlex.quote(current_abs)}"
                    )
                    code, out = self.exec_once(cut, exec_route)
                    reported = _first_int(out)
                    if code != 0 or reported != length:
                        detail = (
                            f"远端切第 {index} 片失败 (exitcode={code}, wc={reported}, 期望 {length} 字节; "
                            f"输出: {out.strip()[:200]})。分片要求代理端 exec 为 POSIX shell "
                            "(EXEC_SHELL=true, 需 tail/head/重定向); 单次整取请用 --mode direct"
                        )
                        if fetched == 0 and start == 0:
                            # 一片未取回、本地也没有既有进度 => 判定这台机器做不了分片。
                            # 先退出 with (Windows 上句柄未关闭时删不掉文件), 再由下面清理。
                            unavailable = detail
                            break
                        raise KisamaError(detail)
                    data = self.request_binary(
                        "POST", "/api/file/download",
                        {"path": _remote_join(parts_rel, part_name)},
                        timeout=timeout or self._dynamic_timeout(length),
                    )
                    if len(data) != length:
                        raise KisamaError(f"第 {index} 片取回 {len(data)} 字节, 与远端 {length} 字节不符")
                    handle.write(data)
                    handle.flush()
                    fetched += 1
                    self._drop_remote_part(current_abs, exec_route, keep_parts)
                    current_abs = None   # 已清理, 不再让 finally 重复发一条 rm
        finally:
            self._drop_remote_part(current_abs, exec_route, keep_parts)
            if not keep_parts:
                # 只 rmdir (空目录才删得掉), 绝不递归删远端目录, 避免误伤同名数据
                try:
                    self.exec_once(
                        f"rmdir {shlex.quote(_remote_join(root, parts_rel))} "
                        f"{shlex.quote(_remote_join(root, PARTS_ROOT))}",
                        exec_route,
                    )
                except KisamaError:
                    pass
        if unavailable is not None:
            if part_local.exists():
                part_local.unlink()   # 0 字节空壳, 回退路径不需要它
            if not keep_parts:
                self._sweep_parts_dir(parts_rel)
            raise SplitUnavailableError(unavailable)
        written = part_local.stat().st_size
        if written != size:
            raise KisamaError(
                f"拼接结果 {written} 字节, 与远端 {size} 字节不符; 已保留 {part_local} 供修正后续传"
            )
        os.replace(part_local, dest)
        return {
            "status": "ok",
            "path": str(dest),
            "size": written,
            "mode": "split",
            "remote_size": size,
            "chunk_size": chunk_size,
            "parts_total": total_chunks,
            "parts_fetched": fetched,
            "resumed_bytes": start,
            "parts_dir": parts_rel,
            "parts_kept": keep_parts,
        }


    async def terminal(
        self,
        command: Optional[str] = None,
        raw_input: Optional[str] = None,
        request_id: Optional[str] = None,
        token: Optional[str] = None,
        rows: int = 24,
        cols: int = 80,
        timeout: float = 60.0,
    ) -> dict[str, Any]:
        """超级终端 (带 0.4.8 密钥轮换恢复).

        token 取值兼容两种代理:
          - 0.4.8+: 传 "auto" 或 self.ws_downgrade_token() (HMAC(session_key));
          - 0.4.7-: 传 noise_key.agent.public (旧行为不变);
          - None:   走 Noise 加密模式 (两端通用).
        0.4.8 代理在 tempkey 过期时会轮换 session_key/控制端密钥对: 首次尝试若因
        Noise 公钥不匹配或 token 校验失败 (close 1008) 失败, 自动重拉 baseinfo
        刷新密钥后重试一次。
        """
        self._ensure_session()
        # 🌟 DEBUG / plain 代理: baseinfo 恒无 noise_key (规范设计), 无法建立 Noise/Token 终端会话。
        # 提前给出明确指引, 避免深入 WS 握手后报出晦涩的密钥错误。
        if (self.debug_mode or self.plain_mode) and self.noise_key is None:
            mode_tag = "DEBUG (x-encrypted: false)" if self.debug_mode else "生产明文认证 (x-encrypted: plain)"
            raise KisamaError(f"该代理处于 {mode_tag} 模式，不下发 session_key/noise_key，不支持 terminal；请改用 exec")
        if token == "auto":
            token = self.ws_downgrade_token()
        try:
            return await self._terminal_once(command, raw_input, request_id, token, rows, cols, timeout)
        except Exception as exc:
            msg = str(exc)
            stale_key = "不匹配" in msg or "1008" in msg
            if stale_key:
                self.bootstrap()
                return await self._terminal_once(command, raw_input, request_id, token, rows, cols, timeout)
            raise

    async def _terminal_once(
        self,
        command: Optional[str] = None,
        raw_input: Optional[str] = None,
        request_id: Optional[str] = None,
        token: Optional[str] = None,
        rows: int = 24,
        cols: int = 80,
        timeout: float = 60.0,
    ) -> dict[str, Any]:
        self._ensure_session()
        request_id = request_id or f"kisama-{uuid.uuid4().hex}"
        query = {"request_id": request_id, "meta": "1"}
        if token:
            query["token"] = token
        scheme = "wss" if self.base_url.startswith("https://") else "ws"
        host_url = self.base_url.replace("https://", f"{scheme}://", 1).replace("http://", f"{scheme}://", 1)
        ws_url = f"{host_url}{self.path_prefix}/api/ws/terminal?{urllib.parse.urlencode(query)}"
        ws_headers = {"X-Target-Host": self.target_host} if self.target_host else None
        # websockets 只接受 wss 上的 ssl 参数 (ws:// 传入会直接报错), 且非 insecure 时保持默认校验
        ws_kwargs: dict[str, Any] = {}
        if self.ssl_context is not None and scheme == "wss":
            ws_kwargs["ssl"] = self.ssl_context

        async with websockets.connect(ws_url, ping_interval=20, ping_timeout=10, max_size=2**22, additional_headers=ws_headers, **ws_kwargs) as websocket:
            cipher: Optional[NoiseConnection] = None
            if not token:
                if not isinstance(self.noise_key, dict):
                    raise KisamaError("该代理未提供 noise_key (常见于 php 版代理)，不支持 terminal，请改用 exec")
                controller_private = base64.b64decode(self.noise_key["controller"]["private"])
                expected_agent_public = base64.b64decode(self.noise_key["agent"]["public"])
                cipher = NoiseConnection.from_name(b"Noise_XX_25519_ChaChaPoly_BLAKE2s")
                cipher.set_as_initiator()
                cipher.set_keypair_from_private_bytes(Keypair.STATIC, controller_private)
                cipher.set_prologue(b"kisama_terminal_v1")
                cipher.start_handshake()
                await websocket.send(cipher.write_message(b""))
                msg2 = await websocket.recv()
                cipher.read_message(msg2 if isinstance(msg2, bytes) else msg2.encode())
                try:
                    remote_public = cipher.noise_protocol.handshake_state.rs.public_bytes
                except AttributeError as exc:
                    raise KisamaError("Noise 库无法读取代理静态公钥，拒绝继续") from exc
                if remote_public != expected_agent_public:
                    raise KisamaError("Noise 握手中代理静态公钥不匹配")
                await websocket.send(cipher.write_message(b""))
                if not cipher.handshake_finished:
                    raise KisamaError("Noise 握手未完成")

            async def send_payload(payload: bytes) -> None:
                await websocket.send(cipher.encrypt(payload) if cipher else payload)

            async def recv_plain(timeout_s: float) -> bytes:
                msg = await asyncio.wait_for(websocket.recv(), timeout=timeout_s)
                if isinstance(msg, str):
                    msg = msg.encode("utf-8")
                return cipher.decrypt(msg) if cipher else msg

            # 🔤 shell 自适配 (0.5.8): meta=1 请求 welcome 元数据帧 (0.5.5+, 先于 PTY 首字节)，
            # 拿到 shell 类型再注入命令——Windows 代理 PTY 是 PowerShell，POSIX 标记包装必超时。
            # 老代理无 welcome 帧: 首帧即 PTY 数据，落缓冲后按 baseinfo os 兜底判断。
            shell_kind: Optional[str] = None
            output = bytearray()
            try:
                while True:
                    first_plain = await recv_plain(1.5)
                    try:
                        obj = json.loads(first_plain.decode("utf-8"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        output.extend(first_plain)
                        break
                    if obj.get("type") == "welcome":
                        shell_kind = _resolve_terminal_shell(str(obj.get("shell") or ""), None)
                        continue
                    if obj.get("type") == "heartbeat":
                        continue
                    output.extend(first_plain)
                    break
            except asyncio.TimeoutError:
                pass
            if shell_kind is None:
                shell_kind = _resolve_terminal_shell(None, (self.baseinfo_data or {}).get("os"))

            async def heartbeat() -> None:
                while True:
                    await asyncio.sleep(10)
                    await send_payload(b'{"type":"heartbeat"}')

            heartbeat_task = asyncio.create_task(heartbeat())
            try:
                marker = f"__KISAMA_DONE__{uuid.uuid4().hex}"
                # resize 先于命令注入: 避免执行期 conpty 重绘把 ANSI 序列插进标记输出破坏匹配
                await send_payload(json.dumps({"type": "resize", "rows": rows, "cols": cols}, separators=(",", ":")).encode("utf-8"))
                if command is not None:
                    payload = {
                        "type": "input",
                        "data": base64.b64encode(_terminal_command_payload(command, marker, shell_kind)).decode("ascii"),
                        "encoding": "base64",
                    }
                    await send_payload(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
                    # 不要求行首 \n: 回显行内标记后跟的是未求值文本 (冒号后非数字), 本就不会误匹配;
                    # 这样即使 PSReadLine 续行提示符/重绘把标记顶到行中也能匹配
                    pattern = re.compile(re.escape(marker.encode()) + rb":(\d+)__\r?\n")
                elif raw_input is not None:
                    await send_payload(raw_input.encode("utf-8"))
                    pattern = None
                else:
                    raise KisamaError("terminal 必须提供 command 或 raw_input")

                exitcode: Optional[int] = None
                started = time.monotonic()
                while time.monotonic() - started < timeout:
                    remaining = max(0.1, timeout - (time.monotonic() - started))
                    try:
                        message = await asyncio.wait_for(websocket.recv(), timeout=remaining)
                    except asyncio.TimeoutError:
                        break
                    if isinstance(message, str):
                        message = message.encode("utf-8")
                    plain = cipher.decrypt(message) if cipher else message
                    try:
                        obj = json.loads(plain.decode("utf-8"))
                        if obj.get("type") in ("heartbeat", "welcome"):
                            continue
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        pass
                    output.extend(plain)
                    if pattern:
                        # 匹配在剥离 ANSI/OSC 序列后的缓冲上进行 (conpty 重绘会把光标序列
                        # 插进标记文本中间, 原始字节流上匹配会随时序抖动)
                        searchable = _TERMINAL_ANSI_RE.sub(b"", bytes(output))
                        match = pattern.search(searchable)
                        if match:
                            exitcode = int(match.group(1))
                            text = searchable[:match.start()].decode("utf-8", errors="replace")
                            return {
                                "status": "ok",
                                "request_id": request_id,
                                "output": text,
                                "exitcode": exitcode,
                            }
                text = output.decode("utf-8", errors="replace")
                return {
                    "status": "ok" if (pattern is None or exitcode is not None) else "timeout",
                    "request_id": request_id,
                    "output": text,
                    "exitcode": exitcode,
                }
            finally:
                heartbeat_task.cancel()
                try:
                    await heartbeat_task
                except asyncio.CancelledError:
                    pass


def parse_pairs(values: list[str], label: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise KisamaError(f"{label} 参数必须是 key=value: {value}")
        key, val = value.split("=", 1)
        if not key:
            raise KisamaError(f"{label} 的 key 不能为空")
        result[key] = val
    return result


# 📡 本地端口反代 (0.6.7 起, docs/API.MD 二十): agent 路由支持的方法与控制端响应内联上限
PROXY_METHODS = ("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS")
PROXY_INLINE_LIMIT = 64 * 1024


def parse_port_list(text: str) -> list[int]:
    """解析 --ports '8080,9090' / '8080 9090' 为端口整数列表 (逐项 1~65535 校验).

    服务端对非法/越界条目静默过滤 (docs/API.MD 20.8), 客户端这里宁可先报错 ——
    多半是手误, 静默过滤会让"想开的端口没开"不被察觉。
    """
    ports: list[int] = []
    for token in re.split(r"[,\s]+", (text or "").strip()):
        if not token:
            continue
        try:
            value = int(token)
        except ValueError:
            raise KisamaError(f"端口不是数字: {token!r} (--ports 期望逗号/空格分隔的整数)")
        if not 1 <= value <= 65535:
            raise KisamaError(f"端口越界: {value} (合法范围 1~65535)")
        ports.append(value)
    if not ports:
        raise KisamaError("--ports 不能为空 (例: --ports '8080,9090')")
    return ports


def output(value: Any, pretty: bool = False) -> None:
    if isinstance(value, bytes):
        sys.stdout.buffer.write(value)
        return
    print(json.dumps(value, ensure_ascii=False, indent=2 if pretty else None, default=str))


def _ensure_utf8_stdio() -> None:
    """Windows 控制台默认编码可能是 GBK/cp1252, 打印中文 JSON 会抛
    UnicodeEncodeError（Linux/macOS 默认 UTF-8 无此问题）。这里强制 UTF-8。"""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass


# ============================================================================
# 🔗 Kisama 分享链接 (kisama://) 与连接档案 (0.5.8)
# ============================================================================
# 链接格式 (脚本为权威解析器, 兼容两种生成端写法):
#   kisama://node?domain=<值>&ecdsaprikey=<64位hex>&eciesprikey=<64位hex>[&tls=1][&扩展参数...]
# - 值先手工按 & 与第一个 = 切分, 再做百分号解码 (unquote, 不转 + 为空格):
#   生成端既可标准 URL 编码 (domain=https%3A%2F%2F...%23...), 也可原样携带 '#' 直接传
# - domain: host[:port] (缺省拼 http://) 或完整 URL (http(s):// 开头则原样, 可含 # 网关路由);
#   tls=1 / secure=1 → 强制 https:// 前缀
# - domain 允许为间接域名: https://shz.al/~<KNAME> (KMODE=2 静默上报的名称解析入口,
#   见 is_indirect_url/resolve_indirect_url)——不是代理本身, 每次建连前先 GET 解析出真实地址
# - ecdsaprikey: P-256 私钥标量 64 位 hex (tempkey?format=short 下发, 兼容 Base64(32字节))
# - eciesprikey: 64 位 hex (兼容 Base64(32字节))
# - 未知参数不报错, 原样存入连接档案 extra 字段 (前向兼容)
# - netloc (node) 不参与语义; 链接两端空白容忍
CONNECT_REQUIRED_PARAMS = ("domain", "ecdsaprikey", "eciesprikey")

# 终端输出中的 ANSI CSI/OSC 控制序列 (done 标记匹配前剥离, conpty 重绘会插在任意字节之间)
_TERMINAL_ANSI_RE = re.compile(rb"\x1b\[[0-9;?]*[a-zA-Z]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")


def parse_share_link(link: str) -> dict[str, Any]:
    """解析 kisama:// 分享链接 → {url, ecdsa_key, ecies_key, insecure, extra}。

    手工按 & 与第一个 = 切分键值 (不经 parse_qs, 因此值内的 '#' 不会被误当片段),
    再对值做 unquote 百分号解码 (不转 + 为空格, 兼容 Base64 密钥材料)——
    已编码与原样两种生成端写法均可。缺必填参数抛 KisamaError 并指出缺哪个。
    """
    raw = (link or "").strip()
    if not raw.lower().startswith("kisama://"):
        raise KisamaError("分享链接必须以 kisama:// 开头")
    _, _, query = raw.partition("?")
    if not query:
        raise KisamaError("分享链接缺少查询参数 (kisama://node?domain=...&ecdsaprikey=...&eciesprikey=...)")
    params: dict[str, str] = {}
    for pair in query.split("&"):
        if not pair:
            continue
        key, sep, value = pair.partition("=")
        if not sep:
            continue
        params[key.strip()] = urllib.parse.unquote(value.strip())

    missing = [name for name in CONNECT_REQUIRED_PARAMS if not params.get(name)]
    if missing:
        raise KisamaError("分享链接缺少参数: " + ", ".join(missing))

    domain = params["domain"]
    force_tls = params.get("tls", "").lower() in ("1", "true", "yes") or params.get("secure", "").lower() in ("1", "true", "yes")
    if domain.lower().startswith(("http://", "https://")):
        url = domain
    elif force_tls:
        url = f"https://{domain}"
    else:
        url = f"http://{domain}"

    insecure = params.get("insecure", "").lower() in ("1", "true", "yes")
    extra = {k: v for k, v in params.items()
             if k not in CONNECT_REQUIRED_PARAMS and k not in ("tls", "secure", "insecure")}
    return {
        "url": url,
        "ecdsa_key": params["ecdsaprikey"],
        "ecies_key": params["eciesprikey"],
        "insecure": insecure,
        "extra": extra,
    }


# 🌐 间接域名 (KMODE=2 shz.al 静默上报): domain=https://shz.al/~<KNAME> 不是代理本身,
# 而是名称解析入口——GET 该 URL 的响应体 (trim 后) 即真实代理地址 (形如 https://xxxx.trycloudflare.com)。
# 代理每次重启会覆盖更新同一 URL 的值 (409→PUT, 预测 URL 永远指向最新域名), 未上报时 404,
# 上报值 7 天后自动过期 (语义见仓库 README「开启 KMODE 后如何查看临时域名」)。
# 因此控制端必须在每次建连前解析, 不能只在 connect 时解析一次:
# 档案保存入口 URL, 会话缓存绑定解析结果 (代理重启换隧道域名后缓存自动失效重握手)。
INDIRECT_URL_HOST_SUFFIX = "shz.al"
_INDIRECT_RESOLVE_TIMEOUT = 15.0


def is_indirect_url(url: Optional[str]) -> bool:
    """判定 URL 是否为 shz.al/~名称 形式的间接解析入口 (而非代理本身)。

    仅按形态判定: http(s) scheme + 主机为 shz.al (含子域) + 路径以 /~ 开头。
    '#' 网关路由与该特性互斥 (主机位是网关时不会命中)。
    """
    raw = str(url or "").strip()
    if not raw.lower().startswith(("http://", "https://")):
        return False
    parts = urllib.parse.urlsplit(raw)
    host = (parts.hostname or "").lower()
    if host != INDIRECT_URL_HOST_SUFFIX and not host.endswith("." + INDIRECT_URL_HOST_SUFFIX):
        return False
    name = parts.path.lstrip("/")
    return name.startswith("~") and len(name) > 1


def resolve_indirect_url(url: str, timeout: float = _INDIRECT_RESOLVE_TIMEOUT, insecure: bool = False) -> str:
    """解析 shz.al/~名称 间接域名 → 真实代理地址。

    GET 入口 URL, 响应体 trim 后必须是以 http(s):// 开头的地址, 否则报错并给出指引。
    404 = 尚未上报或已过期 (代理未启动/KNAME 不符/超 7 天), 语义见模块注释。
    """
    ctx = None
    if insecure:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(
        url,
        headers={"Accept": "text/plain", "User-Agent": _CLOCK_PROBE_UA},
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            body = resp.read().decode("utf-8", errors="replace").strip()
            status = resp.status
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", errors="replace").strip()[:200]
        except Exception:
            pass
        if exc.code == 404:
            raise KisamaError(
                f"间接域名 {url} 尚未上报隧道域名 (404): 代理未启动/未完成上报, KNAME 不符, 或上报值已过期 (7 天)。"
                "代理每次重启会自动覆盖更新同一 URL 的值, 确认代理以 KMODE=2 + 该 KNAME 运行后稍候重试"
            ) from exc
        raise KisamaError(f"间接域名 {url} 解析失败: HTTP {exc.code} {detail}") from exc
    except urllib.error.URLError as exc:
        raise KisamaError(f"间接域名 {url} 无法访问: {exc.reason}") from exc
    if status != 200 or not body:
        raise KisamaError(f"间接域名 {url} 响应异常 (HTTP {status}, 响应体为空)")
    if not body.lower().startswith(("http://", "https://")):
        raise KisamaError(
            f"间接域名 {url} 的响应体不是代理地址 (得到: {body[:120]!r}); "
            "确认该 KNAME 对应的代理以 KMODE=2 上报 (响应体应为形如 https://xxxx.trycloudflare.com 的隧道域名)"
        )
    return body


def _resolve_terminal_shell(shell_name: Optional[str], baseinfo_os: Optional[str]) -> str:
    """归一化终端 shell 类型 → "powershell" | "cmd" | "posix"。

    优先取 welcome 元数据帧 (0.5.5+, meta=1) 上报的 shell 归一化名 (powershell/pwsh/cmd/bash...)；
    无帧时 (旧代理) 按 baseinfo os 字段兜底 —— 各语言 Windows 代理 PTY 均优先 PowerShell。
    """
    name = (shell_name or "").strip().lower()
    if name.startswith("powershell") or name == "pwsh":
        return "powershell"
    if name == "cmd":
        return "cmd"
    if name:
        return "posix"
    return "powershell" if "windows" in str(baseinfo_os or "").lower() else "posix"


def _terminal_command_payload(command: str, marker: str, shell_kind: str) -> bytes:
    r"""构造"用户命令 + done 标记"注入载荷 (按 shell 自适配)。

    marker 为完整标记串 (__KISAMA_DONE__<uuid>)。
    - posix: printf + "$?" (现状, Linux 全家桶)
    - powershell: 无 printf 命令、"$?" 是布尔、且 LF 不是 Enter (PSReadLine 视为续行) ——
      必须 CRLF 行尾 + Write-Output + "$?" 布尔转 0/1 (实测 $LASTEXITCODE 在部分环境展开为空)
    - cmd: echo. 空行 + %errorlevel% 展开
    标记的回显行内是未求值文本 (冒号后无纯数字), 不会误触发匹配模式中的 (\d+)。
    """
    if shell_kind == "powershell":
        # 单语句: "$(if ($?) ...)" 在字符串构造时求值, 此时前一语句正是用户命令;
        # 若前面再插任何语句 (如空行 Write-Output '') 会把 $? 重置为 True → 退码恒 0。
        return (
            f"{command}\r\n"
            f"Write-Output \"{marker}:$(if ($?) {{0}} else {{1}})__\"\r\n"
        ).encode("utf-8")
    if shell_kind == "cmd":
        return (
            f"{command}\r\n"
            f"echo.\r\necho {marker}:%errorlevel%__\r\n"
        ).encode("utf-8")
    return (
        f"{command}\n"
        f"printf '\\n{marker}:%s__\\n' \"$?\"\n"
    ).encode("utf-8")


def _profile_path(name_or_path: Optional[str]) -> Path:
    """解析连接档案路径: 缺省 ~/.kisama/profile.json; 传名称 → ~/.kisama/profiles/<名>.json;
    传 .json 路径 (绝对或相对) 原样。"""
    base = Path.home() / ".kisama"
    raw = (name_or_path or "").strip()
    if not raw:
        return base / "profile.json"
    p = Path(raw)
    if p.suffix == ".json" or str(p.parent) not in (".", ""):
        return p if p.is_absolute() else Path.cwd() / p
    return base / "profiles" / f"{raw}.json"


def load_profile(name_or_path: Optional[str] = None) -> Optional[dict[str, Any]]:
    """读取连接档案; 缺失/损坏/无 url 返回 None (绝不抛错, 档案仅是便捷层)。"""
    try:
        data = json.loads(_profile_path(name_or_path).read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(data, dict) or not data.get("url"):
        return None
    return data


def save_profile(name_or_path: Optional[str], profile: dict[str, Any]) -> Path:
    """写入连接档案 (JSON, UTF-8), POSIX 下收敛权限为 0600 (Windows 忽略)。"""
    path = _profile_path(name_or_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return path


def delete_profile(name_or_path: Optional[str] = None) -> bool:
    """删除连接档案及同名会话缓存; 档案不存在返回 False。"""
    path = _profile_path(name_or_path)
    removed = False
    for target in (path, Path(str(path) + ".session.json")):
        try:
            target.unlink()
            removed = True
        except OSError:
            pass
    return removed


def _mask_secret(value: Optional[str]) -> str:
    if not value:
        return "(未配置)"
    if len(value) <= 10:
        return value[:3] + "***"
    return f"{value[:6]}...{value[-4:]} (len={len(value)})"


def _is_share_link(raw: str) -> bool:
    return (raw or "").strip().lower().startswith("kisama://")


def resolve_connection(args: argparse.Namespace) -> None:
    """就地补全 args.url / args.ecdsa_key / args.ecies_key / args.session_cache / args.insecure。

    优先级: CLI 显式 > --node/KISAMA_NODE > --link/KISAMA_LINK > 环境变量 > 连接档案。
    --node 是"本次命令连哪台"的最高层来源: 给它整条 kisama:// 分享链接或档案名称/路径即可
    免 connect 直连, 且会屏蔽 --link、环境变量与 connect 写下的缺省档案, 便于同时操作多台代理。
    档案存在且未 --no-session-cache 时, 会话缓存默认启用 (档案同名 .session.json)。
    """
    node_raw = (getattr(args, "node", None) or "").strip()
    node: Optional[dict[str, Any]] = None
    node_profile_path: Optional[Path] = None
    if node_raw:
        if _is_share_link(node_raw):
            node = parse_share_link(node_raw)   # 显式指定的链接: 解析失败当场报错, 不静默降级
        else:
            node_profile_path = _profile_path(node_raw)
            node = load_profile(node_raw)
            if node is None:
                raise KisamaError(f"连接档案不存在或不可读: {node_profile_path} (先 connect --profile {node_raw} 建档, 或直接传 kisama:// 分享链接)")

    profile = None if node else load_profile(args.profile)
    link_raw = None if node else (getattr(args, "link", None) or os.environ.get("KISAMA_LINK"))
    link = parse_share_link(link_raw) if link_raw else None
    if link_raw and link is None:
        link = {}

    def pick(attr: str, env: str, link_key: str, profile_key: str) -> None:
        value = getattr(args, attr, None)
        if value:
            return
        if node and node.get(link_key):
            value = node[link_key]
        elif not node:
            # --node 存在时 --link 与环境变量一律让位 (防止残留 KISAMA_URL 把命令打到另一台代理)
            if link and link.get(link_key):
                value = link[link_key]
            if not value:
                value = os.environ.get(env)
            if not value and profile:
                value = profile.get(profile_key)
        setattr(args, attr, value or None)

    pick("url", "KISAMA_URL", "url", "url")
    pick("ecdsa_key", "KISAMA_ECDSA_KEY", "ecdsa_key", "ecdsa_key")
    pick("ecies_key", "KISAMA_ECIES_KEY", "ecies_key", "ecies_key")

    # 🔓 证书校验开关: CLI --insecure / KISAMA_INSECURE 已在 parser 默认值里生效,
    # 这里只补齐更低优先级的来源 (--node 链接/档案、link insecure=1、连接档案)。
    if not getattr(args, "insecure", False):
        args.insecure = bool(node and node.get("insecure")) or bool(link and link.get("insecure")) or bool(profile and profile.get("insecure"))

    if not args.session_cache and not getattr(args, "no_session_cache", False):
        env_cache = os.environ.get("KISAMA_SESSION_CACHE")
        if env_cache:
            args.session_cache = env_cache
        elif node_profile_path is not None:
            # --node 指向档案文件: 沿用该档案的会话缓存 (多台并行各自独立)
            args.session_cache = str(node_profile_path) + ".session.json"
        elif node:
            pass   # --node 传链接: 一次性用法, 不落盘
        elif profile:
            # 仅连接档案模式默认启用会话缓存; --link 一次性用法不落盘
            args.session_cache = str(_profile_path(args.profile)) + ".session.json"

    # 🌐 间接域名 (shz.al/~名称, KMODE=2 静默上报): 每条命令建连前先解析出真实代理地址。
    # 档案/链接里保存的始终是入口 URL (代理重启换隧道域名后仍指向最新),
    # 解析结果只在本条命令内生效; 原始入口记入 url_entry 供错误提示与 connect 保存档案使用。
    if getattr(args, "url", None) and is_indirect_url(args.url):
        args.url_entry = args.url
        args.url = resolve_indirect_url(args.url, insecure=bool(getattr(args, "insecure", False)))


def _normalize_url(url: Optional[str]) -> str:
    """档案占用判定用: 去 scheme 大小写、去尾随 '/'、去查询串外的一切空白。
    '#' 网关路由片段是目标主机的一部分, 保留参与比较。"""
    raw = str(url or "").strip().lower()
    return raw.rstrip("/")


def _default_slot_conflict(new_url: str) -> Optional[dict[str, Any]]:
    """缺省槽已被另一台代理占用时返回该档案, 否则 None (同台重连不算冲突)。"""
    existing = load_profile(None)
    if not existing:
        return None
    if _normalize_url(existing.get("url")) == _normalize_url(new_url):
        return None
    return existing


def _profile_inventory() -> list[dict[str, Any]]:
    """connect --list: 只读盘点本机连接档案 (不联网、绝不输出密钥材料)。

    缺省槽 `~/.kisama/profile.json` 列在首位, 其后是 `~/.kisama/profiles/*.json` (按名排序);
    同名 `*.session.json` 是会话缓存不是档案, 跳过; 不存在的槽位不占行; 已存在但读坏/缺 url
    的行保留并标 `valid: false`——共用目录的客户端要能看清"哪一格被谁占着"的实际状态。
    """
    base = Path.home() / ".kisama"
    entries: list[tuple[str, Path]] = [("<default>", base / "profile.json")]
    profiles_dir = base / "profiles"
    if profiles_dir.is_dir():
        entries += [(p.stem, p) for p in sorted(profiles_dir.glob("*.json"))
                    if not p.name.endswith(".session.json")]
    rows: list[dict[str, Any]] = []
    for name, path in entries:
        if not path.is_file():
            continue
        row: dict[str, Any] = {"name": name, "profile_path": str(path), "is_default": name == "<default>"}
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            row.update(valid=False, error=f"档案不可读: {type(exc).__name__}")
            rows.append(row)
            continue
        data = loaded if isinstance(loaded, dict) and loaded.get("url") else None
        if data is None:
            row.update(valid=False, error="档案缺少 url 字段")
            rows.append(row)
            continue
        row.update(
            valid=True,
            url=data.get("url"),
            indirect=bool(data.get("indirect")),
            agent_version=data.get("agent_version"),
            debug_mode=data.get("debug_mode"),
            plain_mode=data.get("plain_mode"),
            key_id=data.get("key_id"),
            source=data.get("source"),
            saved_at=data.get("saved_at"),
            insecure=bool(data.get("insecure")),
            has_ecdsa_key=bool(data.get("ecdsa_key")),
            has_ecies_key=bool(data.get("ecies_key")),
            session_cached=Path(str(path) + ".session.json").is_file(),
        )
        rows.append(row)
    return rows


def do_connect(args: argparse.Namespace) -> dict[str, Any]:
    """connect: 解析分享链接/手工参数 → baseinfo 握手校验 → 保存连接档案 → 播种会话缓存。"""
    node_raw = (getattr(args, "node", None) or "").strip()
    if node_raw and not _is_share_link(node_raw) and not (getattr(args, "profile", None) or "").strip():
        # connect --node <名称|路径>: 该档案既是来源也是保存目标 (免 --profile 两个参数)
        args.profile = node_raw
    if getattr(args, "list", False):
        rows = _profile_inventory()
        return {"status": "ok", "action": "connect", "mode": "list", "count": len(rows), "profiles": rows}
    if getattr(args, "show", False):
        profile = load_profile(args.profile)
        if not profile:
            raise KisamaError(f"连接档案不存在: {_profile_path(args.profile)} (先执行 connect 保存)")
        return {
            "status": "ok",
            "action": "connect",
            "mode": "show",
            "profile_path": str(_profile_path(args.profile)),
            "url": profile.get("url"),
            "indirect": bool(profile.get("indirect")),
            "agent_version": profile.get("agent_version"),
            "debug_mode": profile.get("debug_mode"),
            "plain_mode": profile.get("plain_mode"),
            "key_id": profile.get("key_id"),
            "saved_at": profile.get("saved_at"),
            "source": profile.get("source"),
            "insecure": bool(profile.get("insecure")),
            "ecdsa_key": _mask_secret(profile.get("ecdsa_key")),
            "ecies_key": _mask_secret(profile.get("ecies_key")),
            "extra": profile.get("extra") or {},
        }

    link_raw = getattr(args, "link", None) or (node_raw if _is_share_link(node_raw) else None)
    link = parse_share_link(link_raw) if link_raw else None
    url = args.url or os.environ.get("KISAMA_URL") or (link or {}).get("url") or (load_profile(args.profile) or {}).get("url")
    if not url:
        raise KisamaError("connect 需要 --url 或整条 kisama:// 分享链接 (链接作为位置参数传入, 或用 --node 传入)")

    # 🔒 多客户端共用 ~/.kisama: 缺省槽只有一格, 无条件覆盖会把别人正在用的节点换成自己的
    # (对方下一条不带参数的命令就打到你这台机器, 比断开更糟)。显式 --profile/--node 名称属自选槽位, 不拦。
    if not (getattr(args, "profile", None) or "").strip() and not getattr(args, "force", False):
        holder = _default_slot_conflict(url)
        if holder:
            raise KisamaError(
                f"缺省连接档案已被另一台代理占用: {_profile_path(None)} 现指向 {holder.get('url')} "
                f"(版本 {holder.get('agent_version')}, 保存于 {holder.get('saved_at')})。"
                "connect 不覆盖它——本次请改用 --node 直连: "
                "--node \"<整条 kisama:// 链接>\" (免建档, 不碰任何槽位), "
                "或 connect --profile <名称> 建独立档案、之后各命令加 --node <名称>; "
                "确要把缺省槽切到新代理时重新执行并加 --force (改写现有档案并清空其会话缓存)"
            )

    ecdsa_key = args.ecdsa_key or os.environ.get("KISAMA_ECDSA_KEY") or (link or {}).get("ecdsa_key")
    ecies_key = args.ecies_key or os.environ.get("KISAMA_ECIES_KEY") or (link or {}).get("ecies_key")
    insecure = bool(getattr(args, "insecure", False)) or bool((link or {}).get("insecure"))

    # 🌐 间接域名 (shz.al/~名称): 握手校验连解析出的真实地址; 档案仍保存入口 URL——
    # 代理重启会换隧道域名, 入口 URL 永远指向最新, 之后每条命令经 resolve_connection 现场解析。
    indirect = is_indirect_url(url)
    resolved_url = resolve_indirect_url(url, insecure=insecure) if indirect else url

    # 校验: 完成 baseinfo 握手 (DEBUG 代理同样成功; 密钥错误当场报错)。校验握手不落缓存。
    client = KisamaClient(resolved_url, ecdsa_key, ecies_key, args.timeout, None, args.clock_offset, insecure)
    data = client.bootstrap()

    profile: dict[str, Any] = {
        "url": url,
        "indirect": indirect,
        "ecdsa_key": ecdsa_key or "",
        "ecies_key": ecies_key or "",
        "insecure": insecure,
        "agent_version": client.agent_version,
        "debug_mode": client.debug_mode,
        "plain_mode": client.plain_mode,
        "saved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source": "link" if link else "manual",
    }
    if link:
        profile["link"] = link_raw.strip()
        if link.get("extra"):
            profile["extra"] = link["extra"]
        profile["key_id"] = link["extra"].get("key_id") if link.get("extra") else None
    path = save_profile(args.profile, profile)

    # 会话缓存: 档案同名 .session.json, 播种校验握手的 session_key, 下一命令免重复握手
    sess_path = Path(str(path) + ".session.json")
    try:
        if sess_path.exists():
            sess_path.unlink()
        if not getattr(args, "no_session_cache", False):
            client.session_cache = str(sess_path)
            client.save_cache()
    except OSError:
        pass

    return {
        "status": "ok",
        "action": "connect",
        "profile_path": str(path),
        "url": url,
        "indirect": indirect,
        "resolved_url": resolved_url,
        "agent_version": client.agent_version,
        "debug_mode": client.debug_mode,
        "plain_mode": client.plain_mode,
        "key_id": profile.get("key_id"),
        "source": profile["source"],
        "insecure": insecure,
        "ecdsa_key": _mask_secret(ecdsa_key),
        "ecies_key": _mask_secret(ecies_key),
        "session_cached": bool(client.session_cache) and client.session_key_b64 is not None,
    }


def do_disconnect(args: argparse.Namespace) -> dict[str, Any]:
    """disconnect: 删除连接档案与同名会话缓存。"""
    node_raw = (getattr(args, "node", None) or "").strip()
    if node_raw and _is_share_link(node_raw):
        raise KisamaError("disconnect 需要档案名称或路径 (--node 传分享链接时本就不落盘, 无需删除)")
    if node_raw and not (getattr(args, "profile", None) or "").strip():
        args.profile = node_raw
    path = _profile_path(args.profile)
    removed = delete_profile(args.profile)
    return {
        "status": "ok" if removed else "noop",
        "action": "disconnect",
        "profile_path": str(path),
        "message": "连接档案已删除" if removed else "连接档案不存在 (无需清除)",
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="使用 Kisama Python 控制端连接并操作代理")
    parser.add_argument("--url", default=None, help="代理地址，例如 http://127.0.0.1:8000（必填；或先 connect 保存连接档案 / 用 --link 传入 kisama:// 分享链接）")
    parser.add_argument("--ecdsa-key", default=None, help="控制端 ECDSA 私钥文件或内容：PEM/DER，或 64 位 hex / Base64(32字节) 短格式标量（tempkey?format=short 下发，0.5.8 起支持）（可省略：DEBUG 代理免签名；生产代理会 401）")
    parser.add_argument("--ecies-key", default=None, help="控制端 ECIES 私钥文件、64 位 hex 或 Base64(32字节)（可省略：DEBUG 代理响应恒明文；生产代理必须提供）")
    parser.add_argument("--timeout", type=float, default=30.0, help="每次 HTTP 请求超时(秒), 上传/下载大文件自动放宽")
    parser.add_argument("--session-cache", default=None, help="会话缓存文件(JSON), 复用 session_key/noise_key, 免每次重复 baseinfo; 连接档案模式下缺省启用(档案同名 .session.json)")
    parser.add_argument("--no-session-cache", dest="no_session_cache", action="store_true", help="禁用会话缓存 (连接档案模式下默认启用)")
    parser.add_argument("--link", default=os.getenv("KISAMA_LINK"), help="kisama:// 分享链接整条传入 (任意命令可用, 免 connect 建档); KISAMA_LINK 环境变量等效")
    parser.add_argument("--node", default=os.getenv("KISAMA_NODE"), help="本次命令直连的代理: 整条 kisama:// 分享链接, 或连接档案名称/JSON 路径 (~/.kisama/profiles/<名>.json)。优先级高于 --link、环境变量与 connect 的缺省档案且互不串台, 多台代理并行时每条命令指定一台; KISAMA_NODE 环境变量等效")
    parser.add_argument("--profile", default=os.getenv("KISAMA_PROFILE"), help="连接档案: 名称(存 ~/.kisama/profiles/<名>.json)或 .json 文件路径; 缺省 ~/.kisama/profile.json; KISAMA_PROFILE 环境变量等效")
    parser.add_argument("--pretty", action="store_true")
    parser.add_argument("--clock-offset", type=float, default=None, help="签名时间戳偏移(秒), 默认自动从服务器 Date 头探测")
    parser.add_argument("--insecure", action="store_true",
                        default=os.getenv("KISAMA_INSECURE", "").strip().lower() in ("1", "true", "yes"),
                        help="跳过服务端 TLS 证书校验: 主机用自签证书/证书链不完整/证书域名不匹配时 (报 CERTIFICATE_VERIFY_FAILED) 使用。等效 KISAMA_INSECURE=1; 分享链接可带 insecure=1; connect 时记入连接档案, 后续命令自动沿用")
    sub = parser.add_subparsers(dest="action", required=True)

    sub.add_parser("baseinfo", help="获取代理信息并刷新 session_key/noise_key")

    command = sub.add_parser("exec", help="执行一次非交互式命令")
    command.add_argument("--cmd", required=True)
    command.add_argument("--cwd")
    command.add_argument("--env", action="append", default=[], metavar="KEY=VALUE")
    command.add_argument("--route", default="/api/exec",
                         choices=["/api/exec", "/api/do", "/api/run", "/api/work"],
                         help="exec 路由 (0.5.7+ 代理)。WAF/审计规则拦截 /api/exec 时优先 --route /api/do，备选 /api/run、/api/work；别名与默认路由完全等价，签名按实际路径自动处理")

    listing = sub.add_parser("list", help="列出远端文件")
    listing.add_argument("--path", default=".")
    listing.add_argument("--recursive", action="store_true")

    cat = sub.add_parser("cat", help="读取远端文件")
    cat.add_argument("--path", required=True)

    authority_get = sub.add_parser("authority-get", help="查询远端权限")
    authority_get.add_argument("paths", nargs="+")

    authority_set = sub.add_parser("authority-set", help="设置远端权限")
    authority_set.add_argument("permissions", nargs="+", metavar="PATH=MODE")
    authority_set.add_argument("--recursive", action="store_true")

    mkdir = sub.add_parser("mkdir", help="创建远端目录")
    mkdir.add_argument("--path", required=True)

    move = sub.add_parser("move", help="移动或重命名远端文件")
    move.add_argument("mapping", nargs="+", metavar="FROM=TO")

    copy = sub.add_parser("copy", help="复制远端文件")
    copy.add_argument("mapping", nargs="+", metavar="FROM=TO")

    delete = sub.add_parser("delete", help="删除远端文件或目录")
    delete.add_argument("paths", nargs="+")
    delete.add_argument("--route", default="auto",
                        choices=["auto", "/api/file", "/api/file/delete"],
                        help="delete 路由 (缺省 auto): auto 按代理版本自动选择——version 含 php 时优先 POST /api/file/delete (与 DELETE /api/file 完全等价的 PHP 兼容路由, 规避 cPanel 等共享主机网关禁用/剥离 DELETE 方法请求体导致的读超时), 失败自动回退 DELETE /api/file; 显式指定两条路由之一则强制使用、失败不回退")

    upload = sub.add_parser("upload", help="上传本地文件到远端，自动使用裸二进制分片")
    upload.add_argument("--local", required=True)
    upload.add_argument("--remote-path", required=True)
    upload.add_argument("--name")
    upload.add_argument("--chunk-size", type=int, default=8 * 1024 * 1024)

    download = sub.add_parser("download", help="下载远端文件到本地 (先预检真实大小; 超过 --chunk-size 自动远端切片取回并支持续传)")
    download.add_argument("--remote-path", required=True)
    download.add_argument("--local", required=True)
    download.add_argument("--chunk-size", type=int, default=DOWNLOAD_CHUNK_DEFAULT,
                          help=f"字节: 大于此值的文件走远端切片流水线, 缺省 {DOWNLOAD_CHUNK_DEFAULT} (32MiB); 小于等于该值恒单次整取")
    download.add_argument("--mode", choices=["auto", "direct", "split"], default="auto",
                          help="auto 按预检大小分流; direct 强制单次整取 (整个响应进内存); split 强制分片 (需代理端 POSIX exec)")
    download.add_argument("--root-abs", help="分片模式: 代理端 FILE_ROOT 的绝对路径; 缺省用 exec 的 pwd/$HOME 探测并按文件大小校验")
    download.add_argument("--exec-route", default="/api/exec",
                          choices=["/api/exec", "/api/do", "/api/run", "/api/work"],
                          help="分片流水线用的 exec 路由 (WAF 拦 /api/exec 时改 --exec-route /api/do)")
    download.add_argument("--keep-parts", action="store_true", help="保留远端临时分片不删除 (排障用; 本地 .part 仍会合并进目标文件)")

    zipcmd = sub.add_parser("zip", help="打包远端文件/目录为 zip (需代理端 0.5.4+)")
    zipcmd.add_argument("--path", required=True, help="目标 zip 路径 (相对 FILE_ROOT); 已存在时覆盖重建")
    zipcmd.add_argument("items", nargs="+", help="待压缩文件/目录 (相对 FILE_ROOT); 目录递归打包")
    zipcmd.add_argument("--flat", action="store_true", help="目录内容不带顶层目录名前缀")

    unzip = sub.add_parser("unzip", help="解压远端 zip 包 (需代理端 0.5.4+)")
    unzip.add_argument("--path", required=True, help="zip 压缩包路径 (相对 FILE_ROOT)")
    unzip.add_argument("--dest", help="解压目标目录, 缺省为 zip 所在目录 (解压到此处)")
    unzip.add_argument("--no-overwrite", action="store_true", help="目标文件已存在时跳过 (缺省覆盖)")
    unzip.add_argument("--entries", nargs="+", metavar="NAME", help="仅解压匹配条目 (精确名或不带路径匹配)")

    terminal = sub.add_parser("terminal", help="通过 Noise 超级终端执行命令")
    group = terminal.add_mutually_exclusive_group(required=True)
    group.add_argument("--command")
    group.add_argument("--input")
    terminal.add_argument("--request-id")
    terminal.add_argument("--token", help="明文降级模式令牌: 0.4.8+ 用 auto (自动按 HMAC(session_key) 计算); 旧版代理传 agent 公钥; 不传走 Noise 加密模式")
    terminal.add_argument("--rows", type=int, default=24)
    terminal.add_argument("--cols", type=int, default=80)
    terminal.add_argument("--terminal-timeout", type=float, default=60.0)

    sub.add_parser("tunnel-list", help="查询临时隧道列表 (GET /api/argo; 0.6.8+ 条目含 shz_name/shz_url 绑定信息)")
    tunnel_create = sub.add_parser("tunnel-create", help="创建临时隧道 (POST /api/argo; 0.6.8+ 可带 --shz 系列参数创建并绑定 shz.al 上报)")
    tunnel_create.add_argument("--port", type=int, help="隧道转发端口 1~65535, 缺省用 agent 自身监听端口")
    tunnel_create.add_argument("--duplicate", action="store_true", help="允许同一端口重复创建隧道")
    tunnel_create.add_argument("--shz", action="store_true", help="创建后绑定 shz.al 上报 (0.6.8+; 上报名缺省派生 KNAME-端口, 密钥派生 上报名+123)")
    tunnel_create.add_argument("--shz-name", help="显式指定上报名 (完整覆盖派生值, 不再拼端口; ≥3 字符; 0.6.8+)")
    tunnel_create.add_argument("--shz-key", help="显式指定管理密钥 (完整覆盖派生值; ≥8 字符; 0.6.8+)")
    tunnel_delete = sub.add_parser("tunnel-delete", help="删除临时隧道 (DELETE /api/argo; 0.6.8+ 删除绑定隧道自动清持久化并删远端记录)")
    tunnel_delete.add_argument("--port", type=int, required=True, help="要删除的隧道转发端口 1~65535")
    tunnel_delete.add_argument("--tunnel-domain", help="同端口存在多条隧道时用于精确定位")
    tunnel_bind = sub.add_parser("tunnel-bind", help="给已启动隧道绑定 shz.al 上报 (POST /api/argo/bind; 0.6.8+ Py/Js/Java/Java11)")
    tunnel_bind.add_argument("--port", type=int, required=True, help="目标隧道转发端口 1~65535")
    tunnel_bind.add_argument("--tunnel-domain", help="同端口存在多条隧道时用于精确定位")
    tunnel_bind.add_argument("--shz-name", help="显式指定上报名 (完整覆盖派生值 KNAME-端口, 不再拼端口; ≥3 字符)")
    tunnel_bind.add_argument("--shz-key", help="显式指定管理密钥 (完整覆盖派生值 上报名+123; ≥8 字符)")
    tunnel_unbind = sub.add_parser("tunnel-unbind", help="解绑隧道的 shz.al 上报 (DELETE /api/argo/bind; 保留隧道, 远端记录后台删除; 0.6.8+)")
    tunnel_unbind.add_argument("--port", type=int, required=True, help="目标隧道转发端口 1~65535")
    tunnel_unbind.add_argument("--tunnel-domain", help="同端口存在多条隧道时用于精确定位")

    sub.add_parser("task-status", help="查看任务模块运行状态 (GET /api/task/status)")
    task_get = sub.add_parser("task-get", help="查看任务表 (GET /api/task/onetime|/api/task/cron)")
    task_get.add_argument("--type", required=True, choices=["onetime", "cron"],
                          help="onetime=启动任务列表, cron=定时任务 {表达式: 命令}")
    task_set = sub.add_parser("task-set", help="设置任务表 (POST /api/task/onetime|/api/task/cron; 整表替换, 本次未包含的存量任务即被删除)")
    task_set.add_argument("--type", required=True, choices=["onetime", "cron"],
                          help="onetime=启动任务, cron=定时任务")
    task_set.add_argument("items", nargs="+", metavar="ITEM",
                          help="--type onetime: 每项一条完整命令字符串, 如 'echo hello' 'date'; "
                               "--type cron: 每项 'CRON表达式=命令' (首个 = 切分, 命令内可含 =), "
                               "表达式含 * 与空格须整体引号包裹, 如 '*/5 * * * *=echo heartbeat'")
    sub.add_parser("task-exec", help="手动强制重跑全部已配置启动任务 (POST /api/task/onetime/execute; 不受 InitTask 状态限制, 结果写入启动任务日志环)")
    task_log = sub.add_parser("task-log", help="查询任务执行日志 (GET /api/task/log/onetime|cron; 环形缓冲, 缺省/最大 100 条)")
    task_log.add_argument("--type", required=True, choices=["onetime", "cron"],
                          help="onetime=启动任务日志, cron=定时任务日志")
    task_log.add_argument("--limit", type=int, default=100, help="返回条数, 缺省 100, 超出自动截到 100")
    task_log_clear = sub.add_parser("task-log-clear", help="清空任务执行日志 (DELETE /api/task/log/onetime|cron; 不可逆)")
    task_log_clear.add_argument("--type", required=True, choices=["onetime", "cron"],
                                help="onetime=启动任务日志, cron=定时任务日志")
    sub.add_parser("task-log-summary", help="任务日志统计摘要 (GET /api/task/log/summary; 数量与成功率)")

    # 📡 本地端口反代 (0.6.7 起 py/js/java/java11; go 端无此特性返回 404)
    sub.add_parser("proxy-config", help="查看反代端口白名单快照 (GET /api/proxy/config; 0.6.7 续批六起返回 hub/local 两组各自 env_ports/runtime_ports/effective_ports)")
    proxy_config_set = sub.add_parser("proxy-config-set", help="整体覆盖所选组运行时白名单 (POST /api/proxy/config; 0.6.7 续批六 scope 分组: hub=HUB 组仅 hub 链路 / local=本地组仅本地路由; KSTORE 启用时持久化, 重启恢复)")
    proxy_config_set.add_argument("--ports", required=True, metavar="PORTS",
                                  help="端口列表, 逗号或空格分隔, 如 '8080,9090'; 整体覆盖所选组运行时列表 (组 env KHUB_PORTS/KPROXY_PORTS 下限不受影响, 收紧用 proxy-config-clear)")
    proxy_config_set.add_argument("--scope", choices=["local", "hub"], default="local",
                                  help="白名单组: local=本地组 (默认, /api/proxy 路由), hub=HUB 组 (hub /{KNAME}/{PORT}/* 中继; 0.6.7 续批六)")
    proxy_config_clear = sub.add_parser("proxy-config-clear", help="清空所选组运行时白名单回落组 env (DELETE /api/proxy/config; 0.6.7 续批六 scope 分组; 不带 --scope 清两组)")
    proxy_config_clear.add_argument("--scope", choices=["local", "hub"], default=None,
                                    help="只清该组: local=本地组, hub=HUB 组; 缺省清两组 (组 env KHUB_PORTS/KPROXY_PORTS 部分仍生效)")
    proxy = sub.add_parser("proxy", help="经 agent 反代路由访问其 127.0.0.1:{port} 的 HTTP 服务 (匿名+白名单门禁, 响应原样透传)")
    proxy.add_argument("--port", type=int, required=True, help="目标端口 1~65535, 须在本地组白名单内 (env KPROXY_PORTS ∪ proxy-config-set --scope local 的运行时列表)")
    proxy.add_argument("--path", default="", metavar="PATH", help="反代子路径 (可含 query), 如 'api/status?x=1'; 缺省请求 /api/proxy/{port} 根路径")
    proxy.add_argument("--method", default="GET", choices=list(PROXY_METHODS), help="HTTP 方法, 缺省 GET")
    proxy.add_argument("--header", action="append", metavar="K:V", help="附加请求头, 可重复, 如 'Content-Type: application/json'")
    proxy.add_argument("--data", help="请求体字符串 (UTF-8); 与 --data-file 二选一")
    proxy.add_argument("--data-file", dest="data_file", help="请求体读本地文件原始字节 (二进制安全); 与 --data 二选一")
    proxy.add_argument("--out", help="响应体保存到本地文件 (原始字节, 完整不截断, 输出含 sha256); 缺省按文本/base64 内联输出")

    connect = sub.add_parser("connect", help="整条 kisama:// 分享链接(或 --url/--ecdsa-key/--ecies-key)一次完成校验并保存连接档案, 之后所有命令免密钥参数; 多客户端共用 ~/.kisama 时缺省槽被别的节点占着会拒绝覆盖, 改用 --node 直连或 --profile 独立建档")
    connect.add_argument("link", nargs="?", default=None, metavar="LINK", help="kisama:// 分享链接整条传入 (引号包裹); 省略时用 --url 等参数手工连接")
    connect.add_argument("--url", default=argparse.SUPPRESS, help="手工连接: 代理地址 (省略链接时使用)")
    connect.add_argument("--ecdsa-key", default=argparse.SUPPRESS, help="手工连接: ECDSA 私钥 (省略链接时使用)")
    connect.add_argument("--ecies-key", default=argparse.SUPPRESS, help="手工连接: ECIES 私钥 (省略链接时使用)")
    connect.add_argument("--show", action="store_true", help="仅显示当前连接档案 (脱敏), 不联网")
    connect.add_argument("--list", dest="list", action="store_true", help="只读盘点本机全部连接档案: 缺省槽 + profiles/*.json 的节点、版本、来源、保存时间与是否有会话缓存; 绝不输出密钥材料, 不联网")
    connect.add_argument("--force", action="store_true", help="允许覆盖已被其他节点占用的缺省档案 (默认拒绝, 改用 --node/--profile 让位)")
    sub.add_parser("disconnect", help="删除连接档案与同名会话缓存")
    return parser


def require_options(args: argparse.Namespace) -> None:
    # 🌟 仅 --url 必填: 密钥改惰性加载, DEBUG 模式代理 (x-encrypted: false) 免验签/免解密,
    # 无密钥也能探测与操作; 生产模式首次签名/解密时才因缺钥报出明确错误。
    missing = [name for name in ("url",) if not getattr(args, name)]
    if missing:
        raise KisamaError(
            "缺少连接参数: " + ", ".join(missing)
            + "。可用 --node 直连 (整条 kisama:// 分享链接或档案名称/路径), 或先执行 connect \"kisama://...\" 保存连接档案, 或用 --link 传整条分享链接, 或用命令行参数 / KISAMA_URL 环境变量"
        )


async def run(args: argparse.Namespace) -> Any:
    # 🔗 连接档案管理命令: 不走常规连接解析
    if args.action == "connect":
        return do_connect(args)
    if args.action == "disconnect":
        return do_disconnect(args)

    # 其余命令: CLI 显式 > --node/KISAMA_NODE > --link/KISAMA_LINK > 环境变量 > 连接档案
    resolve_connection(args)
    require_options(args)
    client = KisamaClient(args.url, args.ecdsa_key, args.ecies_key, args.timeout, args.session_cache, args.clock_offset, getattr(args, "insecure", False))
    try:
        return await dispatch(client, args)
    except KisamaError as exc:
        # 缓存密钥失效时清空重试一次 (重拉 baseinfo 刷新)。
        # 🌟 生产缓存撞上 DEBUG 代理的场景依赖这次重试: 首个请求用缓存密钥 AES 加密会被
        # DEBUG 代理原样透传给路由 (DEBUG 分支跳过解密) 而报错, 但响应已置位 debug_mode,
        # 重试后走明文直发即可成功。bootstrap 成功后 _cache_state 变为 "fresh", 不会重试第二次。
        if client._cache_state == "loaded":
            client._cache_state = "none"
            client.session_key_b64 = None
            client.session_key = None
            client.noise_key = None
            return await dispatch(client, args)
        raise


def do_delete_paths(client: KisamaClient, paths: list[str], route: Optional[str]) -> Any:
    """🗑️ 删除远端路径, 按 docs/API.MD 自动适配 PHP 兼容删除路由。

    共享主机/cPanel/Froxlor 等网关会禁用或剥离 DELETE 方法的请求体, 使
    DELETE /api/file 表现为读超时长挂。PHP 版代理提供完全等价的
    POST /api/file/delete (请求体/处理逻辑 SafeFileManager::deletePaths/
    返回结构与原路由一致, 仅方法与路径不同)。

    - 显式 --route /api/file/delete 或 /api/file: 强制使用该路由, 失败不回退
    - auto: 先 _ensure_session 确保 agent_version 就位, 再按版本决策——
        · version 含 php → 先 POST /api/file/delete, 任一次级失败 (含旧版
          PHP 无此路由的 404) 回退 DELETE /api/file; 双双失败抛合并错误
        · 否则 → 直接 DELETE /api/file (兼容路由仅 PHP 版提供)
    """
    payload = {"paths": list(paths)}
    if route and route != "auto":
        if route == "/api/file/delete":
            return client.request_json("POST", route, payload)
        if route == "/api/file":
            return client.request_json("DELETE", route, payload)
        raise KisamaError(f"未知 delete 路由: {route}")
    # 先完成 baseinfo 握手 (拉取/校验代理版本号), 再按版本选路由
    client._ensure_session()
    if "php" not in (client.agent_version or "").lower():
        return client.request_json("DELETE", "/api/file", payload)
    try:
        return client.request_json("POST", "/api/file/delete", payload)
    except Exception as first_exc:
        pass  # 读超时/404/405 等一律回退原路由; 两条都失败时再合并报错
    try:
        return client.request_json("DELETE", "/api/file", payload)
    except Exception as second_exc:
        raise KisamaError(
            "两条删除路由均失败 — "
            f"POST /api/file/delete (php 兼容): {first_exc}; "
            f"DELETE /api/file (原版): {second_exc}"
        ) from second_exc


async def dispatch(client: KisamaClient, args: argparse.Namespace) -> Any:
    if args.action == "baseinfo":
        data = client.bootstrap()
        if isinstance(data, dict):
            return {
                k: ("***masked***" if k in ("session_key", "noise_key") else v)
                for k, v in data.items()
            }
        return data
    if args.action == "exec":
        return client.request_json("POST", getattr(args, "route", None) or "/api/exec", {"cmd": args.cmd, **({"cwd": args.cwd} if args.cwd else {}), **({"env": parse_pairs(args.env, "env")} if args.env else {})})
    if args.action == "list":
        return client.request_json("POST", "/api/file/list", {"path": args.path, "recursive": args.recursive})
    if args.action == "cat":
        return client.request_json("POST", "/api/file/cat", {"path": args.path})
    if args.action == "authority-get":
        return client.request_json("POST", "/api/file/authority", {"paths": args.paths})
    if args.action == "authority-set":
        return client.request_json("PUT", "/api/file/authority", {"permissions": parse_pairs(args.permissions, "permissions"), "recursive": args.recursive})
    if args.action == "mkdir":
        return client.request_json("POST", "/api/file/new", {"path": args.path})
    if args.action == "move":
        return client.request_json("PUT", "/api/file", parse_pairs(args.mapping, "mapping"))
    if args.action == "copy":
        return client.request_json("POST", "/api/file/cp", parse_pairs(args.mapping, "mapping"))
    if args.action == "delete":
        return do_delete_paths(client, list(args.paths), getattr(args, "route", None))
    if args.action == "upload":
        return client.upload(args.local, args.remote_path, args.name, args.chunk_size)
    if args.action == "download":
        return client.download(args.remote_path, args.local, chunk_size=args.chunk_size, mode=args.mode,
                               root_abs=args.root_abs, exec_route=args.exec_route, keep_parts=args.keep_parts)
    if args.action == "zip":
        return client.request_json("POST", "/api/file/zip", {"path": args.path, "items": list(args.items), "flat": args.flat})
    if args.action == "unzip":
        payload: dict[str, Any] = {"path": args.path, "overwrite": not args.no_overwrite}
        if args.dest:
            payload["dest_path"] = args.dest
        if args.entries:
            payload["entries"] = list(args.entries)
        return client.request_json("POST", "/api/file/unzip", payload)
    if args.action == "terminal":
        return await client.terminal(args.command, args.input, args.request_id, args.token, args.rows, args.cols, args.terminal_timeout)
    if args.action == "tunnel-list":
        return client.request_json("GET", "/api/argo", None)
    if args.action == "tunnel-create":
        payload: dict[str, Any] = {}
        if args.port is not None:
            payload["port"] = args.port
        if args.duplicate:
            payload["duplicate"] = True
        # shz/shz_name/shz_key 为 0.6.8+ 新参数 (创建并绑定 shz.al 上报); 旧版代理不支持,
        # 兼容标注见 SKILL.md 临时隧道段
        if args.shz:
            payload["shz"] = True
        if getattr(args, "shz_name", None):
            payload["shz_name"] = args.shz_name
        if getattr(args, "shz_key", None):
            payload["shz_key"] = args.shz_key
        return client.request_json("POST", "/api/argo", payload)
    if args.action == "tunnel-delete":
        payload = {"port": args.port}
        if args.tunnel_domain:
            payload["tunnel_domain"] = args.tunnel_domain
        return client.request_json("DELETE", "/api/argo", payload)
    if args.action == "tunnel-bind":
        payload = {"port": args.port}
        if args.tunnel_domain:
            payload["tunnel_domain"] = args.tunnel_domain
        if args.shz_name:
            payload["shz_name"] = args.shz_name
        if args.shz_key:
            payload["shz_key"] = args.shz_key
        return client.request_json("POST", "/api/argo/bind", payload)
    if args.action == "tunnel-unbind":
        payload = {"port": args.port}
        if args.tunnel_domain:
            payload["tunnel_domain"] = args.tunnel_domain
        return client.request_json("DELETE", "/api/argo/bind", payload)
    if args.action == "task-status":
        return client.request_json("GET", "/api/task/status", None)
    if args.action == "task-get":
        return client.request_json("GET", f"/api/task/{args.type}", None)
    if args.action == "task-set":
        # onetime 传 JSON 数组 (每项一条完整命令); cron 传 {表达式: 命令} 对象 (首个 = 切分,
        # 表达式不含 =, 命令内含 = 不受影响) — 均 docs/API.MD 14/16 整表替换语义
        if args.type == "onetime":
            return client.request_json("POST", "/api/task/onetime", [str(x) for x in args.items])
        return client.request_json("POST", "/api/task/cron", parse_pairs(list(args.items), "cron 任务"))
    if args.action == "task-exec":
        return client.request_json("POST", "/api/task/onetime/execute", None)
    if args.action == "task-log":
        return client.request_json("GET", f"/api/task/log/{args.type}?limit={min(max(args.limit, 0), 100)}", None)
    if args.action == "task-log-clear":
        return client.request_json("DELETE", f"/api/task/log/{args.type}", None)
    if args.action == "task-log-summary":
        return client.request_json("GET", "/api/task/log/summary", None)
    if args.action == "proxy-config":
        return client.request_json("GET", "/api/proxy/config", None)
    if args.action == "proxy-config-set":
        return client.request_json("POST", "/api/proxy/config",
                                   {"ports": parse_port_list(args.ports), "scope": args.scope})
    if args.action == "proxy-config-clear":
        clear_path = f"/api/proxy/config?scope={args.scope}" if args.scope else "/api/proxy/config"
        return client.request_json("DELETE", clear_path, None)
    if args.action == "proxy":
        if args.data is not None and args.data_file:
            raise KisamaError("--data 与 --data-file 二选一")
        headers: dict[str, str] = {}
        for item in args.header or []:
            if ":" not in item:
                raise KisamaError(f"--header 参数必须是 'Key: Value': {item}")
            key, value = item.split(":", 1)
            if not key.strip():
                raise KisamaError(f"--header 的 key 不能为空: {item}")
            headers[key.strip()] = value.strip()
        if args.data is not None:
            body = args.data.encode("utf-8")
        elif args.data_file:
            source = Path(args.data_file).expanduser()
            if not source.is_file():
                raise KisamaError(f"--data-file 本地文件不存在: {source}")
            body = source.read_bytes()
        else:
            body = None
        return client.proxy_relay(args.port, args.method, args.path, body, headers, args.out)
    raise KisamaError(f"未知操作: {args.action}")


def main() -> int:
    _ensure_utf8_stdio()
    parser = build_parser()
    args = parser.parse_args()
    try:
        result = asyncio.run(run(args))
        output(result, args.pretty)
        return 0
    except KeyboardInterrupt:
        return 130
    except KisamaError as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    except Exception as exc:
        print(json.dumps({"status": "error", "message": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
