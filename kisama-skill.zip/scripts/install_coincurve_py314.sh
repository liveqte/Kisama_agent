#!/usr/bin/env bash
# ============================================================================
# 🔧 coincurve Python 3.14 修复脚本
#
# 问题: coincurve (eciespy 的底层依赖) 最高只发布到 cp313 的预编译 wheel,
#       Python 3.14 下只能源码编译, 而 coincurve 21.0.0 的 hatchling 构建
#       钩子要求 cffi 发行版中恰好存在 1 个 LICENSE 文件 (新版 cffi 为 0 个),
#       导致 `pip install -r requirements.txt` 在 Preparing metadata 阶段报错:
#       "RuntimeError: Expected exactly one LICENSE file in cffi distribution, got 0"
#
# 解决: 下载 coincurve 源码包 -> 打补丁跳过 LICENSE 校验 -> 本地编译安装,
#       之后 `pip install -r requirements.txt` 即可正常通过 (coincurve 已满足, 跳过)。
#
# 用法:
#   tools/install_coincurve_py314.sh [venv_python]
#   例如: tools/install_coincurve_py314.sh            # 使用当前 python
#         tools/install_coincurve_py314.sh py/venv/bin/python
# ============================================================================
set -euo pipefail

PY=${1:-python3}
COINCURVE_VERSION="21.0.0"
WORKDIR=$(mktemp -d)
trap 'rm -rf "$WORKDIR"' EXIT

check_py314() {
    local major="${1?}" minor="${2?}"
    if [ "$major" -gt 3 ] || { [ "$major" -eq 3 ] && [ "$minor" -ge 14 ]; }; then
        return 0
    fi
    # < 3.14 有官方 wheel, 无需打补丁
    echo "ℹ️  Python $major.$minor < 3.14, coincurve 有官方预编译 wheel, 无需此补丁。"
    exit 0
}

echo "🔍 检测 Python 版本..."
VER=$("$PY" -c "import sys; print(f'{sys.version_info.major} {sys.version_info.minor}')")
check_py314 $VER

if ! command -v curl >/dev/null 2>&1 || ! command -v tar >/dev/null 2>&1; then
    echo "❌ 需要 curl 与 tar 命令" >&2
    exit 1
fi

echo "⬇️  下载 coincurve==${COINCURVE_VERSION} 源码包..."
curl -sL -o "$WORKDIR/coincurve.tar.gz" \
    "https://files.pythonhosted.org/packages/source/c/coincurve/coincurve-${COINCURVE_VERSION}.tar.gz"
tar xzf "$WORKDIR/coincurve.tar.gz" -C "$WORKDIR"

echo "🔧 应用 LICENSE 校验补丁..."
python3 - "$WORKDIR/coincurve-${COINCURVE_VERSION}/hatch_build.py" <<'EOF'
import sys

p = sys.argv[1]
s = open(p).read()

old = '''        dist = distribution("cffi")
        license_files = [f for f in dist.files if f.name == "LICENSE" and f.parent.name.endswith(".dist-info")]
        if len(license_files) != 1:
            message = f"Expected exactly one LICENSE file in cffi distribution, got {len(license_files)}"
            raise RuntimeError(message)

        license_file = license_files[0]
        shutil.copy2(license_file.locate(), self.local_cffi_license)
        self.metadata.core.license_files.append(self.LICENSE_NAME)'''
new = '''        try:
            dist = distribution("cffi")
            license_files = [f for f in dist.files if f.name == "LICENSE" and f.parent.name.endswith(".dist-info")]
            if len(license_files) == 1:
                license_file = license_files[0]
                shutil.copy2(license_file.locate(), self.local_cffi_license)
                self.metadata.core.license_files.append(self.LICENSE_NAME)
        except Exception:
            pass'''
assert old in s, "patch pattern not found, coincurve source may have changed"
s = s.replace(old, new)
s = s.replace(
    '''    def finalize(self, version: str, build_data: dict[str, Any], artifact: str) -> None:  # noqa: ARG002
        os.remove(self.local_cffi_license)''',
    '''    def finalize(self, version: str, build_data: dict[str, Any], artifact: str) -> None:  # noqa: ARG002
        if os.path.exists(self.local_cffi_license):
            os.remove(self.local_cffi_license)''')
open(p, "w").write(s)
print("✅ 补丁应用成功")
EOF

echo "⏳ 编译安装 coincurve (需要 gcc 与 python 头文件)..."
"$PY" -m pip install "$WORKDIR/coincurve-${COINCURVE_VERSION}"

echo "✅ coincurve==${COINCURVE_VERSION} 安装完成。现在可以正常执行:"
echo "   $PY -m pip install -r requirements.txt"