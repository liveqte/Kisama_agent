# 依赖安装与环境准备

首次安装或安装报错时阅读。正常流程（SKILL.md §1）：建 venv → `pip install -r` → 验证导入。

## 1. 必须用虚拟环境

Ubuntu 23.04+/Debian 12+ 直接对系统 Python `pip install` 会被拒绝（`error: externally-managed-environment`，PEP 668）。**不要加 `--break-system-packages`**，用 venv：

```bash
python3 -m venv /tmp/venv              # Linux/macOS
# Windows (PowerShell):  python -m venv .venv
```

命令一律用 venv 内 Python：Linux/macOS 是 `/tmp/venv/bin/python`，Windows 是 `.venv\Scripts\python.exe`，不要用系统 `python3`/`python`。venv 可复用：已验证通过就不要重装。

## 2. 依赖分层与 Python 3.14

依赖分两层（requirements.txt 已按此组织）：

- **核心必装**：`ecdsa`（纯 Python）、`cryptography`（abi3 wheel）、`noiseprotocol`、`websockets`——任意 CPython（含 3.14）都有免编译安装包，`pip install -r` 不会触发源码编译。
- **可选加速**：`coincurve`/`eciespy`/`pycryptodome`（libsecp256k1 原生实现）。**Python 3.14 无对应 wheel，装不上没关系**：pip 会报错跳过或提示，脚本内置兼容层会自动回退 ecdsa+cryptography 实现，功能与输出格式完全一致（仅点运算速度差异，控制端场景可忽略）。

**Python 3.14 用户**：核心依赖直接安装即可运行，无需任何补丁或编译工具。`scripts/install_coincurve_py314.sh`（Linux/macOS，需 gcc 与 python 头文件）仅在想要原生性能时选用；Windows 3.14 无需任何处理。

## 3. 包名注意

- PyPI 包名是 **`eciespy`**（可选加速；核心依赖不含它，不要手动往必装清单里改）。
- 导入名是 **`ecies`**：仅当安装了原生加速时验证命令可写 `import ecies`。

验证命令（Linux，核心依赖）：
```bash
/tmp/venv/bin/python -c "import ecdsa, cryptography, noise, websockets; print('all deps OK')"
```
（Windows 把解释器换成 `.venv\Scripts\python.exe`）

## 4. 密钥与地址

- ECDSA 私钥原样写入 PEM 文件（PKCS#8 或 SEC1 均可），ECIES 私钥写入 64 位 hex 文件；Unix 上权限设为 0600（Windows 无此概念）。不要放进仓库或聊天消息。
- 地址逐字复制用户提供的 `scheme://主机[:端口]`，不加 `/api`、不加尾随 `/`。
- 密钥文件与缓存文件用 ASCII/UTF-8 无 BOM 保存（避免 Windows 记事本默认 UTF-16 导致解析失败）。