# 依赖安装与环境准备

首次安装或安装报错时阅读。正常流程（SKILL.md §1）：建 venv →（Python 3.14 先跑补丁，仅 Linux/macOS）→ `pip install -r` → 验证导入。

## 1. 必须用虚拟环境

Ubuntu 23.04+/Debian 12+ 直接对系统 Python `pip install` 会被拒绝（`error: externally-managed-environment`，PEP 668）。**不要加 `--break-system-packages`**，用 venv：

```bash
python3 -m venv /tmp/venv              # Linux/macOS
# Windows (PowerShell):  python -m venv .venv
```

命令一律用 venv 内 Python：Linux/macOS 是 `/tmp/venv/bin/python`，Windows 是 `.venv\Scripts\python.exe`，不要用系统 `python3`/`python`。venv 可复用：已验证通过就不要重装。

## 2. Python 3.14：coincurve 编译问题

3.14 下 `pip install -r requirements.txt` 若报 `RuntimeError: Expected exactly one LICENSE file in cffi distribution, got 0`（coincurve 只发布到 cp313 wheel，3.14 需源码编译）：

- **Linux/macOS**：先运行
  ```bash
  scripts/install_coincurve_py314.sh /tmp/venv/bin/python
  ```
  （需 gcc 与 python 头文件）后再 pip install。
- **Windows**：该补丁脚本是 bash，**不可用**。Windows 上源码编译需要 MSVC 工具链（Visual Studio Build Tools），配置繁琐；**建议改用 Python 3.13 或 3.12**（有官方 wheel，直接 pip install 即可）。

非 3.14 环境有官方 wheel，跳过此步。

## 3. 包名注意

- PyPI 包名是 **`eciespy`**（requirements.txt 原样，不要改）。
- 导入名是 **`ecies`**：验证命令写 `import ecies`，不要 `import eciespy` 或 `pip install ecies`。

验证命令（Linux）：
```bash
/tmp/venv/bin/python -c "import ecdsa, Crypto, ecies, coincurve, noise, websockets; print('all deps OK')"
```
（Windows 把解释器换成 `.venv\Scripts\python.exe`）

## 4. 密钥与地址

- ECDSA 私钥原样写入 PEM 文件（PKCS#8 或 SEC1 均可），ECIES 私钥写入 64 位 hex 文件；Unix 上权限设为 0600（Windows 无此概念）。不要放进仓库或聊天消息。
- 地址逐字复制用户提供的 `scheme://主机[:端口]`，不加 `/api`、不加尾随 `/`。
- 密钥文件与缓存文件用 ASCII/UTF-8 无 BOM 保存（避免 Windows 记事本默认 UTF-16 导致解析失败）。