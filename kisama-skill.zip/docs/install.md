# 依赖安装与环境准备（按需阅读）

本文件只在首次安装依赖或安装报错时阅读。正常流程（SKILL.md §1.1）是：建 venv → （Python 3.14 先跑补丁脚本）→ `pip install -r` → 验证导入。下面记录已验证的环境事实与每个坑的完整背景，按这些步骤做即可一次成功。

## 1. 必须使用虚拟环境（PEP 668）

Ubuntu 23.04+/Debian 12+ 等发行版对系统 Python 启用 PEP 668，直接 `python3 -m pip install ...` 会被拒绝，报 `error: externally-managed-environment`（提示联系发行商或加 `--break-system-packages`）。**不要加 `--break-system-packages` 污染系统 Python**，正确做法：

```bash
python3 -m venv /tmp/venv
```

之后所有命令都使用 `/tmp/venv/bin/python`，不要用系统 `python3`。venv 可复用：已有 `/tmp/venv` 且验证通过时，不要再重新安装。

## 2. Python 3.14：coincurve 必须先打补丁

问题：`coincurve`（`eciespy` 的底层依赖）最高只发布到 cp313 预编译 wheel；Python 3.14 只能源码编译，而 coincurve 21.0.0 的 hatchling 构建钩子要求 cffi 发行版恰好存在 1 个 LICENSE 文件（新版 cffi 为 0 个），导致 `pip install -r requirements.txt` 在 Preparing metadata 阶段报：

```text
RuntimeError: Expected exactly one LICENSE file in cffi distribution, got 0
```

解决：先运行技能包自带的补丁脚本（下载 coincurve 源码 → 打补丁跳过 LICENSE 校验 → 本地编译安装，需 gcc 与 python 头文件）：

```bash
scripts/install_coincurve_py314.sh /tmp/venv/bin/python
```

之后再执行 `pip install -r scripts/requirements.txt` 即可（coincurve 已满足会自动跳过）。非 3.14 环境有官方 wheel，跳过此步。

## 3. 包名 `eciespy` vs 导入名 `ecies`

- PyPI 包名是 **`eciespy`**（requirements.txt 里写的没错，不要改）。
- 代码内导入名是 **`ecies`**：控制端脚本使用 `from ecies import decrypt`。
- 常见错误与后果：
  - `import eciespy` → `ModuleNotFoundError: No module named 'eciespy'`。
  - `pip install ecies` → `No matching distribution found for ecies`（PyPI 不存在该包名）。
- 验证命令（与脚本实际 import 完全一致）：

```bash
/tmp/venv/bin/python -c "import ecdsa, Crypto, ecies, coincurve, noise, websockets; print('all deps OK')"
```

## 4. 验证标准与避免重复安装

- 验证命令输出 `all deps OK` 即环境可用，无需反复 `pip install`（重复执行只会显示 Requirement already satisfied，浪费时间）。
- `pip install` 报错时先看完整错误尾部：metadata 阶段报 coincurve → 执行第 2 步补丁；其他包报错 → 先确认是否在 venv 内、网络是否可用，再重试一次；仍失败按错误信息逐条排查，不要无限重试。

## 5. 连接前的密钥与地址

- ECDSA 私钥原样写入 PEM 文件（PKCS#8 或 SEC1 均可），ECIES 私钥写入 64 位 hex 文件，文件权限设为 `0600`，不要放进仓库或聊天消息。
- 地址逐字复制用户提供的 `scheme://主机[:端口]`，不要补 `/api`、不加尾随 `/`。