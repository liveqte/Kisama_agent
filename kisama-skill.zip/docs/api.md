# Kisama API 协议与接口定义（按需阅读）

本文件是协议与接口的完整参考：认证头、会话密钥、AES 请求加密、ECIES 响应解密、`/api/exec`、全部文件管理接口的原始请求/响应格式，以及推荐控制器状态机。仅当需要核对协议细节、实现自定义控制端或排查接口层问题时阅读；正常命令行操作由 `scripts/kisama_control.py` 封装完成，无需在此实现任何密码学逻辑。

## 1. 请求认证流程

除 `/api/baseinfo` 和 `/api/status` 外，接口必须认证。即使基础信息允许匿名访问，匿名响应不会提供敏感的 `session_key` 和 `noise_key`；要建立可用控制会话，必须使用 ECDSA 签名请求获取基础信息。

每次 HTTP 请求都重新生成认证头：

```text
nonce     = Base64(16 个随机字节)
timestamp = 当前 UTC Unix 秒级时间戳的十进制字符串
message   = nonce + timestamp       # 直接拼接字符串，不加分隔符
signature = ECDSA-P256-SHA256-sign(message)
X-Nonce         = nonce
X-Timestamp     = timestamp
X-Auth-Token    = Base64(signature)
Accept          = application/json
```

- 默认 ECDSA DER 签名并 Base64 编码；代理也兼容 64 字节 raw `r || s`，控制端优先 DER。
- 不要复用 nonce、不要缓存签名头。timestamp 必须接近代理端当前时间；签名过期或时间窗口错误时检查两端时钟后重试一次，不要无限重试。
- 所有受保护的 JSON 请求另加 `Content-Type: application/json`。

## 2. 第一次交互：获取并保存会话密钥

### 2.1 请求 `/api/baseinfo`

1. 用控制端 ECDSA 私钥生成本次请求的认证头。
2. `GET {base_url}/api/baseinfo`，无请求体。
3. 查看响应头 `X-Encrypted`：
   - `true`：响应体是 Base64，用控制端 ECIES 私钥解密后再解析 JSON。
   - `false`：只接受已认证的明文响应；匿名明文中的敏感字段通常是 `null`。
4. 从 JSON 读取 `session_key` 和 `noise_key`。

成功的已认证基础信息至少包含：

```json
{
  "session_key": "Base64 编码的 32 字节 AES 密钥",
  "noise_key": {
    "controller": { "private": "Base64 编码的 X25519 私钥" },
    "agent": { "public": "Base64 编码的 X25519 公钥" }
  }
}
```

- `session_key` Base64 解码为严格 32 字节的 AES 原始密钥，只保存在当前控制会话内；不要把它当作 HTTP Bearer token。
- `noise_key.controller.private` 和 `noise_key.agent.public` 保存到会话内存，是本次代理进程的动态 Noise 身份，不是永久固定配置。

### 2.2 代理重启后的处理

JavaScript 代理在进程启动时生成新的 AES `SESSION_KEY` 和 Noise X25519 密钥对。代理重启后旧 `session_key`/`noise_key` 全部失效。出现 AES 解密失败、Noise 握手失败或认证上下文失效时，重新执行一次签名的 `/api/baseinfo` 换取新密钥，不要只重复使用旧密钥。

## 3. JSON 请求体的 AES-256-GCM 加密

获取会话密钥后，所有需要 JSON 请求体的受保护接口都使用 AES-256-GCM：

```text
nonce       = 随机 12 字节
ciphertext  = AES-GCM.encrypt(明文 JSON UTF-8)
tag         = 16 字节认证标签
payload     = {
  "nonce": Base64(nonce),
  "tag": Base64(tag),
  "ciphertext": Base64(ciphertext)
}
body        = Base64(UTF-8(JSON.stringify(payload)))
```

同时设置 `X-AES-Encrypted: true` 与 `Content-Type: application/json`。

- 顺序：先把业务对象序列化为紧凑 JSON，再 AES 加密；不是先 Base64 业务字段放进 JSON，也不是把 AES 对象直接作为请求体发送。
- 每个请求使用新随机 nonce；同一个 `session_key` 可用于多个请求，但**绝不能复用 nonce**。

## 4. 响应体的 ECIES 解密

生产模式下，已认证且返回 `application/json` 的响应通常带 `X-Encrypted: true`，响应体是 ECIES secp256k1 密文的 Base64 文本：

1. 去除首尾空白。 2. Base64 解码。 3. 用控制端 ECIES 私钥解密。 4. 明文 UTF-8 解析为 JSON。

- 不要用 ECDSA 私钥或 `session_key` 解密响应；ECIES 是"代理用控制端 ECIES 公钥加密、控制端用对应私钥解密"。
- 错误响应（4xx/5xx）包装有版本差异：0.4.2+ 为单层 ECIES，更早版本可能 `{"_encrypted": "..."}` 嵌套两层；控制端脚本递归兼容两者。自定义实现时先按 `X-Encrypted` 与状态码判断再做单层/双层递归解密。
- `X-Encrypted: false` 时按明文处理。先检查状态码：401/400/500 的错误响应可能是明文 JSON，不要把错误文本当 ECIES 密文。

## 5. 命令执行：`POST /api/exec`

明文业务 JSON：

```json
{"cmd": "ls -la /tmp", "cwd": "/tmp", "env": {"LANG": "C.UTF-8"}}
```

- `cmd`：必填，代理通过配置的 shell 执行。
- `cwd`：可选，远端工作目录，不要把控制端本地目录当远端目录。
- `env`：可选，额外环境变量。

调用顺序：认证头 → AES 加密 JSON → POST → 按 `X-Encrypted` 解密。正常响应：

```json
{"result": "Linux host 6.6.123+ x86_64 ...\n", "exitcode": 0, "timeout": false, "cmd": "uname -a"}
```

退出码约定：`0` 成功 / `124` 超时 / `126` 无权限或不可执行 / `127` 命令不存在 / `-1` 代理内部异常。不要通过其他方式猜测成功。

- 输出可能混合 stdout 和 stderr，且可能为空；代理执行超时由 `EXEC_TIMEOUT` 控制，默认约 30 秒。
- 执行破坏性命令前先确认目标路径、命令作用与返回结果；不要为探测环境执行 `rm`、磁盘格式化、重启或修改防火墙等高危命令。

## 6. 文件路径与文件根目录

文件接口受代理端 `FILE_ROOT` 限制。相对路径以代理的 `FILE_ROOT` 为基准（**不是控制端当前目录**）；优先使用相对路径或已确认在 `FILE_ROOT` 内的绝对路径，不要用 `..` 穿越。

推荐流程：`list` 父目录 → `authority-get` 检查权限 → 执行读写/上传/移动/删除 → 再 list/cat/authority 验证。上传时明确区分 `local_file` 与 `remote_path`。

## 7. 文件管理接口

以下每个 JSON 接口遵循同一流程：签名请求头 → JSON 业务对象 → AES 加密 → 发送 → ECIES 解密响应。

### 7.1 列出：`POST /api/file/list`

```json
{"path":"/tmp","recursive":false}
```

响应含 `status`、`count`、`files[]`（每项 `name/path/type/size/mode/owner`）。`recursive` 只在需要时为 `true`，避免大型目录响应过大。

### 7.2 查询权限：`POST /api/file/authority`

```json
{"paths":["/tmp/memo.txt","/tmp"]}
```

检查返回的 `readable`、`writable`、`executable`、`mode_octal`，不要仅凭文件名判断权限。

### 7.3 设置权限：`PUT /api/file/authority`

```json
{"permissions": {"/tmp/memo.txt":"644","/opt/scripts":"755"}, "recursive": false}
```

仅当用户明确要求时才修改权限（有副作用操作，先确认）。八进制模式用字符串（如 `"644"`），写成 JSON 数字会丢失前导语义。

### 7.4 查看内容：`POST /api/file/cat`

```json
{"path":"/tmp/config.json"}
```

适合 ≤1 MiB 文本。返回 `content`（UTF-8 文本或二进制 Base64）、`encoding`（`utf-8`/`base64`）、`is_binary`、`size`。`is_binary: true` 时不要当普通文本，优先使用下载接口。

### 7.5 创建目录：`POST /api/file/new`

```json
{"path":"/tmp/new/project/logs"}
```

服务端递归创建；成功后用 `list` 验证。

### 7.6 移动/重命名：`PUT /api/file`

```json
{"/tmp/old.txt":"/archive/old.txt", "/tmp/logs":"/backup/logs"}
```

部分客户端包装为 `{"move_map":{...}}`，直接使用映射即可兼容。移动前确认目标位置避免覆盖或误改名。

### 7.7 复制：`POST /api/file/cp`

```json
{"/tmp/old.txt":"/archive/old.txt", "/tmp/logs":"/backup/logs"}
```

响应含 `total`、`success` 和逐项 `results`；目录复制耗磁盘，先检查容量。

### 7.8 删除：`DELETE /api/file`

```json
{"paths":["/tmp/old.log","/tmp/cache"]}
```

删除目录即递归删除，视为不可逆：先列出目标确认无路径拼接错误，响应中逐项检查 `status`。

### 7.9 JSON/Base64 上传：`POST /api/file`

```json
{"path":"/tmp/uploads", "filename":"memo.txt", "content":"SGVsbG8gS2lzYW1hIQ=="}
```

适合小文件；`content` 是文件原始字节的 Base64。大文件不用此接口（Base64 膨胀 + 再包一层 AES Base64）。

### 7.10 裸二进制上传：`POST /api/fileraw`

大文件优先。**重要例外**：请求体是原始二进制流而非 JSON，不能把文件先包进 AES JSON（否则代理会把密文当文件内容保存）。

请求头：

```text
Content-Type: application/octet-stream
X-File-Path:   URL 编码后的远端目录
X-File-Name:   URL 编码后的文件名
X-Chunk-Id:    从 0 开始的分片编号
X-Total-Chunks: 分片总数
```

单文件直传：`X-Chunk-Id: 0`、`X-Total-Chunks: 1`。请求仍必须带签名认证头（`X-Nonce`/`X-Timestamp`/`X-Auth-Token`/`Accept`），**不要**设 `X-AES-Encrypted: true`（该路由 body 必须是原始字节流）。

分片规则：按字节切分；编号从 0 连续到 total-1；每片独立认证头与 nonce；同一文件的 `X-File-Path`/`X-File-Name`/`X-Total-Chunks` 一致；控制端按序发送不要并发（避免合并竞态）；单片 ≤50 MiB（Express 流解析默认限制）；最后一片返回 `completed: true` 后用 list/authority 或 exec 校验大小与校验和。

典型响应：`{"status":"ok","path":"/tmp/uploads/data.tar.gz","chunk_id":0,"completed":false}`。该响应是 JSON，生产模式仍可能被 ECIES 加密，按响应头处理，不要因请求是二进制就跳过响应解密。

### 7.11 下载：`POST /api/file/download`

```json
{"path":"/tmp/backup.tar.gz"}
```

请求体照常 AES 加密并认证。成功响应是 `application/octet-stream` 原始字节流，通常带 `X-File-Size`、`X-Original-Path`（某些版本还有 `X-Encrypted`）。当前代理对二进制下载不做 JSON/ECIES 包装，**不要**对响应做 UTF-8 解码或 JSON 解析，直接保存；若代理明确返回 `X-Encrypted: true` 再按该版本实际协议处理。下载后核对 `X-File-Size` 与本地大小，必要时算 SHA-256。

## 8. 推荐控制器状态机

```text
DISCONNECTED
  -> KEYS_READY       检查地址、ECDSA 私钥、ECIES 私钥
  -> BOOTSTRAPPED     签名请求 baseinfo，ECIES 解密，读取 session_key/noise_key
  -> HTTP_READY       每个 JSON 请求 AES 加密，每个 JSON 响应 ECIES 解密
  -> TERMINAL_READY   使用本次 noise_key 完成 Noise XX 握手
  -> CLOSED           清理 session key、Noise cipher 和 WebSocket
```

建议封装 `sign_headers()` / `aes_encrypt_json(value, session_key)` / `ec_validate_and_decrypt_response(body, headers, ecies_private_key)` / `request_json(method, path, value)` / `upload_raw_chunk(...)` / `open_noise_terminal(base_url, noise_key, request_id)`。控制端脚本已实现这些，除非自研控制端否则不需要重复实现。

注意：**不要**把 `/api/baseinfo` 首次请求写成依赖 AES——此时还没有 `session_key`。首次请求只需 ECDSA 认证，其响应由 ECIES 私钥解密，之后才启用 AES 请求体。