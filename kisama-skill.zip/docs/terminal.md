# 超级终端：操作说明（按需阅读）

需要真实 TTY、交互式程序（`top`/`vim`/`sudo`）、连续输入输出或长期会话时使用；普通一次性命令优先走 HTTP `exec`。**调用前必须先确认 `baseinfo.version` 不含 `php`**——PHP 代理端不支持终端，用 `exec` 替代。

## 1. 调用方式

```bash
<PY> scripts/kisama_control.py ... terminal --command 'ls -la'     # 发一条命令，自动等结果
<PY> scripts/kisama_control.py ... terminal --input '原始输入'      # 发送原始输入（如密码、按键序列）
```

可选参数：`--request-id`、`--rows`/`--cols`（窗口尺寸，默认 24×80）、`--terminal-timeout`（默认 60 秒）、`--token`（HTTPS/WSS 部署需要时）。

**`--token` 的版本差异（0.4.8 安全更新）**：

| 代理版本 | `--token` 取值 |
| --- | --- |
| 0.4.8+ | `--token auto`：脚本自动计算 `Base64(HMAC-SHA256(session_key原始字节, "kisama-ws-token-v1"))`。旧式"agent 公钥当 token"在 0.4.8 上会被拒绝（close 1008） |
| 0.4.7 及更早 | 传 `noise_key.agent.public`（旧行为不变） |
| 不传 `--token` | 走 Noise 加密模式（`Noise_XX_25519_ChaChaPoly_BLAKE2s`，prologue `kisama_terminal_v1`），0.4.8 起服务端强制校验发起方静态公钥必须为 `noise_key.controller.private`——脚本已按此实现，新旧代理通用 |

**密钥轮换恢复（0.4.8 新增行为）**：代理端的 tempkey 过期时会轮换 `session_key` 与控制端 Noise 密钥对，客户端缓存的旧密钥会失效。脚本检测到 Noise 公钥不匹配或 1008 时会自动重拉 baseinfo 并重试一次，无需人工干预；若连续失败，重新执行一次 `baseinfo` 即可。

> **Windows cmd.exe 注意**：单引号在 cmd 里不是引号，含空格/特殊字符的参数请用双引号。PowerShell 与 bash 单双引号均可。

## 2. 判读结果

返回 JSON：`status`（ok / timeout）、`request_id`、`output`（PTY 原始输出，可能含 ANSI 转义）、`exitcode`。`--command` 方式脚本自带结束标记，退出码可靠；`--input` 方式靠超时结束，`exitcode` 为 null。

- 输出保留 ANSI 转义序列与换行，不要当 JSON 解析。
- 不要只靠固定睡眠判断完成，看返回的 `status`。

## 3. 长时间会话注意

- 每 10 秒自动发一次 heartbeat，脚本已处理；没有 PTY 输出不代表连接断开。
- 命令含换行、引号、二进制数据或密码提示时，优先用 `--input` 传原始字节，避免转义错误。
- 本地控制端平台不影响终端协议：`--command`/`--input` 内容始终是代理端 Linux shell 语义（远端执行）。