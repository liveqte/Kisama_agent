# 超级终端：Noise 加密 WebSocket（按需阅读）

需要真实 TTY、交互式程序（`top`/`vim`/`sudo`）、连续输入输出或长期会话时才使用本协议；普通一次性命令优先走 HTTP `exec`（有结构化退出码，更易验证）。调用 `terminal` 前必须先确认 `baseinfo.version` 不含 `php`——PHP 代理端不提供本能力，用 `exec` 替代，不要把它当故障排查。

## 1. 连接地址与模式

Noise 模式使用不带 token 的 WebSocket：

```text
ws://agent.example.com:8000/api/ws/terminal?request_id=<URL编码的唯一ID>
```

- 如果通过 HTTPS/WSS 且部署端要求 `token`，当前实现把"存在 token"视为已由 WSS 保护并跳过 Noise；没有明确 token 规范时不要自行添加。
- `request_id` 必须唯一、不可为空、URL 编码。**不要把 ECDSA、ECIES、AES 或 Noise 私钥放进查询参数。**

## 2. 生产端动态 Noise 身份

代理端使用 `Noise_XX_25519_ChaChaPoly_BLAKE2s`，序言固定为 `kisama_terminal_v1`。

代理启动时自动生成 X25519 密钥对，通过已认证的 `/api/baseinfo` 返回：

```text
controller.private  -> 控制端 initiator 的静态私钥
agent.public       -> 代理端 responder 的静态公钥
```

不要硬编码测试密钥；代理重启后必须重新 `baseinfo` 获取这两个字段。

## 3. 三步握手

控制端是 initiator，代理端是 responder。**每个握手包都必须作为 WebSocket binary frame 发送/接收**：

1. 初始化 Noise XX，设置 prologue、控制端静态私钥和预期代理静态公钥。
2. 写出 msg1，发送 binary frame。
3. 接收代理端 msg2，读入状态机。
4. 写出 msg3，发送 binary frame。
5. 握手进入 established/split 状态后才允许发送业务数据。

Python 控制端已封装（内部使用 `noiseprotocol` 的 `NoiseConnection`）：

```text
NoiseConnection.from_name(b"Noise_XX_25519_ChaChaPoly_BLAKE2s")
set_as_initiator()
set_keypair_from_private_bytes(Keypair.STATIC, Base64解码后的 controller.private)
set_prologue(b"kisama_terminal_v1")
start_handshake()
```

按 `write_message(b"") -> read_message(msg2) -> write_message(b"")` 完成三步交互。握手结束后读取远端静态公钥，**严格比较**是否等于 Base64 解码后的 `agent.public`；不要为绕过失败而关闭公钥校验。

## 4. 传输数据

- 每个方向维护独立 transport nonce：控制端发送用 initiator 发送 cipher，接收用 initiator 接收 cipher；代理端反向对应。
- 每个逻辑消息对应一次 `Encrypt`/`Decrypt`；不要重复解密、拼接密文再解密，或跨会话复用 cipher。
- 加解密均使用空 associated data；所有终端数据用 binary frame。
- 代理发送的是加密后的 **PTY 原始输出字节**，通常不是 JSON：按字节解密后输出，保留 ANSI 转义序列与换行，不要按单个 UTF-8 字符截断，也不要当 JSON 解析。

## 5. 向终端发送输入

最稳妥是发送加密后的 JSON：

```json
{"type":"input","data":"bHMgLWxhCg==","encoding":"base64"}
```

（Base64 明文是 `ls -la\n`；也可以直接把要写入 PTY 的原始字节作为明文加密发送。）

调整窗口：

```json
{"type":"resize","rows":40,"cols":120}
```

保活：

```json
{"type":"heartbeat"}
```

代理会返回加密的 heartbeat JSON。建议每 10 秒一次应用层 heartbeat，同时靠 WebSocket ping/pong 保活；不要因为没有 PTY 输出就认为连接断开。

## 6. 通过终端执行可验证命令

PTY 没有 HTTP 那样的结构化结果。批量执行并可靠判断结束时，发送带唯一标记的命令：

```sh
command_here
rc=$?
printf '\n__KISAMA_DONE__:%s__\n' "$rc"
```

持续接收、解密并缓存输出，直到识别到唯一标记，再从标记提取退出码。不要仅靠固定睡眠时间判断完成，也不要吞掉终端 ANSI 控制序列。

- 注意 shell quoting：命令含换行、引号、二进制数据或密码提示时，优先用 JSON + Base64 输入，避免 JSON 转义错误。
- 连接关闭时先停止发送任务再关 WebSocket，清理接收任务与 Noise cipher；不要复用已关闭的 cipher 重连。