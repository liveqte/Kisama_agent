# 故障排查顺序（按需阅读）

按错误现象从上到下定位；如果运行中的代理行为与本技能描述不一致，以实际返回的状态码、响应头和错误消息为准，先重新调用一次 `baseinfo` 获取当前进程的密钥，再缩小问题范围。

## 安装与环境

- `pip install` 报 `externally-managed-environment`：系统 Python 受 PEP 668 保护，改用 venv（详见 `docs/install.md` §1），不要加 `--break-system-packages`。
- `ModuleNotFoundError: No module named 'eciespy'` 或 `No matching distribution found for ecies`：包名 `eciespy` ≠ 导入名 `ecies`，按 SKILL.md §1.1 的验证命令写导入，requirements.txt 原样安装（详见 `docs/install.md` §3）。
- Python 3.14 下 coincurve 预处理报 `Expected exactly one LICENSE file in cffi distribution`：先运行 `scripts/install_coincurve_py314.sh`（详见 `docs/install.md` §2）。

## 连接与认证

- `SSL: CERTIFICATE_VERIFY_FAILED ... Hostname mismatch`：`--url` 抄错或私自补全/改了主机名，逐字核对用户提供的地址。
- `401 Missing auth headers`：确认每次请求都生成了三个 `X-*` 认证头（`X-Nonce`/`X-Timestamp`/`X-Auth-Token`）。
- `401 Signature verification failed`：确认签名原文严格是 `nonce + timestamp`，签名算法 SHA-256，ECDSA 私钥与代理配置的公钥匹配；检查两端 Unix 时间。
- 使用 `--session-cache` 后仍报 AES/认证类错误：代理进程已重启，旧会话密钥失效；脚本会自动丢弃缓存并重新 `baseinfo` 一次，仍失败则检查缓存文件是否被手工改坏或跨代理复用。
- baseinfo 没有 `session_key` 或 `noise_key`：请求可能是匿名请求，或响应解密后仍是匿名内容；用 ECDSA 签名重新请求。

## 加解密

- ECIES 解密失败：确认用的是控制端 ECIES 私钥，代理端配置的是匹配的压缩公钥；先检查 `X-Encrypted` 与 HTTP 状态码，不要把明文错误响应当密文。若提示"无法加载 ECIES 私钥"，确认密钥是 64 位 hex 或 Base64(32字节)，不要把 ECDSA PEM 或公钥误传。
- AES 解密失败：确认 `session_key` Base64 解码后是 32 字节，payload 的 `nonce/tag/ciphertext` 都是 Base64，且没有复用旧代理进程的密钥。

## 文件与终端

- 文件上传后内容错误：检查是否错误地给 `/api/fileraw` 设置了 `X-AES-Encrypted`；裸上传必须发送原始二进制。
- 分片合并失败：确认分片从 0 连续编号、总数一致、目标目录和文件名一致，并按顺序发送。
- Noise 握手失败：重新获取 `/api/baseinfo`，确认使用最新动态 Noise 私钥、公钥、协议名、序言和 initiator/responder 角色；每个握手包必须是 binary frame。
- Noise 握手后 MAC 错误：检查是否丢弃、重复或并发发送了 transport 消息，是否让多个协程同时写同一 WebSocket，是否跨重连复用了旧 cipher。
- 终端无输出：确认已经启动独立接收循环，按 binary frame 解密，并没有把 PTY 原始输出当 JSON 解析。

## 两条总则

- 如果 `baseinfo.version` 包含 `php`，不要把超级终端失败当作密钥或网络故障排查——PHP 代理本身不提供该能力，改用 `exec`。
- 运行中的代理行为与文档不一致时，以实际返回的状态码、响应头和错误消息为准；先重新 `baseinfo` 获取当前进程的密钥，再缩小范围。