# 故障排查顺序（按需阅读）

按错误现象从上到下定位。代理行为与技能描述不一致时，以实际返回的状态码、响应头和错误消息为准；先重新调用一次 `baseinfo` 获取当前进程密钥，再缩小范围。

## 平台相关（Windows 特有）

| 报错/现象 | 处理 |
| --- | --- |
| 中文 JSON 打印报 `UnicodeEncodeError` | 控制台编码非 UTF-8（GBK/cp1252）。脚本已强制 UTF-8 输出，仍遇到时设置 `PYTHONUTF8=1` 环境变量 |
| `python3: command not found` / 找不到 `/tmp/venv` | 控制端是 Windows：用 `python` 或 `py -3`，venv 解释器在 `.venv\Scripts\python.exe`，没有 `/tmp` |
| cmd.exe 下 `--cmd 'uname -a'` 报参数错误 | cmd 不识别单引号，用双引号：`exec --cmd "uname -a"` |
| 密钥/缓存文件读取报 UnicodeDecodeError | 文件被存成 UTF-16（记事本默认）或带 BOM，重新用 ASCII/UTF-8 无 BOM 保存 |
| `install_coincurve_py314.sh` 无法运行 | Windows 无 bash；见 `docs/install.md` §2，建议用 Python 3.13/3.12 |
| 缓存文件权限 0600 失效 | Windows 无 POSIX 权限位，正常现象，功能不受影响 |

## 安装与环境

| 报错 | 处理 |
| --- | --- |
| `pip install` 报 `externally-managed-environment` | 用 venv，不要 `--break-system-packages`（见 `docs/install.md` §1） |
| `ModuleNotFoundError: No module named 'eciespy'` / `No matching distribution found for ecies` | 包名 `eciespy`，导入名 `ecies`，按 SKILL.md §1 验证命令写 |
| Python 3.14 报 `Expected exactly one LICENSE file in cffi distribution` | Linux/macOS 跑 `scripts/install_coincurve_py314.sh`；Windows 换 Python 3.13/3.12（见 `docs/install.md` §2） |

## 连接与认证

| 报错 | 处理 |
| --- | --- |
| `SSL: CERTIFICATE_VERIFY_FAILED ... Hostname mismatch` | `--url` 抄错或私自补全/改主机名，逐字核对用户给的地址 |
| `HTTP 500`（空响应体）或返回 404 HTML 页面 | 带 `#` 路由的地址被手动拆分或丢失片段：目标主机必须保留在 `--url` 的 `#` 之后（脚本自动转成 `X-Target-Host` 头并拼路径前缀），不要只传网关部分 |
| `401 Missing auth headers` | 确认每次请求都有三个 `X-*` 认证头（脚本已自动生成，一般不会出现） |
| `401 Signature verification failed` | 确认 ECDSA 私钥与代理配置公钥匹配、两端时间（脚本已自动对齐服务器时钟）。0.4.8 签名协议变化由脚本自动协商（新签名 401 时自动回退旧签名），一般无需处理；特殊环境可用 `KISAMA_SIG_MODE=v1\|v2` 强制指定 |
| 使用 `--session-cache` 后仍报 AES/认证错误 | 代理已重启，脚本会自动丢缓存重取 baseinfo；仍失败检查缓存文件是否被改坏或跨代理复用 |
| baseinfo 没有 `session_key`/`noise_key` | 先看响应头：`x-encrypted: false` ⇒ 代理处于 DEBUG 模式，恒不下发密钥属正常（脚本自动识别并以明文通信，业务命令不受影响，仅 `terminal` 不可用）；头缺失 ⇒ 匿名或签名未通过，用正确的 ECDSA 私钥重新请求 |

## 加解密

| 报错 | 处理 |
| --- | --- |
| ECIES 解密失败 | 确认用的是控制端 ECIES 私钥（64 位 hex 或 Base64(32字节)），不要把 ECDSA PEM 或公钥误传。**0.5.6 起 ECIES 仅用于 `baseinfo` 握手**，其余端点响应已改为 `session_key` AES-GCM（见下行） |
| AES 解密失败 | 确认 `session_key` 是 32 字节，payload 字段都是 Base64，没复用旧代理进程密钥。**0.5.6 起非 baseinfo 响应均为 session_key AES**：先成功执行一次 `baseinfo` 握手（取得 session_key 与代理版本号）再调其他命令；报"版本需成对升级"类提示时，升级控制端或代理到匹配版本 |
| 代理版本未知导致解密方式误判 | 脚本从 baseinfo 响应 `version` 字段自动判定（`>= 0.5.6` 用 AES，旧版全 ECIES）；session-cache 里缓存过旧版本号时删除缓存文件重连 |

## 文件与终端

| 报错 | 处理 |
| --- | --- |
| 文件上传后内容错误 | 检查是否给 `/api/fileraw` 误设了 `X-AES-Encrypted`；裸上传必须原始二进制（脚本已正确处理） |
| 上传返回 `{"completed": false, "message": "Chunk received"}`（新版会直接报错拦截） | `--remote-path` 误传了远端**已存在的文件**，它应是**目标目录**（最终文件 = 目录/`--name`）。例如远端已有 `info.php` 文件时，`--remote-path info.php --name diag.php` 会被拼成 `info.php/diag.php`——PHP 代理把分片写进文件路径下的隐藏暂存目录永远无法合并，恒返回 `completed:false`（go/py/js 则建出同名目录写出嵌套文件）。正确写法：`--remote-path '.' --name '<目标文件名>'`。脚本已在上传前列父目录探测并给出此指引 |
| 上传返回 `completed:false` 且 `--remote-path` 是正常目录 | 远端目录无写权限或磁盘已满；用 `exec --cmd 'df -h; ls -ld 目标目录'` 排查，或换可写目录重试 |
| 远端找不到本地路径/文件 | `--local` 是控制端路径（Windows `C:\...`），`--remote-path`/`--path` 是代理端路径（Linux `/...`），不要混写（见 SKILL.md §2） |
| Noise 握手失败 / MAC 错误 | 重新 `baseinfo` 获取最新动态密钥；不要跨重连复用旧 cipher（脚本每次新握手） |
| 终端连接被断开（close 1008 / Noise 公钥不匹配） | 0.4.8 代理的 tempkey 过期会轮换 session_key 与控制端密钥对，脚本会自动重拉 baseinfo 重试一次；连续失败时手动执行一次 `baseinfo` 刷新密钥。0.4.8+ 明文降级模式必须用 `--token auto`（旧式 agent 公钥 token 已失效） |
| 终端无输出 | 确认已启动独立接收循环并按 binary frame 解密（脚本已处理）；不要当 JSON 解析 PTY 输出 |

## 两条总则

- `baseinfo.version` 含 `php`：不要排查终端失败——PHP 代理不支持终端，改用 `exec`。
- 代理行为与文档不一致：以实际状态码、响应头、错误消息为准，先重新 `baseinfo` 再缩小范围。