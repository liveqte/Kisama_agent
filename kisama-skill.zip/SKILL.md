---
name: kisama-control
description: 通过 Kisama Agent 的加密 HTTP API 和 Noise WebSocket 超级终端，对已部署的 Kisama 代理执行系统命令、浏览和管理文件、上传文件以及进行交互式终端操作。用户要求连接、控制、运维、执行命令或上传文件到 Kisama Agent 时使用。
compatibility: Created for Zo Computer; requires network access to the Kisama Agent, the controller ECDSA private key and ECIES private key, plus Python crypto/WebSocket libraries when implementing a client.
metadata:
  author: elfinpeak.zo.computer
---
# Kisama Agent 控制端技能

本技能是自包含的。执行 Kisama 运维任务时，优先调用本目录自带的 `file scripts/kisama_control.py`，不需要阅读仓库中的其他文档、测试或控制端实现。密码学、HTTP 封装、响应解密、文件传输和 Noise 握手已经封装在脚本中；大模型只需要准备连接参数、选择子命令、读取 JSON 结果并据此继续操作。

本技能只覆盖以下接口：

- 基础信息：`GET /api/baseinfo`
- 命令执行：`POST /api/exec`
- 文件管理：`/api/file/list`、`/api/file/authority`、`/api/file/cat`、`/api/file`、`/api/fileraw`、`/api/file/download`、`/api/file/cp`、`/api/file/new`
- 超级终端：`WS /api/ws/terminal`

不要为了完成普通命令或文件任务调用其他未覆盖接口。优先使用 HTTP 命令执行和文件接口；只有需要真实 TTY、交互式程序、终端尺寸或持续会话时才使用超级终端。

## PHP 代理端限制

执行任何 `terminal` 操作前，必须先读取本次 `baseinfo` 返回的 `version` 字段，并进行不区分大小写的判断。如果 `version` 包含 `php`，说明目标是 PHP 代理端。PHP 代理端不支持 `/api/ws/terminal` 和 Noise 超级终端，此时严禁调用 `terminal` 或尝试 Noise 握手；普通命令改用 `exec`，如果用户要求交互式终端，应明确说明当前代理不支持该能力。

## 1. 最短使用路径：用内置 Python 控制端连接代理

### 1.1 安装一次依赖

本技能自带可直接调用的控制端：

```text
scripts/kisama_control.py
```

首次使用时执行：

```bash
python3 -m pip install -r scripts/requirements.txt
```

控制端支持命令行和 Python API。大模型通常只需要调用命令行，不需要自己实现签名、AES、ECIES 或 Noise。脚本的全局参数名称是 `--url`、`--ecdsa-key`、`--ecies-key`；不要使用其他名称。仓库内脚本位于 `tools/skill/scripts/kisama_control.py`。

### 1.2 连接预检：先运行 `baseinfo`

执行任何远端操作前，先运行：

```bash
python3 scripts/kisama_control.py \
  --url 'http://agent.example.com:8000' \
  --ecdsa-key '/secure/control_ecdsa.pem' \
  --ecies-key '/secure/control_ecies.hex' \
  baseinfo
```

成功表示地址和两把控制端私钥都可用，并且脚本已获取本次代理进程的 `session_key` 和 `noise_key`。脚本只在当前进程内保存这些会话密钥；不要把 `baseinfo` 的完整输出复制到用户可见消息、日志或文件中（CLI 输出中 `session_key`/`noise_key` 已自动脱敏为 `***masked***`）。

如果密钥通过环境变量提供，可省略对应参数：

```bash
export KISAMA_URL='http://agent.example.com:8000'
export KISAMA_ECDSA_KEY='/secure/control_ecdsa.pem'
export KISAMA_ECIES_KEY='/secure/control_ecies.hex'
python3 scripts/kisama_control.py baseinfo
```

### 1.3 执行非交互式命令

```bash
python3 scripts/kisama_control.py \
  --url 'http://agent.example.com:8000' \
  --ecdsa-key '/secure/control_ecdsa.pem' \
  --ecies-key '/secure/control_ecies.hex' \
  exec --cmd 'uname -a' --cwd '/tmp'
```

脚本会自动获取会话密钥、签名请求、加密请求体和解密响应。检查 JSON 中的 `exitcode`，只有 `exitcode == 0` 才算命令成功；`result` 是命令输出。单次 HTTP 请求默认超时 30 秒，可用全局参数 `--timeout` 调整（单位秒）。

### 1.4 上传文件

```bash
python3 scripts/kisama_control.py \
  --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" \
  upload --local '/home/user/package.tar.gz' --remote-path '/tmp/uploads'
```

远端文件名默认取本地文件名；需要改名时使用 `--name`。脚本自动按顺序发送裸二进制分片，不要额外加密上传内容。上传片超时按分片大小自动放宽（保守按 256KB/s 估算），大文件无需手动调大 `--timeout`。上传后用 `list` 或远端 `exec` 校验文件是否存在、大小和校验和。

### 1.5 下载文件

```bash
python3 scripts/kisama_control.py \
  --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" \
  download --remote-path '/tmp/result.tar.gz' --local '/home/user/result.tar.gz'
```

### 1.6 文件操作子命令

```text
baseinfo
exec --cmd CMD [--cwd DIR] [--env KEY=VALUE]
list [--path PATH] [--recursive]
cat --path PATH
authority-get PATH [PATH ...]
authority-set PATH=MODE [PATH=MODE ...] [--recursive]
mkdir --path PATH
move FROM=TO [FROM=TO ...]
copy FROM=TO [FROM=TO ...]
delete PATH [PATH ...]
upload --local FILE --remote-path DIR [--name NAME] [--chunk-size BYTES]
download --remote-path PATH --local FILE
terminal (--command CMD | --input TEXT) [--rows N] [--cols N]
```

示例：

```bash
python3 scripts/kisama_control.py --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" list --path '/tmp'
python3 scripts/kisama_control.py --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" cat --path '/tmp/config.json'
python3 scripts/kisama_control.py --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" mkdir --path '/tmp/uploads'
python3 scripts/kisama_control.py --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" delete '/tmp/old.log'
python3 scripts/kisama_control.py --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" move '/tmp/a=/tmp/b'
python3 scripts/kisama_control.py --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" copy '/tmp/a=/tmp/c'
```

删除、覆盖、移动和权限修改属于有副作用操作，执行前先确认目标。

### 1.7 超级终端

需要真实 TTY、交互式程序或连续输入输出时调用：

```bash
python3 scripts/kisama_control.py \
  --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" \
  terminal --command 'uname -a'
```

脚本会获取动态 `noise_key`、完成 Noise XX 握手、建立终端、发送命令并读取唯一结束标记。一次性非交互命令优先使用 `exec`。`terminal --input` 用于发送原始输入但没有结构化退出码，适合交互式输入或持续会话。

调用 `terminal` 前必须确认 `baseinfo.version` 不包含 `php`；先获取基础信息再决定是否使用超级终端。

### 1.8 同一 Python 进程内复用连接状态

CLI 每次运行都是一个新进程；如果要连续执行多个动作，直接在脚本中导入控制端并复用 `KisamaClient`：

```python
import asyncio
from importlib.util import module_from_spec, spec_from_file_location

spec = spec_from_file_location("kisama_control", "scripts/kisama_control.py")
module = module_from_spec(spec)
spec.loader.exec_module(module)

client = module.KisamaClient(
    "http://agent.example.com:8000",
    "/secure/control_ecdsa.pem",
    "/secure/control_ecies.hex",
)
info = client.bootstrap()
result = client.request_json("POST", "/api/exec", {"cmd": "uname -a", "cwd": "/tmp"})
print(result)
asyncio.run(client.terminal(command="stty size"))
```

大模型优先使用 CLI；只有需要在一个流程中连续操作、复用密钥状态或处理多步结果时才使用 Python API。脚本不会把私钥发送给代理，也不会将私钥写入输出。

### 1.9 跨命令复用会话（`--session-cache`）

连续执行多个命令时，每次 CLI 调用都要重复一次签名的 `baseinfo` 换取 `session_key/noise_key`。可以用 `--session-cache` 把会话密钥缓存到 JSON 文件，后续调用直接复用，跳过重复握手：

```bash
python3 scripts/kisama_control.py --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" \
  --session-cache '/tmp/kisama_session.json' baseinfo
python3 scripts/kisama_control.py --url "$KISAMA_URL" --ecdsa-key "$KISAMA_ECDSA_KEY" --ecies-key "$KISAMA_ECIES_KEY" \
  --session-cache '/tmp/kisama_session.json' exec --cmd 'uname -a'
```

- 缓存文件权限自动设为 `0600`；也可以直接导出 `KISAMA_SESSION_CACHE=/path/to/cache.json` 全局生效。
- 代理重启后旧会话密钥失效：脚本遇到认证/解密类错误会自动删除缓存并重新执行一次 `baseinfo`，无需手工清理。
- 缓存与目标代理绑定，不要跨代理复用同一个缓存文件。

### 1.10 查看帮助

```bash
python3 scripts/kisama_control.py --help
python3 scripts/kisama_control.py terminal --help
```

## 2. 先确认控制端密钥和目标地址

控制端只需要**两把私钥**：ECDSA 私钥（签名请求）和 ECIES 私钥（解密响应）。**公钥完全不需要**——代理端配置的是与你对应的公钥，`baseinfo` 之外的接口全部由签名+会话密钥认证。无论用户/面板提供了多少密钥材料，只向脚本传这两把私钥即可：

| 控制端私钥 | 格式（脚本自动识别） | 用途 |
| --- | --- | --- |
| ECDSA P-256 私钥 | PEM（`-----BEGIN EC PRIVATE KEY-----`） | 对每个 HTTP 请求生成签名 |
| ECIES secp256k1 私钥 | **64 位 hex 或 Base64(32字节)** 均可 | 解密代理端的响应 |

`/api/tempkey`（0.4.2+）下发的 `ecdsa.private_key` 为 **ECDSA P-256**（secp256r1/prime256v1）SEC1 PEM、`ecies.private_key` 为 64 位 hex（secp256k1），均可原样传给脚本，无需转换；旧版本 ECIES 下发 Base64 也被脚本自动兼容。

控制端私钥不是从 `/api/baseinfo` 获取的。它们在部署控制端时生成，代理端只配置对应的公钥。不要把私钥打印到日志、命令输出、聊天消息、URL 或请求头以外的地方；不要把密钥写进仓库。

代理地址从用户提供的 URL 获取，例如：

```text
http://agent.example.com:8000
https://agent.example.com
```

地址应只保留 scheme、主机和端口，不要重复拼接 `/api`。默认端口由代理的 `KPORT`、`PORT` 或 `SERVER_PORT` 决定，均未设置时是 `8000`。

如果缺少 ECDSA 私钥、ECIES 私钥或目标地址，不要猜测，也不要尝试匿名执行命令。先报告缺少哪一项。

## 3. Kisama 的请求认证流程

除 `/api/baseinfo` 和 `/api/status` 外，接口必须认证。即使基础信息接口允许匿名访问，匿名响应不会提供敏感的 `session_key` 和 `noise_key`；要建立可用控制会话，必须使用 ECDSA 签名请求获取基础信息。

每次 HTTP 请求都重新生成认证头：

```text
nonce     = Base64(16 个随机字节)
timestamp = 当前 UTC Unix 秒级时间戳的十进制字符串
message   = nonce + timestamp       # 直接拼接字符串，不加分隔符
signature = ECDSA-P256-SHA256-sign(message)
X-Nonce         = nonce
X-Timestamp     = timestamp
X-Auth-Token    = Base64(signature)
Accept          = application/json
```

默认使用 ECDSA DER 签名并 Base64 编码。代理实现也兼容 64 字节 raw `r || s` 格式，但控制端应优先使用 DER。

不要复用 nonce，不要缓存签名头。timestamp 必须接近代理端当前时间；如果出现签名过期或时间窗口错误，检查两端时钟后重试一次，不要无限重试。

所有受保护的 JSON 请求还要设置：

```text
Content-Type: application/json
```

## 4. 第一次交互：获取并保存会话密钥

### 4.1 请求 `/api/baseinfo`

第一次调用必须：

1. 用控制端 ECDSA 私钥生成本次请求的认证头。
2. `GET {base_url}/api/baseinfo`，无请求体。
3. 查看响应头 `X-Encrypted`。
4. 如果 `X-Encrypted: true`，将响应体视为 Base64 字符串，使用控制端 ECIES 私钥解密，再解析得到 JSON。
5. 如果 `X-Encrypted: false`，只接受已认证的明文响应；生产环境下匿名明文中的敏感字段通常是 `null`。
6. 从 JSON 读取 `session_key` 和 `noise_key`。

成功的已认证基础信息至少应包含：

```json
{
  "session_key": "Base64 编码的 32 字节 AES 密钥",
  "noise_key": {
    "controller": { "private": "Base64 编码的 X25519 私钥" },
    "agent": { "public": "Base64 编码的 X25519 公钥" }
  }
}
```

将 `session_key` Base64 解码为严格 32 字节的原始 AES 密钥，并只保存在当前控制会话内。不要把 Base64 字符串误当作 AES 原始密钥，也不要把 `session_key` 当作 HTTP Bearer token。

将 `noise_key.controller.private` 和 `noise_key.agent.public` 保存到当前终端会话的内存状态中。它们是本次代理进程的动态 Noise 身份，不是永久固定配置。

### 4.2 代理重启后的处理

JavaScript 代理在进程启动时生成新的：

- AES `SESSION_KEY`
- 控制端和代理端的 Noise X25519 密钥对

因此代理重启后旧的 `session_key` 和 `noise_key` 都失效。出现 AES 解密失败、Noise 握手失败或认证上下文失效时，重新执行一次签名的 `/api/baseinfo`，用新数据替换旧状态；不要只重复使用旧密钥。

## 5. JSON 请求体的 AES-256-GCM 加密

第一次获取会话密钥后，所有需要 JSON 请求体的受保护接口都使用 AES-256-GCM。请求体格式是：

```text
nonce       = 随机 12 字节
ciphertext  = AES-GCM.encrypt(明文 JSON UTF-8)
tag         = 16 字节认证标签
payload     = {
  "nonce": Base64(nonce),
  "tag": Base64(tag),
  "ciphertext": Base64(ciphertext)
}
body        = Base64(UTF-8(JSON.stringify(payload)))
```

同时设置：

```text
X-AES-Encrypted: true
Content-Type: application/json
```

注意顺序：先把业务对象序列化为紧凑或普通 JSON，再用 AES 加密；不是先 Base64 业务字段，也不是把 AES 对象直接作为 JSON 请求体发送。服务端解密后再解析业务 JSON。

示例明文：

```json
{"cmd":"uname -a","cwd":"/tmp"}
```

发送的 HTTP body 是一整段 Base64 文本，而不是上面的明文 JSON。每个请求使用新的随机 nonce；同一个 `session_key` 可以用于多个请求，但绝不能复用 nonce。

## 6. 响应体的 ECIES 解密

生产模式下，已认证且返回 `application/json` 的响应通常具有：

```text
X-Encrypted: true
```

此时响应体是 ECIES secp256k1 密文的 Base64 文本：

1. 去除首尾空白。
2. Base64 解码。
3. 用控制端 ECIES 私钥解密。
4. 将明文 UTF-8 解析为 JSON。

不要使用 ECDSA 私钥解密，也不要用 `session_key` 解密响应。ECIES 是“代理用控制端提供的 ECIES 公钥加密、控制端用对应私钥解密”。

错误响应（4xx/5xx）的包装版本有差异：0.4.2+ 为**单层 ECIES**，更早版本可能出现 `{"_encrypted": "..."}` 嵌套两层。控制端脚本对两种形式都递归兼容，直接读取即可；实现自定义控制端时，先按 `X-Encrypted` 与状态码判断，再做单层/双层递归解密。

如果 `X-Encrypted: false`，直接按明文处理。处理响应前先检查 HTTP 状态码：401/400/500 的错误响应可能是明文 JSON，不要把错误文本强行当作 ECIES 密文。

## 7. 命令执行：`POST /api/exec`

这是执行非交互式系统命令的首选接口。

明文业务 JSON：

```json
{
  "cmd": "ls -la /tmp",
  "cwd": "/tmp",
  "env": {"LANG": "C.UTF-8"}
}
```

字段说明：

- `cmd`：必填。代理会通过配置的 shell 执行。
- `cwd`：可选。远端工作目录；不要把控制端本地目录当成远端目录。
- `env`：可选。额外环境变量。

调用顺序：生成认证头 → AES 加密 JSON → POST `/api/exec` → 按 `X-Encrypted` 解密响应。

正常响应类似：

```json
{
  "result": "Linux host 6.6.123+ x86_64 ...\n",
  "exitcode": 0,
  "timeout": false,
  "cmd": "uname -a"
}
```

退出码通常按以下方式判断：

- `0`：成功
- `124`：超时
- `126`：权限不足或不可执行
- `127`：命令不存在
- `-1`：代理内部异常

不要通过接口返回的 `exitcode` 以外猜测成功。输出可能混合 stdout 和 stderr，且可能为空。代理执行超时由 `EXEC_TIMEOUT` 控制，默认约 30 秒；长任务应交给代理后台机制或使用超级终端，但本技能不实现任务管理接口。

执行具有破坏性的命令前，先确认目标路径、命令作用和返回结果；不要为了探测环境执行 `rm`、磁盘格式化、重启或修改防火墙等高风险命令。

## 8. 文件路径和文件根目录

文件接口最终受代理端 `FILE_ROOT` 限制。相对路径以代理的 `FILE_ROOT` 为基准，不是控制端当前目录。优先使用相对路径或已确认在 `FILE_ROOT` 内的绝对路径；不要使用 `..` 穿越目录。

推荐流程：

1. 用 `/api/file/list` 检查父目录。
2. 用 `/api/file/authority` 检查目标权限。
3. 执行读写、上传、移动或删除。
4. 再次 list/cat/authority 验证结果。

不要把控制端本地文件路径直接当作远端路径。上传时要明确区分 `local_file` 和 `remote_path`。

## 9. 文件管理接口

以下每个 JSON 接口都遵循同一通用流程：请求头签名 → JSON 业务对象 → AES 加密 → 发送 → ECIES 解密 JSON 响应。

### 9.1 列出文件：`POST /api/file/list`

明文业务 JSON：

```json
{"path":"/tmp","recursive":false}
```

响应：

```json
{
  "status":"ok",
  "count":1,
  "files":[
    {"name":"memo.txt","path":"tmp/memo.txt","type":"file","size":24,"mode":"-rw-r--r--","owner":"1000:1000"}
  ]
}
```

`recursive` 只在确实需要时设为 `true`，避免大型目录造成过大的响应。

### 9.2 查询权限：`POST /api/file/authority`

```json
{"paths":["/tmp/memo.txt","/tmp"]}
```

检查返回的 `readable`、`writable`、`executable`、`mode_octal`，不要仅凭文件名判断权限。

### 9.3 设置权限：`PUT /api/file/authority`

```json
{
  "permissions": {"/tmp/memo.txt":"644","/opt/scripts":"755"},
  "recursive": false
}
```

只有用户明确要求时才修改权限。八进制模式使用字符串，例如 `"644"`、`"755"`；不要把 `644` 写成 JSON 数字导致前导语义丢失。递归修改前先确认目录范围。

### 9.4 查看内容：`POST /api/file/cat`

```json
{"path":"/tmp/config.json"}
```

接口适合不超过 1 MiB 的文本文件。返回字段：

- `content`：UTF-8 文本，或二进制的 Base64 内容
- `encoding`：通常为 `utf-8` 或 `base64`
- `is_binary`：是否检测为二进制
- `size`：文件大小

发现 `is_binary: true` 时不要把 `content` 当作普通文本；优先使用下载接口。

### 9.5 创建目录：`POST /api/file/new`

```json
{"path":"/tmp/new/project/logs"}
```

服务端递归创建目录。成功后应通过 list 验证。

### 9.6 移动或重命名：`PUT /api/file`

业务 JSON 是源路径到目标路径的映射：

```json
{
  "/tmp/old.txt":"/archive/old.txt",
  "/tmp/logs":"/backup/logs"
}
```

部分客户端也包装成 `{"move_map":{...}}`，但直接使用映射兼容仓库实现。移动前确认目标是否存在，避免覆盖或误改名。

### 9.7 复制：`POST /api/file/cp`

```json
{
  "/tmp/old.txt":"/archive/old.txt",
  "/tmp/logs":"/backup/logs"
}
```

响应含 `total`、`success` 和逐项 `results`。目录复制可能消耗较多磁盘空间，执行前先检查容量。

### 9.8 删除：`DELETE /api/file`

```json
{"paths":["/tmp/old.log","/tmp/cache"]}
```

删除目录是递归删除。必须把删除当作不可逆操作：在执行前列出目标、确认没有路径拼接错误，并在响应中逐项检查 `status`。

### 9.9 JSON/Base64 上传：`POST /api/file`

适合小文件或已经在内存中的内容。明文业务 JSON：

```json
{
  "path":"/tmp/uploads",
  "filename":"memo.txt",
  "content":"SGVsbG8gS2lzYW1hIQ=="
}
```

`content` 是文件原始字节的 Base64，不是文本内容再次编码后的自定义格式。大文件不要使用此接口；Base64 会膨胀体积，并且请求体还要再包一层 AES Base64。

### 9.10 裸二进制上传：`POST /api/fileraw`

大文件优先使用此接口。它是一个重要例外：请求体是原始二进制流，不是 JSON，不能把原始文件先包进 AES JSON，否则代理会把密文当作文件内容保存。

请求头：

```text
Content-Type: application/octet-stream
X-File-Path: URL 编码后的远端目录
X-File-Name: URL 编码后的文件名
X-Chunk-Id: 从 0 开始的分片编号
X-Total-Chunks: 分片总数
```

单文件直传时：

```text
X-Chunk-Id: 0
X-Total-Chunks: 1
```

请求仍然必须带 `X-Nonce`、`X-Timestamp`、`X-Auth-Token` 和 `Accept`。不要设置 `X-AES-Encrypted: true`，因为该路由的 body 必须保持原始字节流。

分片上传规则：

1. 按文件字节切分，不按字符切分。
2. 分片编号从 `0` 连续到 `total_chunks - 1`。
3. 每片使用独立的认证头和随机 nonce。
4. 同一个目标文件的 `X-File-Path`、`X-File-Name`、`X-Total-Chunks` 必须保持一致。
5. 控制端应按顺序发送分片；不要并发发送同一文件的分片，避免合并竞态。
6. 单片大小保守控制在 50 MiB 以下，因为 Express 原始流解析器默认限制约为 50 MiB；若部署端明确提高了限制再调整。
7. 最后一片返回 `completed: true` 后，再用 list/authority 或 exec 校验最终文件大小和校验和。

典型响应：

```json
{"status":"ok","path":"/tmp/uploads/data.tar.gz","chunk_id":0,"completed":false}
```

该响应是 JSON，生产模式下仍可能被 ECIES 加密；按照响应头处理，而不是因为请求是二进制就跳过响应解密。

### 9.11 下载：`POST /api/file/download`

请求业务 JSON：

```json
{"path":"/tmp/backup.tar.gz"}
```

请求体照常 AES 加密并认证。成功响应是 `application/octet-stream` 原始字节流；通常会带 `X-File-Size` 和 `X-Original-Path`，某些版本还会带 `X-Encrypted`。当前代理实现对二进制下载不会按 JSON 响应交给 ECIES 包装，因此不能把响应先 UTF-8 解码或按 JSON 解析。

收到二进制响应时直接保存。如果运行中的代理明确返回 `X-Encrypted: true`，先依据该版本的实际协议处理；不要盲目把原始二进制 Base64/JSON 解析。下载后用 `X-File-Size` 和本地实际大小核对，必要时计算 SHA-256。

## 10. 超级终端：Noise 加密 WebSocket

PHP 代理端是明确例外，`version` 包含 `php` 时不要继续连接 WebSocket；使用 `exec` 替代非交互式命令。

### 10.1 何时使用

超级终端用于：

- 交互式 shell 或需要 PTY 的程序
- `top`、`vim`、`sudo`、交互式安装器等
- 需要发送按键、调整终端大小或保持长期会话
- HTTP `/api/exec` 无法可靠表达的连续输入/输出

普通一次性命令不要优先使用 WebSocket；HTTP 接口有明确的退出码和结果，更容易验证。

### 10.2 连接地址和模式

Noise 模式使用不带 token 的 WebSocket：

```text
ws://agent.example.com:8000/api/ws/terminal?request_id=<URL编码的唯一ID>
```

如果通过 HTTPS/WSS 并且部署端要求 `token`，当前实现会把“存在 token”视为已由 WSS 保护并跳过 Noise。不要在没有明确 token 规范时自行添加 token；用户要求 Noise 通信时使用 `ws://`/无 token 模式，并完成下面的握手。

`request_id` 必须唯一、不可为空，且应 URL 编码。不要把 ECDSA、ECIES、AES 或 Noise 私钥放进查询参数。

### 10.3 生产端动态 Noise 身份

代理端的 JavaScript 实现使用 Noise：

```text
Noise_XX_25519_ChaChaPoly_BLAKE2s
```

序言固定为：

```text
kisama_terminal_v1
```

生产端在启动时自动生成 X25519 密钥对，并通过已认证的 `/api/baseinfo` 返回：

```text
controller.private  -> 控制端 initiator 的静态私钥
agent.public       -> 代理端 responder 的静态公钥
```

不要硬编码测试文件中的密钥。代理重启后必须重新获取基础信息和这两个字段。

### 10.4 三步握手

控制端是 initiator，代理端是 responder。每个握手包都必须作为一个 WebSocket binary frame 发送和接收：

```text
1. 控制端初始化 Noise XX，设置 prologue、控制端静态私钥和预期代理静态公钥。
2. 控制端写出 msg1，发送 binary frame。
3. 接收代理端 msg2，读入 Noise 状态机。
4. 控制端写出 msg3，发送 binary frame。
5. 握手进入 established/split 状态后才允许发送业务数据。
```

Python 控制端已经封装了 Noise 客户端。内部使用 `noiseprotocol` 的 `NoiseConnection`，配置如下：

```text
NoiseConnection.from_name(b"Noise_XX_25519_ChaChaPoly_BLAKE2s")
set_as_initiator()
set_keypair_from_private_bytes(Keypair.STATIC, Base64解码后的 controller.private)
set_prologue(b"kisama_terminal_v1")
start_handshake()
```

然后按 `write_message(b"") -> read_message(msg2) -> write_message(b"")` 完成三步交互。握手结束后，读取 Noise 状态中的远端静态公钥，并严格比较它是否等于 Base64 解码后的 `agent.public`。不要为了绕过失败而关闭公钥校验，也不要硬编码任何 Noise 密钥。

### 10.5 传输数据

握手完成后，每个终端方向都维护自己的 Noise transport nonce 状态：

- 控制端发送：使用 initiator 的发送 cipher 加密。
- 控制端接收：使用 initiator 的接收 cipher 解密。
- 代理端反向使用对应的发送/接收 cipher。
- 每一个逻辑消息对应一个 `Encrypt`/`Decrypt`，不要重复解密、拼接密文后再解密，或跨会话复用 cipher。
- 加密和解密都使用空 associated data。
- 所有终端数据使用 binary frame。

代理向控制端发送的是加密后的 PTY 原始输出字节，通常不是 JSON。控制端必须按字节解密后再输出，保留 ANSI 转义序列和换行，不要强制按单个 UTF-8 字符截断。

### 10.6 向终端发送输入

最稳妥的是发送加密后的 JSON：

```json
{"type":"input","data":"bHMgLWxhCg==","encoding":"base64"}
```

上例中的 Base64 明文是 `ls -la\n`。也可以直接把要写入 PTY 的原始字节作为明文加密发送。

调整窗口：

```json
{"type":"resize","rows":40,"cols":120}
```

保活：

```json
{"type":"heartbeat"}
```

代理会返回加密的 heartbeat JSON。建议每 10 秒发送一次应用层 heartbeat，同时让 WebSocket 库的 ping/pong 保活；不要因为没有 PTY 输出就认为连接断开。

### 10.7 通过终端执行可验证命令

PTY 没有 HTTP 那样的结构化结果。若要批量执行命令并可靠判断结束，可发送带唯一标记的命令：

```sh
command_here
rc=$?
printf '\n__KISAMA_DONE__:%s__\n' "$rc"
```

持续接收、解密并缓存输出，直到识别到唯一标记，再从标记提取退出码。不要仅依靠固定睡眠时间判断命令完成，也不要吞掉终端的 ANSI 控制序列。

发送命令时要注意 shell quoting；用户提供的命令若包含换行、引号、二进制数据或密码提示，应优先使用 JSON + Base64 输入，避免 JSON 转义错误。

连接关闭时，先停止发送任务，再关闭 WebSocket；清理接收任务和 Noise cipher。不要复用已经关闭的 cipher 进行重连。

## 11. 推荐的控制器状态机

实现控制器时保持下面的状态：

```text
DISCONNECTED
  -> KEYS_READY       检查地址、ECDSA 私钥、ECIES 私钥
  -> BOOTSTRAPPED     签名请求 baseinfo，ECIES 解密，读取 session_key/noise_key
  -> HTTP_READY       每个 JSON 请求 AES 加密，每个 JSON 响应 ECIES 解密
  -> TERMINAL_READY   使用本次 noise_key 完成 Noise XX 握手
  -> CLOSED           清理 session key、Noise cipher 和 WebSocket
```

建议封装这些函数，而不是在每个接口中重复密码学代码：

```text
sign_headers()
aes_encrypt_json(value, session_key)
ec_validate_and_decrypt_response(body, headers, ecies_private_key)
request_json(method, path, value)
upload_raw_chunk(local_file, remote_path, filename, chunk_id, total_chunks)
open_noise_terminal(base_url, noise_key, request_id)
```

不要把 `/api/baseinfo` 的首次请求写成依赖 AES，因为此时还没有 `session_key`。首次请求只需 ECDSA 认证；其响应由 ECIES 私钥解密。之后才启用 AES 请求体。

## 12. 故障排查顺序

- `401 Missing auth headers`：确认每次请求都生成了三个 `X-*` 认证头。
- `401 Signature verification failed`：确认签名原文严格是 `nonce + timestamp`，签名算法是 SHA-256，ECDSA 私钥与代理配置的公钥匹配；检查 Unix 时间。
- 使用 `--session-cache` 后仍报 AES/认证类错误：代理进程已重启，旧会话密钥失效；脚本会自动丢弃缓存并重新 `baseinfo` 一次，仍失败则检查缓存文件是否被手工改坏或跨代理复用。
- baseinfo 没有 `session_key` 或 `noise_key`：请求可能是匿名请求，或响应解密后仍是匿名内容；用 ECDSA 签名重新请求。
- ECIES 解密失败：确认使用的是控制端 ECIES 私钥，代理端配置的是匹配的压缩公钥；先检查 `X-Encrypted` 和 HTTP 状态码，不要把明文错误响应当密文。若提示“无法加载 ECIES 私钥”，确认密钥是 64 位 hex 或 Base64(32字节)，不要把 ECDSA PEM 或公钥误传。
- AES 解密失败：确认 `session_key` Base64 解码后是 32 字节，payload 的 `nonce/tag/ciphertext` 都是 Base64，且没有复用旧代理进程的密钥。
- 文件上传后文件内容错误：检查是否错误地给 `/api/fileraw` 设置了 `X-AES-Encrypted`；裸上传必须发送原始二进制。
- 分片合并失败：确认分片从 0 连续编号、总数一致、目标目录和文件名一致，并按顺序发送。
- Noise 握手失败：重新获取 `/api/baseinfo`，确认使用最新动态 Noise 私钥、公钥、协议名、序言和 initiator/responder 角色；每个握手包必须是 binary frame。
- Noise 握手后 MAC 错误：检查是否丢弃、重复或并发发送了 transport 消息，是否让多个协程同时写同一 WebSocket，是否跨重连复用了旧 cipher。
- 终端无输出：确认已经启动独立接收循环，按 binary frame 解密，并没有把 PTY 原始输出当 JSON 解析。

如果 `baseinfo.version` 包含 `php`，不要把超级终端失败当作密钥或网络故障排查，PHP 代理本身不提供该功能。

如果运行中的代理行为与本技能描述不一致，以实际返回的状态码、响应头和错误消息为准；先重新调用 `baseinfo` 获取当前进程的密钥，再缩小问题范围。