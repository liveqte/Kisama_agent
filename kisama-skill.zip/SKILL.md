---
name: kisama-control
description: 通过 Kisama Agent 的加密 HTTP API 和 Noise WebSocket 超级终端，对已部署的 Kisama 代理执行系统命令、浏览和管理文件、上传文件以及进行交互式终端操作。用户要求连接、控制、运维、执行命令或上传文件到 Kisama Agent 时使用。
compatibility: Created for Zo Computer; requires network access to the Kisama Agent, the controller ECDSA private key and ECIES private key, plus Python crypto/WebSocket libraries when implementing a client.
metadata:
  author: elfinpeak.zo.computer
---

# Kisama Agent 控制技能

本技能是自包含的。执行 Kisama 运维任务时，优先调用本目录自带的 `scripts/kisama_control.py`，不需要阅读仓库中的其他文档、测试或控制端实现。密码学、HTTP 封装、响应解密、文件传输和 Noise 握手已经封装在脚本中；大模型只需要准备连接参数、选择子命令、读取 JSON 结果并据此继续操作。

本技能只覆盖以下接口：

- 基础信息：`GET /api/baseinfo`
- 命令执行：`POST /api/exec`
- 文件管理：`/api/file/list`、`/api/file/authority`、`/api/file/cat`、`/api/file`、`/api/fileraw`、`/api/file/download`、`/api/file/cp`、`/api/file/new`
- 超级终端：`WS /api/ws/terminal`

不要为了完成普通命令或文件任务调用其他未覆盖接口。优先使用 HTTP 命令执行和文件接口；只有需要真实 TTY、交互式程序、持续会话时才使用超级终端。

## PHP 代理端限制（重要）

执行任何 `terminal` 操作前，必须先读取本次 `baseinfo` 返回的 `version` 字段，不区分大小写判断：如果包含 `php`，目标就是 PHP 代理端，**不支持 `/api/ws/terminal` 与 Noise 超级终端，严禁调用 `terminal` 或尝试 Noise 握手**；普通命令改用 `exec`，用户要求交互式终端时明确说明当前代理不支持该能力。

## 1. 快速开始

### 1.1 安装依赖（一次性，成功后无需重复）

控制端：`scripts/kisama_control.py`（技能目录：zip 解压后即技能目录，仓库内为 `tools/skill/`；下文路径均相对技能目录）。**不要对系统 Python 直接 `pip install`**（Ubuntu 23.04+/Debian 12+ 的 PEP 668 会拒绝）。完整安装排错见 `docs/install.md`，标准流程：

```bash
python3 -m venv /tmp/venv                                  # 1) 虚拟环境
# 2) 仅 Python 3.14：先跑技能自带补丁，否则 coincurve 报 cffi LICENSE 错误
#    scripts/install_coincurve_py314.sh /tmp/venv/bin/python
/tmp/venv/bin/python -m pip install -r scripts/requirements.txt
/tmp/venv/bin/python -c "import ecdsa, Crypto, ecies, coincurve, noise, websockets; print('all deps OK')"
```

最易踩的坑：PyPI 包名是 `eciespy`，**导入名是 `ecies`**——验证永远写 `ecies`，不要 `import eciespy`，也不要 `pip install ecies`。之后所有命令都用 `/tmp/venv/bin/python`（下文简写 `<PY>`）。

### 1.2 连接预检：必须先运行 `baseinfo`

```bash
<PY> scripts/kisama_control.py \
  --url 'http://agent.example.com:8000' \
  --ecdsa-key '/secure/control_ecdsa.pem' \
  --ecies-key '/secure/control_ecies.hex' \
  baseinfo
```

通过标准：返回 `"status": "ok"` 且含 `version`、`os` 等字段；脚本已获取本次代理进程的 `session_key`/`noise_key`。不要把 baseinfo 完整输出复制到用户可见消息、日志或文件中（CLI 中密钥已自动脱敏）。

`--url` 来自用户提供的地址，**逐字复制**，只保留 `scheme://主机[:端口]`：不要补 `/api`、不加尾随 `/`，更不要凭印象重输主机名（抄错只会得到 `CERTIFICATE_VERIFY_FAILED ... Hostname mismatch`）。缺地址或任一把私钥时先报告缺失项，不要猜测或匿名执行。

### 1.3 执行非交互式命令

```bash
<PY> ... exec --cmd 'uname -a' --cwd '/tmp'
```

判读：`exitcode == 0` 才算成功；`result` 是输出（可能混合 stdout/stderr 且可能为空）。单请求默认超时 30 秒，`--timeout` 可调。破坏性命令（rm、格式化、重启等）执行前先确认目标与作用。

### 1.4 上传/下载文件

```bash
<PY> ... upload --local '/home/user/package.tar.gz' --remote-path '/tmp/uploads' [--name 改名]
<PY> ... download --remote-path '/tmp/result.tar.gz' --local '/home/user/result.tar.gz'
```

上传自动按裸二进制分片发送，勿额外加密；完成后用 `list` 或远端 `exec` 校验大小与校验和。

### 1.5 文件操作快速参考

```text
list [--path PATH] [--recursive]      查看目录列表
cat --path PATH                       读取文本文件内容
authority-get PATH [PATH ...]         查询权限
authority-set PATH=MODE [..] [--recursive]   修改权限（用户明确要求才做）
mkdir --path PATH                     创建目录（递归）
move FROM=TO [..] / copy FROM=TO [..] 移动/复制（先确认目标无覆盖）
delete PATH [PATH ...]                递归删除（不可逆，先 list 确认）
```

路径以代理端 `FILE_ROOT` 为基准（相对路径基于它，不是控制端目录），不要用 `..` 穿越。推荐顺序：`list` 父目录 → `authority-get` → 操作 → 再 list/cat 验证。**删除、覆盖、移动、权限修改等有副作用操作，执行前必须先向用户确认。**

### 1.6 超级终端（真实 TTY）

```bash
<PY> ... terminal --command 'uname -a'   # 或 --input 发送原始输入
```

需要真实 TTY、交互式程序或持续会话时用（`top`/`vim`/`sudo`）；普通一次性命令优先 `exec`。**调用前必须先确认 `baseinfo.version` 不含 `php`**。协议细节（Noise 握手、心跳、PING）见 `docs/terminal.md`。

### 1.7 连续操作复用连接（Python API）

CLI 每次是新进程。一个流程内连续多步时，可直接导入脚本复用 `KisamaClient`：`bootstrap()` → `request_json(method, path, 业务 JSON)`。脚本不会把私钥发送给代理或写入输出。

### 1.8 跨命令复用会话 `--session-cache`

```bash
<PY> ... --session-cache '/tmp/kisama_session.json' baseinfo
<PY> ... --session-cache '/tmp/kisama_session.json' exec --cmd 'uname -a'
```

缓存自动 0600；代理重启后脚本遇认证/解密错误会自动删缓存并重新 baseinfo。缓存与目标代理绑定，勿跨代理复用。也可用环境变量 `KISAMA_URL`/`KISAMA_ECDSA_KEY`/`KISAMA_ECIES_KEY`/`KISAMA_SESSION_CACHE` 省略对应参数。

### 1.9 帮助

```bash
<PY> scripts/kisama_control.py --help
<PY> scripts/kisama_control.py terminal --help
```

## 2. 密钥格式

只需**两把私钥**（公钥完全不需要，代理配置的是对应公钥，`baseinfo` 之外的接口由签名+会话密钥认证）：

| 控制端私钥 | 格式（脚本自动识别） | 用途 |
| --- | --- | --- |
| ECDSA P-256 | PEM：PKCS#8 `-----BEGIN PRIVATE KEY-----` 或 SEC1 `-----BEGIN EC PRIVATE KEY-----` 均可 | 每个 HTTP 请求签名 |
| ECIES secp256k1 | **64 位 hex 或 Base64(32 字节)** 均可 | 解密代理响应 |

`/api/tempkey`（0.4.2+）下发的 `ecdsa.private_key`、`ecies.private_key` 原样传入即可，无需转换。私钥不是从 baseinfo 获取，**不要把私钥写进仓库或打印到日志/聊天消息**。

## 3. 按需加载的分能力文档

下面的文档只在对应能力被用到/出问题时读取，平时不要加载以节省上下文：

| 场景 | 文档 |
| --- | --- |
| 看协议细节（认证头、AES/ECIES、各接口完整请求/响应与状态机） | `docs/api.md` |
| 使用超级终端（Noise WebSocket、握手、消息协议） | `docs/terminal.md` |
| 依赖安装失败 / 环境问题 | `docs/install.md` |
| 命令或接口报错时的整体排查顺序 | `docs/troubleshooting.md` |