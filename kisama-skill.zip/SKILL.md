---
name: kisama-control
description: 通过 Kisama Agent 对已部署代理执行系统命令、文件管理、文件传输和交互式终端操作，以及临时隧道（trycloudflare）的查询、创建与删除。用户要求连接、控制、运维、执行命令、上传文件或管理临时隧道到 Kisama Agent 时使用。
compatibility: 需要网络可达 Kisama Agent、控制端 ECDSA 私钥与 ECIES 私钥，以及 Python 依赖。
---

# Kisama Agent 控制技能（操作手册）

本技能只调用本目录 `scripts/kisama_control.py` 一个脚本，不读仓库其他文档。密码学与协议已封装在脚本内，直接给参数、选子命令、读 JSON 结果即可。

只覆盖这些接口：`baseinfo`、`exec`（支持 `--route` 别名路由：WAF 拦截 /api/exec 时优先 `/api/do`，备选 `/api/run`、`/api/work`）、文件管理（list/cat/mkdir/move/copy/delete/authority/upload/download/zip/unzip）、`terminal`、临时隧道（tunnel-list/tunnel-create/tunnel-delete）。

## 1. 安装（一次性，venv 内）

以下 `<PY>` 表示 venv 内 Python：**Linux/macOS** 为 `/tmp/venv/bin/python`，**Windows** 为 `venv\Scripts\python.exe`（以实际创建路径为准）。先确认本机命令：Linux 用 `python3`，Windows 用 `python` 或 `py -3`。

Linux/macOS：

```bash
python3 -m venv /tmp/venv
/tmp/venv/bin/python -m pip install -r scripts/requirements.txt
/tmp/venv/bin/python -c "import ecdsa, cryptography, noise, websockets; print('all deps OK')"
```

Windows（PowerShell，venv 建在技能目录下）：

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r scripts\requirements.txt
.venv\Scripts\python.exe -c "import ecdsa, cryptography, noise, websockets; print('all deps OK')"
```

- 依赖分两层：`ecdsa/cryptography/noise/websockets` 为核心必装（纯 Python 或 abi3 wheel，任意 CPython 含 3.14 免编译）；`coincurve/eciespy/pycryptodome` 为可选原生加速，装不上不影响使用——脚本内置兼容层，缺失时自动回退 ecdsa+cryptography 实现（与原生输出逐字节兼容）。
- Python 3.14 无需任何补丁或编译工具；`scripts/install_coincurve_py314.sh` 仅在想获得 libsecp256k1 原生性能时（Linux/macOS）选用。
- 报错见 `docs/install.md`。

## 2. 连接参数

每条命令都带这三个参数（或对应环境变量 `KISAMA_URL`/`KISAMA_ECDSA_KEY`/`KISAMA_ECIES_KEY`）：

| 参数 | 内容 |
| --- | --- |
| `--url` | 代理地址，逐字复制用户给的完整地址（含 `#` 路由片段），不加 `/api`、不加尾随 `/` |
| `--ecdsa-key` | ECDSA P-256 私钥文件路径或内容：PEM/DER，或 64 位 hex / Base64(32字节) 短格式标量（agent 0.5.8 起 `GET /api/tempkey?format=short` 下发的即为 64 位 hex 标量，单行纯 hex，直接整串传入即可） |
| `--ecies-key` | ECIES secp256k1 私钥，64 位 hex 或 Base64(32字节) |

### 推荐：分享链接一条命令连接（0.5.8 起，首选方式）

用户消息中给出 `kisama://` 分享链接时，**整条链接作为一个参数**传给脚本，解析全部由脚本完成——不要自行拆分参数：

```bash
<PY> scripts/kisama_control.py connect "kisama://node?domain=...&ecdsaprikey=<64位hex>&eciesprikey=<64位hex>&..."
```

- `connect` 自动解析链接（`domain` → 代理地址、`ecdsaprikey`/`eciesprikey` → 两把私钥）、完成 baseinfo 握手**校验**后保存到连接档案（缺省 `~/.kisama/profile.json`，POSIX 0600 权限），输出 `status: ok` 与代理版本即连接成功；
- **之后所有命令零密钥参数**，直接 `exec --cmd ...`、`list --path ...` 等；session_key 自动缓存，免重复握手；
- 链接值自动做百分号解码（兼容已编码 `domain=https%3A%2F%2F...%23...` 与原样含 `#` 两种写法），`tls=1` → 强制 `https://`；未知参数自动存档不报错；**复制时保持整段原样，用引号包裹成一个参数**；
- `--profile <名称|路径>` 支持多代理并存（如 `--profile agentb`），缺省档案为 `~/.kisama/profile.json`；
- `connect --show` 脱敏查看当前档案（不联网）；`disconnect` 删除档案与同名会话缓存（换代理/授权结束时执行）；
- 免档案的一次性用法：任意命令直接 `--link "kisama://..."`（等效环境变量 `KISAMA_LINK`），不落盘；
- 连接来源优先级：**命令行显式参数 > `--link`/`KISAMA_LINK` > 环境变量 > 连接档案**。
- ⚠️ 连接档案与密钥同为明文机密：不要放进仓库、截图或聊天消息；不可信主机上改用 `--link` 一次性用法。

无分享链接时沿用三参数用法（下表），行为完全兼容。

**`#` 路由格式**：当地址形如 `scheme://网关主机[:端口]#目标主机[/路径前缀]` 时（例如 `https://gw.example.com#real.host.net/k.php`），脚本自动把 `#` 后的目标主机放入每个请求的 `X-Target-Host` 头、由网关路由到真实代理，并把 `#` 后的路径前缀（如 `/k.php`）拼在所有 API 路径之前（含 WebSocket 终端）。无 `#` 的普通地址行为不变。用户给的地址必须原样传入，不要自行拆分或补全。

签名时间戳自动与服务器时钟对齐，无需手动设置。密钥不要写进仓库或聊天消息。

**0.4.8 签名协议兼容（自动，无需操作）**：0.4.8 起 agent 的签名消息变为 `METHOD\nPATH\nsha256hex(body)\nnonce\ntimestamp`（旧版为 `nonce+timestamp`）。脚本首次请求按新签名发送，遇到 401 自动回退旧签名重试一次并记忆，**新旧版本代理均可直连，无需配置**。特殊环境下可用环境变量 `KISAMA_SIG_MODE=v1|v2` 强制指定。

**0.5.6 响应加密协议兼容（自动，无需操作）**：0.5.6 起代理的响应加密改为分段式——`baseinfo` 恒为 ECIES（密钥分发握手），其余端点改用 baseinfo 下发的 `session_key` 做 AES-256-GCM（规范见 `docs/API.MD` 第十二节）。脚本从 baseinfo 响应读取代理版本号自动判定解密算法：`>= 0.5.6` 走新协议，旧版代理自动维持全 ECIES，**新旧版本代理均可直连**。注意 `--ecies-key` 仍为必填（生产模式 baseinfo 握手必需）；控制端与代理版本混布时需成对升级，脚本会在解密失败时给出明确提示。

**路径规则（平台差异关键）**：`--url`、`--ecdsa-key`、`--ecies-key`、`--local`、`--session-cache` 是**控制端本机**参数，按控制端平台写法；`exec --cmd` 是代理端命令，`exec --cwd` 是代理端已存在且可访问的 Linux 工作目录；文件接口的 `--path/--remote-path` 是相对代理端 `FILE_ROOT` 的路径。文件接口路径不要写前导 `/`、主机绝对路径或 `..`；例如 `uploads` 表示 `$FILE_ROOT/uploads`。`--local` 才是控制端本机路径。Windows Git Bash 调用时若传入 `/tmp` 等远端参数，设置 `MSYS_NO_PATHCONV=1`，或改用 PowerShell。

## 3. 操作命令

### 连接预检（每次先做）

```bash
# 已执行 connect (推荐): 零密钥参数
<PY> scripts/kisama_control.py baseinfo

# 未建档: 三参数直连
<PY> scripts/kisama_control.py --url URL --ecdsa-key KEY --ecies-key KEY baseinfo
```

通过标准：`"status": "ok"` 且含 `version`、`os` 等字段。输出中 `session_key`/`noise_key` 已自动脱敏。**`version` 包含 `php` 时，禁止用 `terminal`，一律改用 `exec`。**

> **密钥参数可省略（DEBUG 探测场景）**：`--ecdsa-key`/`--ecies-key` 不再是启动必填。不带密钥或密钥占位（如 `dummy`）时脚本直接连通探测——若代理是 DEBUG 模式（响应头 `x-encrypted: false`）则全部命令可用（terminal 除外，见下）；若是生产模式会得到 `401 Missing auth headers` 之类的明确报错，再补齐密钥即可。

> **DEBUG 模式代理**：若代理响应携带 `x-encrypted: false`，说明代理处于 DEBUG 模式（跳过认证与加密）。脚本自动识别并以明文通信，`exec`/文件操作/上传下载/隧道等全部命令照常可用；但 DEBUG 代理**不下发 `session_key`/`noise_key`**（恒为 null，规范设计见 `docs/API.MD` 第十节），因此 `terminal` 不可用，会提示改用 `exec`。

> **生产明文认证模式代理（`x-encrypted: plain`，仅 PHP 版提供）**：代理端配置 `PLAIN_MODE=true` 后双向关闭体加密，认证仍强制 ECDSA 验签。脚本按响应头自动识别并置位 `plain_mode`：照常发送签名三件套（`X-Nonce`/`X-Timestamp`/`X-Auth-Token`），但**请求体改为明文 JSON 直发、不带 `X-AES-Encrypted`**，响应按明文 JSON 解析（规范见 `docs/API.MD` 第十节判定表）。
>
> - `connect` 输出里体现为 `plain_mode: true`（`baseinfo` 只回代理原始字段，不含模式位）；`exec`/文件操作/上传下载照常可用。
> - 与 DEBUG 一样**不下发 `session_key`/`noise_key`**，故 `terminal` 不可用；也因此**没有会话可缓存**：`session_cached` 恒为 `false`，**每条 CLI 命令都会重做一次 baseinfo 握手**（多一个 RTT），批量操作要把这点计进耗时。
> - 识别靠响应头不靠版本号：版本串可能滞后于实际代码代际，别拿它推断加密行为。
> - 排障分流：plain 模式下若仍报错且响应体不是代理的 JSON（例如前置层返回空体 4xx 或 Cloudflare 520 `unknown_origin_error`），那是前置/源站抖动，`retry_after` 后重试即可，不是协议问题——代理自己的 4xx 必带 JSON `message`。
> - 风险提示：请求（含命令输入）与响应（含命令输出）全程明文，机密性只由 TLS 承担；务必确认走 `https://`。

### 执行命令

```bash
<PY> scripts/kisama_control.py ... exec --cmd 'uname -a' --cwd '/tmp'
```

> **Windows cmd.exe 注意**：cmd 不识别单引号，用双引号；PowerShell 可用单双引号。Git Bash 传递 `/tmp` 等远端参数时设置 `MSYS_NO_PATHCONV=1`，否则可能被改写成 `C:/...`。

`cmd` 必须是单个命令字符串；`cwd` 必须是代理端已存在且可访问的目录，不确定时省略。`exitcode == 0` 才算成功；不存在命令通常为 `127`，`-1` 表示进程启动或 `cwd` 设置失败，先检查/省略 `cwd`。默认超时 30 秒，`--timeout` 可调。破坏性命令（rm、格式化、重启）执行前先确认。

> **WAF 拦截 exec 时改用别名路由**：部分托管平台的 WAF/审计规则对 URL 路径中的 `exec` 敏感（表现为 403、返回拦截页或连接被重置）。`exec` 子命令支持 `--route` 指定等价别名路由——**优先 `--route /api/do`**（首选），备选 `--route /api/run`、`--route /api/work`：
>
> ```bash
> <PY> scripts/kisama_control.py ... exec --cmd 'uname -a' --route /api/do
> ```
>
> 六个语言实现（py/js/go/java/java11/php）的别名行为完全一致，签名按实际请求路径自动处理，无需其他调整。别名为 0.5.7 新增；旧版代理没有别名路由会返回 404，此时去掉 `--route` 退回默认路由即可。

### 文件操作

```text
list [--path PATH] [--recursive]     查看目录列表
cat --path PATH                      读取文本文件
authority-get PATH [PATH ...]        查询权限
authority-set PATH=MODE [..] [--recursive]   改权限（用户明确要求才做）
mkdir --path PATH                    创建目录（递归）
move FROM=TO [..] / copy FROM=TO [..] 移动/复制
delete PATH [PATH ...]               递归删除（不可逆，先 list 确认）
zip --path ZIP_PATH ITEM [ITEM ...] [--flat]   打包文件/目录为 zip（覆盖重建）
unzip --path ZIP_PATH [--dest DIR] [--no-overwrite] [--entries NAME ..]  解压 zip
```

路径以代理端 `FILE_ROOT` 为基准，不是控制端目录；不要用 `..` 穿越。推荐顺序：`list` 父目录 → `authority-get` → 操作 → 再 `list`/`cat` 验证。**删除、覆盖、移动、改权限前必须先向用户确认。**

### 上传 / 下载

`--local` 是控制端本机路径；`--remote-path` 是相对代理端 `FILE_ROOT` 的**目标目录**，不要加前导 `/`。例如 `uploads` 表示 `$FILE_ROOT/uploads`，最终文件 = `<remote-path>/<--name>`。`--name` 只填文件名，不含目录或 `..`。**`--remote-path` 不要写成文件路径**：若远端已存在同名文件（如已有 `info.php` 时传 `--remote-path info.php`），脚本会列表父目录探测并直接报错，此时应写 `--remote-path '.' --name '<目标文件名>'`（点号表示 `FILE_ROOT` 根目录）。

```bash
<PY> scripts/kisama_control.py ... upload --local '本地路径' --remote-path 'uploads' [--name 改名]
<PY> scripts/kisama_control.py ... download --remote-path 'uploads/result.tar.gz' --local '本地路径'
```

上传自动裸二进制分片，脚本会校验代理端 `completed` 合并结果（失败时明确报错），完成后用 `list` 或远端 `exec` 校验大小。

### 远端打包 / 解压（zip / unzip）

把远端文件或目录（递归）打包成 zip，或解压远端 zip 包：

```bash
<PY> scripts/kisama_control.py ... zip --path 'logs/2026.zip' 'logs/app' 'logs/err.log' [--flat]
<PY> scripts/kisama_control.py ... unzip --path 'logs/2026.zip' --dest 'logs/extracted' [--no-overwrite] [--entries a.txt]
<PY> scripts/kisama_control.py ... unzip --path 'logs/2026.zip'          # 缺省"解压到此处"(zip 所在目录)
```

- `zip` 目标已存在时覆盖重建；目录递归打包且条目名带顶层目录名前缀（`--flat` 去掉前缀）；单项不存在不中断，逐项回显在 `results[]`（`status: not_found` 等）。
- `unzip` 目标目录不存在自动创建；缺省覆盖同名文件，`--no-overwrite` 改为跳过；防 zip-slip，逃逸条目计入 `skipped`。返回的 `files[]` 为解压出的文件（相对 `FILE_ROOT`，最多 500 条）。
- **这两个命令需代理端 ≥ 0.5.4**（`baseinfo.version` 确认；旧版代理返回 404）。大目录打包/解压耗时随体积增长，必要时调大 `--timeout`。
- 建议顺序：`zip` 后 `unzip`/`list`/`cat` 验证内容；`unzip` 覆盖前确认目标无同名文件。

### 超级终端（真实 TTY）

```bash
<PY> scripts/kisama_control.py ... terminal --command 'uname -a'    # 或 --input 发送原始输入
```

需真实 TTY、交互式程序、持续会话时用（`top`/`vim`/`sudo`）；普通一次命令优先 `exec`。**先确认 `baseinfo.version` 不含 `php`。** 协议细节见 `docs/terminal.md`。

**Windows 代理（0.5.8 起）**：`terminal --command` 在 Windows 代理上同样可用——脚本通过 welcome 元数据帧识别 PTY shell（PowerShell/cmd），自动注入对应的 done 标记（PowerShell 无 `printf`/`$?` 布尔语义，且 LF 不是 Enter）。注意 PowerShell 下 `exitcode` 为 **0=成功 / 1=失败**（非原生命令退码）；需要精确退出码或非交互取输出时仍优先 `exec`。

> **0.4.8 兼容**：不传 `--token` 时走 Noise 加密模式，新旧代理通用；0.4.8+ 代理需要明文降级模式时用 `--token auto`（脚本自动按 HMAC(session_key) 计算新式令牌）；旧版代理仍传 agent 公钥。若代理发生过临时密钥过期轮换，脚本会自动重拉 baseinfo 重试。

### 临时隧道（Argo）

把代理的本地端口暴露为随机的 `https://<随机域名>.trycloudflare.com` 临时公网域名，无需自有域名与证书；隧道随代理进程退出而失效：

```bash
<PY> scripts/kisama_control.py ... tunnel-list                                          # 查询全部存活隧道
<PY> scripts/kisama_control.py ... tunnel-create [--port 8080] [--duplicate]            # 创建隧道
<PY> scripts/kisama_control.py ... tunnel-delete --port 8080 [--tunnel-domain '域名']   # 删除隧道
```

- `tunnel-list` 无隧道时返回 `count: 0` 空列表；`tunnels[]` 每条含 `tunnel_domain`（带 `https://` 前缀）、`port`、`created_at`。
- `tunnel-create` 缺省 `--port` 时用 agent 自身监听端口；同端口已有隧道默认拒绝（409），须显式加 `--duplicate` 才强制再建一条。成功返回的 `tunnel_domain` 即对外可访问的公网地址。
- `tunnel-delete` 的 `--port` 必填；端口无隧道返回 404；同端口存在多条隧道时必须带 `--tunnel-domain` 精确定位（否则 409 防误删）。删除后该公网域名立即失效。
- 该路由仅在代理端 **py/js/java 版本且版本 ≥ 0.4.5** 时提供；先 `baseinfo` 确认 `version`，版本过低或不支持会报错。
- 实测代理端偶发返回空响应体的 `HTTP 503`（无 `message`），间隔几秒重试即可，非客户端问题。

## 4. 复用会话

CLI 每次新进程。连续多步可加 `--session-cache` 跨命令复用（缓存文件路径按控制端平台写，Windows 如 `C:\Users\me\kisama_session.json`，Linux 如 `/tmp/kisama_session.json`）：

```bash
<PY> scripts/kisama_control.py ... --session-cache '缓存路径' baseinfo
<PY> scripts/kisama_control.py ... --session-cache '缓存路径' exec --cmd 'uname -a'
```

缓存自动 0600（Windows 上无 POSIX 权限位，仅尽力设置），与目标代理绑定，代理重启后脚本自动重取。也可在 Python 中 `from kisama_control import KisamaClient` 复用连接。

## 5. 帮助

```bash
<PY> scripts/kisama_control.py --help
<PY> scripts/kisama_control.py terminal --help
```

报错排查顺序见 `docs/troubleshooting.md`。