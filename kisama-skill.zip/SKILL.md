---
name: kisama-control
description: 通过 Kisama Agent 对已部署代理执行系统命令、文件管理、文件传输、交互式终端操作与任务管理（onetime 启动任务 / cron 定时任务及执行日志），临时隧道（trycloudflare）的查询、创建与删除，以及经 agent 本地端口反代访问其 127.0.0.1 端口的 HTTP 服务与反代端口白名单管理。用户要求连接、控制、运维、执行命令、上传文件、管理任务、管理临时隧道或反代白名单到 Kisama Agent 时使用。
compatibility: 需要网络可达 Kisama Agent、控制端 ECDSA 私钥与 ECIES 私钥，以及 Python 依赖。
---

# Kisama Agent 控制技能（操作手册）

本技能只调用本目录 `scripts/kisama_control.py` 一个脚本，不读仓库其他文档。密码学与协议已封装在脚本内，直接给参数、选子命令、读 JSON 结果即可。

只覆盖这些接口：`baseinfo`、`exec`（支持 `--route` 别名路由：WAF 拦截 /api/exec 时优先 `/api/do`，备选 `/api/run`、`/api/work`）、文件管理（list/cat/mkdir/move/copy/delete/authority/upload/download/zip/unzip；`delete` 支持 `--route`：PHP 代理缺省 auto 优先 POST /api/file/delete 兼容路由）、`terminal`、任务管理（task-status/task-get/task-set/task-exec/task-log/task-log-clear/task-log-summary）、临时隧道（tunnel-list/tunnel-create/tunnel-delete；0.6.8 起 tunnel-create 支持 shz 绑定参数、tunnel-bind/tunnel-unbind 管理隧道 shz.al 上报绑定）、本地端口反代（proxy 经 `/api/proxy/{port}` 透传访问 agent 本机端口的 HTTP 服务；proxy-config/proxy-config-set/proxy-config-clear 管理反代端口白名单）。

## 1. 安装（一次性，venv 内）

以下 `<PY>` 表示 venv 内 Python：**Linux/macOS** 为 `/tmp/venv/bin/python`，**Windows** 为 `venv\Scripts\python.exe`（以实际创建路径为准）。先确认本机命令：Linux 用 `python3`，Windows 用 `python` 或 `py -3`。

Linux/macOS：

```bash
python3 -m venv /tmp/venv
/tmp/venv/bin/python -m pip install -r scripts/requirements.txt
/tmp/venv/bin/python -c "import ecdsa, cryptography, noise, websockets; print('all deps OK')"
```

Windows（PowerShell，venv 建在技能目录下）：

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r scripts\requirements.txt
.venv\Scripts\python.exe -c "import ecdsa, cryptography, noise, websockets; print('all deps OK')"
```

- 依赖分两层：`ecdsa/cryptography/noise/websockets` 为核心必装（纯 Python 或 abi3 wheel，任意 CPython 含 3.14 免编译）；`coincurve/eciespy/pycryptodome` 为可选原生加速，装不上不影响使用——脚本内置兼容层，缺失时自动回退 ecdsa+cryptography 实现（与原生输出逐字节兼容）。
- Python 3.14 无需任何补丁或编译工具；`scripts/install_coincurve_py314.sh` 仅在想获得 libsecp256k1 原生性能时（Linux/macOS）选用。
- 报错见 `docs/install.md`。

## 2. 连接参数

每条命令都带这三个参数（或对应环境变量 `KISAMA_URL`/`KISAMA_ECDSA_KEY`/`KISAMA_ECIES_KEY`）：

| 参数 | 内容 |
| --- | --- |
| `--url` | 代理地址，逐字复制用户给的完整地址（含 `#` 路由片段），不加 `/api`、不加尾随 `/` |
| `--ecdsa-key` | ECDSA P-256 私钥文件路径或内容：PEM/DER，或 64 位 hex / Base64(32字节) 短格式标量（agent 0.5.8 起 `GET /api/tempkey?format=short` 下发的即为 64 位 hex 标量，单行纯 hex，直接整串传入即可） |
| `--ecies-key` | ECIES secp256k1 私钥，64 位 hex 或 Base64(32字节) |

### 首选流程：先 connect 建档案，再执行操作（0.5.8 起）

**拿到 `kisama://` 分享链接后的标准动作是先用它 `connect` 建立连接档案，之后所有命令一律不再携带链接、密钥**。不要每条命令都粘贴整条链接（`--link` / `--node "<整条链接>"`）：那样每条命令都重做一次 baseinfo 握手，密钥还会留在每条命令行与会话记录里。直连形态仅限例外场景（见下方"一次性直连"条目）。

单台代理（缺省槽，多客户端共用 `~/.kisama` 时先看下方护栏）：

```bash
<PY> scripts/kisama_control.py connect "kisama://node?domain=...&ecdsaprikey=<64位hex>&eciesprikey=<64位hex>&..."
# 成功后所有命令零密钥参数: baseinfo / exec --cmd ... / list --path ...
```

多台代理并存 / 共用 `~/.kisama` 目录（命名档案，不抢占缺省槽）：

```bash
<PY> scripts/kisama_control.py --profile agentb connect "kisama://..."   # --profile 是全局开关, 写在 connect 之前
# 之后每条命令点名: --node agentb exec --cmd ...
```

用户消息中给出链接时，**整条链接作为一个参数**传给脚本，解析全部由脚本完成——不要自行拆分参数：

- `connect` 自动解析链接（`domain` → 代理地址、`ecdsaprikey`/`eciesprikey` → 两把私钥）、完成 baseinfo 握手**校验**后保存到连接档案（缺省 `~/.kisama/profile.json`，POSIX 0600 权限），输出 `status: ok` 与代理版本即连接成功；
- **之后所有命令零密钥参数**，直接 `exec --cmd ...`、`list --path ...` 等；session_key 自动缓存，免重复握手；
- 链接值自动做百分号解码（兼容已编码 `domain=https%3A%2F%2F...%23...` 与原样含 `#` 两种写法），`tls=1` → 强制 `https://`；未知参数自动存档不报错；**复制时保持整段原样，用引号包裹成一个参数**；
- **间接域名（KMODE=2 shz.al 静默上报，`domain=https://shz.al/~<KNAME>`）**：此形态的 `domain` 不是代理本身而是**名称解析入口**——脚本每次建连前自动 GET 该 URL，响应体（形如 `https://xxxx.trycloudflare.com` 的隧道域名）才是真实代理地址。`connect` 档案保存的是入口 URL，而代理每次重启会自动覆盖更新同一 URL 的值，因此**隧道域名变更后无需重新 connect**，之后每条命令自动解析到最新域名（会话缓存绑定解析结果，域名变更后自动失效重握手）。解析失败排查：404 = 代理未启动/未完成上报/KNAME 不符/上报值超 7 天过期；响应体不是 URL = 该 KNAME 未按 KMODE=2 上报。代价是每条命令多一次 shz.al 解析 RTT。与 `#` 网关路由互斥（主机位是网关时不会命中）；
- **忽略 TLS 证书校验（自签证书主机）**：主机证书自签/证书链不完整/证书域名不匹配时报 `CERTIFICATE_VERIFY_FAILED`，加全局开关 `--insecure`（写在子命令**之前**，如 `... --insecure connect "kisama://..."`、`... --insecure exec --cmd ...`）。等效环境变量 `KISAMA_INSECURE=1`、分享链接参数 `insecure=1`；`connect` 会把开关记入连接档案，之后命令自动沿用（`connect --show` 里体现为 `insecure`）。它只关闭对服务端证书的校验，请求仍全程 TLS 加密、ECDSA 认证照常，`terminal` 的 `wss` 同样生效；不加密的 `http/ws` 地址与该开关无关。
- `--profile <名称|路径>` 支持多代理并存（如 `--profile agentb`），缺省档案为 `~/.kisama/profile.json`；
- `connect --show` 脱敏查看当前档案（不联网）；`disconnect` 删除档案与同名会话缓存（换代理/授权结束时执行）；
- **一次性直连（例外手段，非常规用法）**：任意命令直接 `--link "kisama://..."`（等效环境变量 `KISAMA_LINK`），不落盘——仅限不可信主机不想落盘、或对该代理只跑一两条命令的临时探活；同一代理预计要连续操作时一律改走 `connect` 建档；
- **`--node <档案名称|路径 | 整条 kisama:// 链接>`（等效环境变量 `KISAMA_NODE`）——一条参数直接指定"本次命令连哪台"**：
  - **常规用法是档案形态**（名称 → `~/.kisama/profiles/<名>.json`，或任意 `.json` 路径）：先用 `--profile <名> connect "<链接>"` 建档，之后所有命令 `--node <名>`，复用该档案自身的 `*.session.json` 缓存，握手只付一次；
  - 链接形态（`--node "kisama://..."`）与 `--link` 一样不落盘（不写档案、不建会话缓存），**每条命令都重做握手**，仅限一次性操作或不可信主机不想落盘时；
  - **优先级最高**：给了 `--node` 就只看它——`--link`、`KISAMA_URL`/`KISAMA_ECDSA_KEY` 等环境变量、以及 `connect` 写下的缺省档案全部让位，残留的环境变量不会把命令打到另一台代理；命令行显式 `--url/--ecdsa-key/--ecies-key` 仍可逐字段覆盖；
  - 档案不存在/不可读时**当场报错**（不会静默回退到缺省档案），链接缺参数同样报错；
  - `connect`/`disconnect`/`connect --show` 也接受 `--node <名称|路径>`，含义是"对这台档案操作"，等价于 `--profile`；
  - 与其他全局开关一样写在子命令**之前**：`... --node gt-tc exec --cmd 'hostname'`。
- 连接来源优先级：**命令行显式参数 > `--node`/`KISAMA_NODE` > `--link`/`KISAMA_LINK` > 环境变量 > 连接档案**。
- ⚠️ 连接档案与密钥同为明文机密：不要放进仓库、截图或聊天消息；不可信主机上改用 `--link`/`--node <链接>` 一次性用法。

### 多台代理并行操作

同时管多台代理时，**先为每台建独立命名档案（每台一次），之后每条命令用 `--node <名称>` 点名**，各台互不干扰（各自独立的 url、密钥与会话缓存），可放心并发或放进脚本后台任务：

```bash
# 第一步: 各建一个命名档案 (每个代理只做一次)
<PY> scripts/kisama_control.py --profile agenta connect "kisama://node?domain=...&ecdsaprikey=...&eciesprikey=..."
<PY> scripts/kisama_control.py --profile agentb connect "kisama://..."
# 第二步: 所有命令按名称点名
<PY> scripts/kisama_control.py --node agenta exec --cmd 'df -h'   # 档案 ~/.kisama/profiles/agenta.json
<PY> scripts/kisama_control.py --node agentb list --path uploads   # 另一台
```

- 只有对某台代理**只跑一两条一次性命令**且不想落盘时，才直接 `--node "<整条 kisama:// 链接>"`；预计连续操作的代理一律先建档再点名（握手只付一次，密钥也不出现在每条命令里）；
- 判断"这条命令打到哪台"以输出里的实际主机为准（`exec --cmd 'hostname'`、`baseinfo` 的 `version`/`os`），不要靠环境变量猜。

### 共用 `~/.kisama` 目录时：别抢占别人在用的缺省槽

`~/.kisama/profile.json` 是全机**唯一**的缺省槽位。另一个客户端（另一个会话、另一台终端，或共用同一目录的机器）正在用它时，无条件 `connect` 会把槽位里的节点和密钥换成你自己的——对方下一条不带参数的命令就会打到**你这台**代理，比断开更糟。脚本已加确定性护栏：

- `connect` 在联网**之前**检查：缺省槽已有档案且指向**另一台**代理 → 直接拒绝，报错写明占用者（url、代理版本、保存时间）与出路，一个请求都不发；
- 让位方式（推荐）：`--profile <名称> connect "<链接>"` 建独立档案、之后所有命令 `--node <名称>`（`--profile` 是全局开关，写在 `connect` **之前**）；只跑一两条一次性命令时才用 `--node "<整条 kisama:// 链接>"` 直连（完全不碰槽位）；
- 同一台代理重新 `connect`（链接 url 与槽位一致，忽略大小写与尾随 `/`，`#` 网关路由片段参与比较）不算冲突，照常刷新密钥与缓存；
- 确实要把缺省代理换掉：`connect --force`（改写现有档案并清空其会话缓存）；
- 只读盘点：`connect --list` 列出缺省槽与全部命名档案的 `url`、`agent_version`、`source`、`saved_at`、`has_ecdsa_key`/`has_ecies_key`、`session_cached`——**不输出任何密钥材料**，多客户端环境先跑一次再挑档案名；
- `disconnect` 同理属破坏性动作：共用目录时只删自己的命名档案（`disconnect --node <名称>` / `--profile <名称>`），别对缺省槽执行。

无分享链接时沿用三参数用法（下表），行为完全兼容。

**`#` 路由格式**：当地址形如 `scheme://网关主机[:端口]#目标主机[/路径前缀]` 时（例如 `https://gw.example.com#real.host.net/k.php`），脚本自动把 `#` 后的目标主机放入每个请求的 `X-Target-Host` 头、由网关路由到真实代理，并把 `#` 后的路径前缀（如 `/k.php`）拼在所有 API 路径之前（含 WebSocket 终端）。无 `#` 的普通地址行为不变。用户给的地址必须原样传入，不要自行拆分或补全。

签名时间戳自动与服务器时钟对齐，无需手动设置。密钥不要写进仓库或聊天消息。

**0.4.8 签名协议兼容（自动，无需操作）**：0.4.8 起 agent 的签名消息变为 `METHOD\nPATH\nsha256hex(body)\nnonce\ntimestamp`（旧版为 `nonce+timestamp`）。脚本首次请求按新签名发送，遇到 401 自动回退旧签名重试一次并记忆，**新旧版本代理均可直连，无需配置**。特殊环境下可用环境变量 `KISAMA_SIG_MODE=v1|v2` 强制指定。

**0.5.6 响应加密协议兼容（自动，无需操作）**：0.5.6 起代理的响应加密改为分段式——`baseinfo` 恒为 ECIES（密钥分发握手），其余端点改用 baseinfo 下发的 `session_key` 做 AES-256-GCM（规范见 `docs/API.MD` 第十二节）。脚本从 baseinfo 响应读取代理版本号自动判定解密算法：`>= 0.5.6` 走新协议，旧版代理自动维持全 ECIES，**新旧版本代理均可直连**。注意 `--ecies-key` 仍为必填（生产模式 baseinfo 握手必需）；控制端与代理版本混布时需成对升级，脚本会在解密失败时给出明确提示。

**路径规则（平台差异关键）**：`--url`、`--ecdsa-key`、`--ecies-key`、`--local`、`--session-cache` 是**控制端本机**参数，按控制端平台写法；`exec --cmd` 是代理端命令，`exec --cwd` 是代理端已存在且可访问的 Linux 工作目录；文件接口的 `--path/--remote-path` 是相对代理端 `FILE_ROOT` 的路径。文件接口路径不要写前导 `/`、主机绝对路径或 `..`；例如 `uploads` 表示 `$FILE_ROOT/uploads`。`--local` 才是控制端本机路径。Windows Git Bash 调用时若传入 `/tmp` 等远端参数，设置 `MSYS_NO_PATHCONV=1`，或改用 PowerShell。

## 3. 操作命令

### 连接预检（每次先做）

```bash
# 已 connect 建档 (标准路径): 零密钥参数
<PY> scripts/kisama_control.py baseinfo

# 命名档案: --node 按名称点名
<PY> scripts/kisama_control.py --node agentb baseinfo

# 一次性直连 (仅限未建档且只跑一两条命令): --node 带整条链接
<PY> scripts/kisama_control.py --node "kisama://node?domain=...&ecdsaprikey=...&eciesprikey=..." baseinfo

# 无分享链接: 三参数直连
<PY> scripts/kisama_control.py --url URL --ecdsa-key KEY --ecies-key KEY baseinfo
```

通过标准：`"status": "ok"` 且含 `version`、`os` 等字段。输出中 `session_key`/`noise_key` 已自动脱敏。**`version` 包含 `php` 时，禁止用 `terminal`，一律改用 `exec`。**

报 `无法连接 Kisama 代理: 服务端 TLS 证书校验失败`（原始错误 `CERTIFICATE_VERIFY_FAILED`）时，是主机证书不受控制端信任，加 `--insecure` 重试（见上节）。

> **密钥参数可省略（DEBUG 探测场景）**：`--ecdsa-key`/`--ecies-key` 不再是启动必填。不带密钥或密钥占位（如 `dummy`）时脚本直接连通探测——若代理是 DEBUG 模式（响应头 `x-encrypted: false`）则全部命令可用（terminal 除外，见下）；若是生产模式会得到 `401 Missing auth headers` 之类的明确报错，再补齐密钥即可。

> **DEBUG 模式代理**：若代理响应携带 `x-encrypted: false`，说明代理处于 DEBUG 模式（跳过认证与加密）。脚本自动识别并以明文通信，`exec`/文件操作/上传下载/隧道等全部命令照常可用；但 DEBUG 代理**不下发 `session_key`/`noise_key`**（恒为 null，规范设计见 `docs/API.MD` 第十节），因此 `terminal` 不可用，会提示改用 `exec`。

> **生产明文认证模式代理（`x-encrypted: plain`，仅 PHP 版提供）**：代理端配置 `PLAIN_MODE=true` 后双向关闭体加密，认证仍强制 ECDSA 验签。脚本按响应头自动识别并置位 `plain_mode`：照常发送签名三件套（`X-Nonce`/`X-Timestamp`/`X-Auth-Token`），但**请求体改为明文 JSON 直发、不带 `X-AES-Encrypted`**，响应按明文 JSON 解析（规范见 `docs/API.MD` 第十节判定表）。
>
> - `connect` 输出里体现为 `plain_mode: true`（`baseinfo` 只回代理原始字段，不含模式位）；`exec`/文件操作/上传下载照常可用。
> - 与 DEBUG 一样**不下发 `session_key`/`noise_key`**，故 `terminal` 不可用；也因此**没有会话可缓存**：`session_cached` 恒为 `false`，**每条 CLI 命令都会重做一次 baseinfo 握手**（多一个 RTT），批量操作要把这点计进耗时。
> - 识别靠响应头不靠版本号：版本串可能滞后于实际代码代际，别拿它推断加密行为。
> - 排障分流：plain 模式下若仍报错且响应体不是代理的 JSON（例如前置层返回空体 4xx 或 Cloudflare 520 `unknown_origin_error`），那是前置/源站抖动，`retry_after` 后重试即可，不是协议问题——代理自己的 4xx 必带 JSON `message`。
> - 风险提示：请求（含命令输入）与响应（含命令输出）全程明文，机密性只由 TLS 承担；务必确认走 `https://`。

### 执行命令

```bash
<PY> scripts/kisama_control.py ... exec --cmd 'uname -a' --cwd '/tmp'
```

> **Windows cmd.exe 注意**：cmd 不识别单引号，用双引号；PowerShell 可用单双引号。Git Bash 传递 `/tmp` 等远端参数时设置 `MSYS_NO_PATHCONV=1`，否则可能被改写成 `C:/...`。

`cmd` 必须是单个命令字符串；`cwd` 必须是代理端已存在且可访问的目录，不确定时省略。`exitcode == 0` 才算成功；不存在命令通常为 `127`，`-1` 表示进程启动或 `cwd` 设置失败，先检查/省略 `cwd`。默认超时 30 秒，`--timeout` 可调。破坏性命令（rm、格式化、重启）执行前先确认。

> **WAF 拦截 exec 时改用别名路由**：部分托管平台的 WAF/审计规则对 URL 路径中的 `exec` 敏感（表现为 403、返回拦截页或连接被重置）。`exec` 子命令支持 `--route` 指定等价别名路由——**优先 `--route /api/do`**（首选），备选 `--route /api/run`、`--route /api/work`：
>
> ```bash
> <PY> scripts/kisama_control.py ... exec --cmd 'uname -a' --route /api/do
> ```
>
> 六个语言实现（py/js/go/java/java11/php）的别名行为完全一致，签名按实际请求路径自动处理，无需其他调整。别名为 0.5.7 新增；旧版代理没有别名路由会返回 404，此时去掉 `--route` 退回默认路由即可。

### 文件操作

```text
list [--path PATH] [--recursive]     查看目录列表
cat --path PATH                      读取文本文件（代理端硬上限 1MiB，超出报 413；大文件见"下载大文件"）
authority-get PATH [PATH ...]        查询权限
authority-set PATH=MODE [..] [--recursive]   改权限（用户明确要求才做）
mkdir --path PATH                    创建目录（递归）
move FROM=TO [..] / copy FROM=TO [..] 移动/复制
delete PATH [PATH ...] [--route /api/file]   递归删除（不可逆，先 list 确认）
zip --path ZIP_PATH ITEM [ITEM ...] [--flat]   打包文件/目录为 zip（覆盖重建）
unzip --path ZIP_PATH [--dest DIR] [--no-overwrite] [--entries NAME ..]  解压 zip
```

路径以代理端 `FILE_ROOT` 为基准，不是控制端目录；不要用 `..` 穿越。推荐顺序：`list` 父目录 → `authority-get` → 操作 → 再 `list`/`cat` 验证。**删除、覆盖、移动、改权限前必须先向用户确认。**

> **delete 的 PHP 兼容路由（`--route`，缺省 auto）**：cPanel/Froxlor 等共享主机网关会禁用或剥离
> `DELETE` 方法的请求体，原版 `DELETE /api/file` 表现为读超时长挂。PHP 版代理提供完全等价的
> `POST /api/file/delete`（请求体/处理逻辑/返回结构一致）。缺省 `auto`：version 含 `php` 时
> 优先走兼容路由，请求级失败（含旧版无此路由的 404）自动回退原版路由；显式
> `--route /api/file` 或 `--route /api/file/delete` 则强制指定、失败不回退。`auto` 下出现删除
> 回退卡顿时，可先用两条显式路由分别试一次定位瓶颈。

### 上传 / 下载

`--local` 是控制端本机路径；`--remote-path` 是相对代理端 `FILE_ROOT` 的**目标目录**，不要加前导 `/`。例如 `uploads` 表示 `$FILE_ROOT/uploads`，最终文件 = `<remote-path>/<--name>`。`--name` 只填文件名，不含目录或 `..`。**`--remote-path` 不要写成文件路径**：若远端已存在同名文件（如已有 `info.php` 时传 `--remote-path info.php`），脚本会列表父目录探测并直接报错，此时应写 `--remote-path '.' --name '<目标文件名>'`（点号表示 `FILE_ROOT` 根目录）。

```bash
<PY> scripts/kisama_control.py ... upload --local '本地路径' --remote-path 'uploads' [--name 改名]
<PY> scripts/kisama_control.py ... download --remote-path 'uploads/result.tar.gz' --local '本地路径'
```

上传自动裸二进制分片，脚本会校验代理端 `completed` 合并结果（失败时明确报错），完成后用 `list` 或远端 `exec` 校验大小。

### 下载大文件（不要自己 split）

`download` 已内置大文件处理，**不需要在远端手工 `split`/`dd` 再逐个取回**。流程是：先用 `file/list` 的父目录条目预检真实大小（协议无 stat 路由），再按大小分流：

- **≤ `--chunk-size`（缺省 32MiB）**：单次整取，行为与旧版一致（整个响应进内存后落盘），超时按真实字节数计算（旧版恒按假定 64MiB 算出 ~271s）。
- **> `--chunk-size`**：走内置分片流水线——远端 `tail -c +N | head -c M` 切一片、取回一片、立即删该片，本地拼到 `<目标文件>.part`，全部完成后改名成目标文件。远端峰值占用恒为一个分片大小（小根分区主机友好，可用 `--chunk-size` 调小）。

```bash
<PY> scripts/kisama_control.py ... download --remote-path 'logs/app.log' --local 'E:/tmp/app.log'
<PY> scripts/kisama_control.py ... download --remote-path 'backup.tar' --local 'E:/tmp/backup.tar' --chunk-size 8388608
```

- **续传**：中途中断会保留 `<目标文件>.part`（已按整分片对齐），重跑同一条命令从 `resumed_bytes` 处继续，结果里 `parts_fetched` 只算本次取的片数。要重来就删掉那个 `.part`。
- **完整性**：每片先由远端 `wc -c` 核对字节数，取回再核对一次，拼接总量必须等于预检大小，否则报错并保留 `.part`。
- **分片要求代理端 exec 是 POSIX shell**（需 `tail`/`head`/重定向，`EXEC_SHELL` 缺省开启）。Windows 代理、PHP 仿真层等不支持管道的节点，`auto` 会在**一片都还没取回时**自动退回单次整取（结果里 `split_fallback` 写明原因，行为与旧版一致）；已有本地续传进度时不回退，报错并保留 `.part`，避免丢掉已取回的字节。
- `--mode direct` 强制单次整取（旧行为，也是预检失败时的回退路径，此时结果带 `preflight_error`）；`--mode split` 强制分片、**不回退**，用来自查这台机器到底卡在哪。
- `--root-abs <FILE_ROOT 绝对路径>`：分片需要知道文件在代理端的绝对位置，脚本先用 exec 的 `pwd`、再用 `$HOME` 探测并以"该路径下同一相对文件的字节数 == list 报出的大小"校验，命中即止。两者都校验不过（`auto` 下会回退整取）时用该参数指定，或 `--mode split` 看具体报错。
- `--exec-route /api/do`：WAF 拦 `/api/exec` 时给分片流水线换 exec 路由；`--keep-parts` 保留远端临时分片排障（正常路径每片取回即删，并在结束时 `rmdir` 临时目录，绝不递归删远端目录）。
- **`cat` 只能读 1MiB 以内的文本**（代理端硬上限，超出返回 413 `File too large for cat`）。要看大文件内容：片段用 `exec`（`tail -n`/`sed -n`），整份用 `download` 到本地再看。
- 整目录不能直接 `download`（会预检报"是目录"）：先 `zip` 打包再下载。

### 远端打包 / 解压（zip / unzip）

把远端文件或目录（递归）打包成 zip，或解压远端 zip 包：

```bash
<PY> scripts/kisama_control.py ... zip --path 'logs/2026.zip' 'logs/app' 'logs/err.log' [--flat]
<PY> scripts/kisama_control.py ... unzip --path 'logs/2026.zip' --dest 'logs/extracted' [--no-overwrite] [--entries a.txt]
<PY> scripts/kisama_control.py ... unzip --path 'logs/2026.zip'          # 缺省"解压到此处"(zip 所在目录)
```

- `zip` 目标已存在时覆盖重建；目录递归打包且条目名带顶层目录名前缀（`--flat` 去掉前缀）；单项不存在不中断，逐项回显在 `results[]`（`status: not_found` 等）。
- `unzip` 目标目录不存在自动创建；缺省覆盖同名文件，`--no-overwrite` 改为跳过；防 zip-slip，逃逸条目计入 `skipped`。返回的 `files[]` 为解压出的文件（相对 `FILE_ROOT`，最多 500 条）。
- **这两个命令需代理端 ≥ 0.5.4**（`baseinfo.version` 确认；旧版代理返回 404）。大目录打包/解压耗时随体积增长，必要时调大 `--timeout`。
- 建议顺序：`zip` 后 `unzip`/`list`/`cat` 验证内容；`unzip` 覆盖前确认目标无同名文件。

### 超级终端（真实 TTY）

```bash
<PY> scripts/kisama_control.py ... terminal --command 'uname -a'    # 或 --input 发送原始输入
```

需真实 TTY、交互式程序、持续会话时用（`top`/`vim`/`sudo`）；普通一次命令优先 `exec`。**先确认 `baseinfo.version` 不含 `php`。** 协议细节见 `docs/terminal.md`。

**Windows 代理（0.5.8 起）**：`terminal --command` 在 Windows 代理上同样可用——脚本通过 welcome 元数据帧识别 PTY shell（PowerShell/cmd），自动注入对应的 done 标记（PowerShell 无 `printf`/`$?` 布尔语义，且 LF 不是 Enter）。注意 PowerShell 下 `exitcode` 为 **0=成功 / 1=失败**（非原生命令退码）；需要精确退出码或非交互取输出时仍优先 `exec`。

> **0.4.8 兼容**：不传 `--token` 时走 Noise 加密模式，新旧代理通用；0.4.8+ 代理需要明文降级模式时用 `--token auto`（脚本自动按 HMAC(session_key) 计算新式令牌）；旧版代理仍传 agent 公钥。若代理发生过临时密钥过期轮换，脚本会自动重拉 baseinfo 重试。

### 临时隧道（Argo）

把代理的本地端口暴露为随机的 `https://<随机域名>.trycloudflare.com` 临时公网域名，无需自有域名与证书；隧道随代理进程退出而失效：

```bash
<PY> scripts/kisama_control.py ... tunnel-list                                          # 查询全部存活隧道 (0.6.8+ 含绑定信息)
<PY> scripts/kisama_control.py ... tunnel-create [--port 8080] [--duplicate]            # 创建隧道
<PY> scripts/kisama_control.py ... tunnel-delete --port 8080 [--tunnel-domain '域名']   # 删除隧道
```

- `tunnel-list` 无隧道时返回 `count: 0` 空列表；`tunnels[]` 每条含 `tunnel_domain`（带 `https://` 前缀）、`port`、`created_at`；**0.6.8 起每条另含 `shz_name`/`shz_url`**（shz.al 上报绑定信息，未绑定为 null）。
- `tunnel-create` 缺省 `--port` 时用 agent 自身监听端口；同端口已有隧道默认拒绝（409），须显式加 `--duplicate` 才强制再建一条。成功返回的 `tunnel_domain` 即对外可访问的公网地址。**0.6.8 起可加 `--shz` / `--shz-name X` / `--shz-key X`** 在创建后立即绑定 shz.al 上报（详见下方「绑定上报」）。
- `tunnel-delete` 的 `--port` 必填；端口无隧道返回 404；同端口存在多条隧道时必须带 `--tunnel-domain` 精确定位（否则 409 防误删）。删除后该公网域名立即失效。**0.6.8 起删除带绑定的隧道会自动清持久化条目并后台删除远端 shz.al 记录**（响应 `tunnels[]` 携带删除前的 `shz_name`/`shz_url` 供复核）。
- 该路由仅在代理端 **py/js/java 版本且版本 ≥ 0.4.5** 时提供；先 `baseinfo` 确认 `version`，版本过低或不支持会报错。
- 实测代理端偶发返回空响应体的 `HTTP 503`（无 `message`），间隔几秒重试即可，非客户端问题。

#### 隧道绑定 shz.al 上报（0.6.8 起，py/js/java/java11）

把已启动的临时隧道（或创建时直接绑定）关联上报到 shz.al，得到**可预测的固定地址** `https://shz.al/~上报名`（控制端读该页即得最新隧道域名，隧道换域名/重启后 agent 自动覆盖更新）：

```bash
<PY> scripts/kisama_control.py ... tunnel-bind --port 8080                              # 绑定 (上报名缺省派生 KNAME-端口, 密钥派生 上报名+"123")
<PY> scripts/kisama_control.py ... tunnel-bind --port 8080 --shz-name myapp --shz-key mysecret-key   # 显式指定上报名与密钥
<PY> scripts/kisama_control.py ... tunnel-bind --port 8080 --tunnel-domain '域名'       # 同端口多隧道时精确定位
<PY> scripts/kisama_control.py ... tunnel-unbind --port 8080                            # 解绑 (保留隧道, 远端记录后台删除)
```

- **绑定方式**：`tunnel-create --shz`（或 `--shz-name/--shz-key`）创建即绑定；`tunnel-bind` 给已启动隧道事后绑定。绑定信息经 `tunnel-list` 可查（`shz_name`/`shz_url`）；**管理密钥不随响应下发**。
- **派生规则**：上报名缺省 = `KNAME-端口`（节点名取 agent 的 KNAME 环境变量）；管理密钥缺省 = 上报名 + `"123"`。显式 `--shz-name`（≥3 字符）覆盖上报名（不再拼端口）、显式 `--shz-key`（≥8 字符，shz.al 平台约束）覆盖密钥。
- **错误码**：校验失败（KNAME 未设置/过短、名称非法字符、密钥 <8 字符）400；端口无隧道/无匹配域名 404；同端口多隧道未指定、KMODE 自建隧道（不可绑定）、端口已被其他隧道绑定均 409。
- **持久化**：agent 侧 `KSTORE_KEY` 启用时绑定落盘 `data.argobinds`，agent 重启自动重建隧道并按持久化名称重新上报——**上报地址分毫不差**（trycloudflare 随机域名变化由 agent 的 409→PUT 覆盖机制吸收）。
- **KMODE 隔离**：KMODE=1/2 启动自建的隧道不可绑定（409 `managed by KMODE`），也不进持久化——其上报由 KMODE 配置管理，避免两个位置管理同一隧道。

### 本地端口反代与端口白名单（0.6.7 起，py/js/java/java11；续批六起白名单分两组）

经 agent 自身的反代路由访问**代理所在主机** `127.0.0.1:{port}` 上的 HTTP 服务（不注册 hub 也可用），或动态管理反代端口白名单。**0.6.7 续批六起白名单拆为两组、各管各的**：HUB 组（env `KHUB_PORTS` ∪ hub 运行时，只约束 hub 中继 `/{KNAME}/{PORT}/*`，由 hub 注册端口并入与 `proxy-config-set --scope hub` 管理）与**本地组**（env `KPROXY_PORTS` ∪ 本地运行时，只约束本节 `proxy` 路由）；两组互不影响：

```bash
<PY> scripts/kisama_control.py ... proxy --port 8080 [--path 'api/status?x=1'] [--method POST] [--header 'Content-Type: application/json'] [--data '...'| --data-file 本地文件] [--out 本地文件]
<PY> scripts/kisama_control.py ... proxy-config                        # 查看两组快照 (hub/local 各自 env/runtime/effective)
<PY> scripts/kisama_control.py ... proxy-config-set --ports '8080,9090'              # 整体覆盖本地组运行时白名单 (缺省 --scope local)
<PY> scripts/kisama_control.py ... proxy-config-set --ports '7788' --scope hub       # 整体覆盖 HUB 组运行时白名单 (hub 中继端口反代)
<PY> scripts/kisama_control.py ... proxy-config-clear                  # 清两组运行时列表回落组 env
<PY> scripts/kisama_control.py ... proxy-config-clear --scope hub      # 只清 HUB 组 (本地组不动)
```

- **门禁模型**：`proxy` 是匿名+白名单路由（白名单唯一门禁，不验签）——`--port` 必须在**本地组**白名单内（env `KPROXY_PORTS` ∪ 本地运行时列表）；`proxy-config*` 三条是管理端点，**走验签**（生产模式需密钥齐全，与 exec 同档）。
- **错误映射**（`code`/`message` 直接出现在输出顶层，`upstream_status` 为真实状态码）：白名单外 403 `port_not_allowed`（agent 拒绝且不发起连接）、非法端口 404 `invalid_port`、请求体超限 413 `body_too_large`、上游未监听 502 `loopback_unreachable`。这些是反代语义内的正常答复（输出 `ok: false`，**退出码仍为 0**），不是脚本报错；据此判断放行状态后可用 `proxy-config-set` 临时放行端口。
- **响应保真**：`proxy` 不发认证头、响应原样透传（上游响应不会被 AES 包装，无 `x-encrypted` 头）——文本响应内联在 `body`（超 64KiB 截断并标 `body_truncated`），二进制给 `body_base64`（超限 `body_omitted` 提示改用 `--out`）；`--out` 落盘完整原始字节并附 sha256 对账。**取大文件/二进制一律 `--out`**，不要靠内联输出。
- **白名单语义（续批六分组口径）**：各组 `effective = 组 env ∪ 组 runtime`（本地组 env 为 `KPROXY_PORTS`，HUB 组 env 为 `KHUB_PORTS`）；`proxy-config-set` 是**整体覆盖所选组**的运行时列表（只动该组 runtime 部分，组 env 下限不变；收紧/恢复用 `proxy-config-clear`，不带 `--scope` 清两组）；KSTORE 启用时持久化、重启恢复（响应 `persisted` 可见）；即时生效，下一条 `proxy` 即按新白名单判定。POST 非法 scope → 422 `invalid_scope`。
- **版本兼容**：需代理 **≥ 0.6.7** 且为 py/js/java/java11（go 端无此特性，404）；先 `baseinfo` 确认 `version`。`--scope` 分组需代理端为 0.6.7 续批六及以上（旧 0.6.7 早期构建为单一白名单，`--scope hub` 会报 422 `invalid_scope`）。`--method` 支持 GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS；浏览器 WS 应用直达（同路径 upgrade）与 `/api/proxyws` WS 透传不在本技能范围——`proxy` 只做 HTTP 透传。
- 典型用途：探活/取回本机服务响应（`proxy --port 8080 --path health`）、经反代下载本机服务产物（`--out`）、临时放行一个端口给面板/浏览器用（`proxy-config-set`）、调整 hub 中继可达端口（`proxy-config-set --scope hub`，注册后可随时改，无需重新注册）。

### 任务管理（onetime 启动任务 / cron 定时任务）

管理代理端随生命周期自动执行的任务：onetime（启动任务，agent 生命周期内执行一次）、cron（定时任务，按 cron 表达式循环执行）。执行结果落在环形日志可回查：

```text
task-status                          模块状态 (onetime 待执行数/是否已执行, cron 是否在调度/条数)
task-get --type onetime|cron         查看任务表
task-set --type onetime 'cmd1' 'cmd2' ...   设置启动任务 (JSON 数组)
task-set --type cron 'EXPR=CMD' ...         设置定时任务 (首个 = 切分)
task-exec                            手动强制重跑全部已配置启动任务
task-log --type onetime|cron [--limit N]    查询执行日志 (环形缓冲, 缺省/最大 100 条)
task-log-clear --type onetime|cron   清空对应日志 (不可逆)
task-log-summary                     日志统计 (数量/容量/近期成功失败数)
```

```bash
<PY> scripts/kisama_control.py ... task-set --type onetime 'echo hello' 'date'
<PY> scripts/kisama_control.py ... task-set --type cron '*/5 * * * *=echo heartbeat' '0 2 * * *=/opt/scripts/backup.sh'
<PY> scripts/kisama_control.py ... task-log --type cron --limit 50
```

- ⚠️ **`task-set` 是整表替换**：本次请求未包含的存量任务即被删除（cron 新表为空时自动停止调度循环）。改表前先 `task-get --type` 看现状，替换时把要保留的任务一并写上；**删除任务的方式就是"提交一张不含它的表"**。
- ⚠️ **onetime 设置即执行（首次）**：POST `/api/task/onetime` 设置后 agent 立即执行并把结果带回 `executed` 数组；0.5.7 起 agent 启动时自动恢复并执行持久化任务（单次执行语义）——boot 已执行过的话，再次 `task-set` 只更新表不再自动执行，`task-exec` 是**显式强制重跑的唯一入口**（不受状态限制，结果写入启动任务日志环）。命令里放破坏性操作前先向用户确认。
- **任务身份元数据行（0.6.2 起，透明）**：agent 给每条任务脚本首行自动盖 `kisama-task: id=<ms> updated=<ms>` 注释（Unix `#` / Windows `rem` 语法，对 shell 执行零副作用），`task-get` 回显与 `task-set` 响应的 `tasks` 会带这行，属正常现象；响应回显是规范化后的表，以回显为准。
- **`--limit` 封顶 100**：日志环容量即 100 条（`task-log-summary` 的 `max_capacity` 可见），超出部分已被丢弃，要完整留档用 `exec` 重定向到文件再 `download`。
- 版本兼容：任务管理接口各端全版本可用；响应里的 `persisted` / `persistence` 字段需代理 ≥ 0.5.7（KSTORE 任务持久化），旧版代理只是缺该字段，命令行为不受影响。
- cron 表达式含 `*` 和空格，**必须整体引号包裹**；`EXPR=CMD` 按首个 `=` 切分，命令内含 `=`（如 `export A=1`）不受影响。

## 4. 复用会话

CLI 每次新进程。连续多步可加 `--session-cache` 跨命令复用（缓存文件路径按控制端平台写，Windows 如 `C:\Users\me\kisama_session.json`，Linux 如 `/tmp/kisama_session.json`）：

```bash
<PY> scripts/kisama_control.py ... --session-cache '缓存路径' baseinfo
<PY> scripts/kisama_control.py ... --session-cache '缓存路径' exec --cmd 'uname -a'
```

缓存自动 0600（Windows 上无 POSIX 权限位，仅尽力设置），与目标代理绑定，代理重启后脚本自动重取。也可在 Python 中 `from kisama_control import KisamaClient` 复用连接。

## 5. 帮助

```bash
<PY> scripts/kisama_control.py --help
<PY> scripts/kisama_control.py terminal --help
```

报错排查顺序见 `docs/troubleshooting.md`。