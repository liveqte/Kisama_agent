---
name: kisama-control
description: 通过 Kisama Agent 对已部署代理执行系统命令、文件管理、文件传输和交互式终端操作。用户要求连接、控制、运维、执行命令或上传文件到 Kisama Agent 时使用。
compatibility: 需要网络可达 Kisama Agent、控制端 ECDSA 私钥与 ECIES 私钥，以及 Python 依赖。
metadata:
  author: elfinpeak.zo.computer
---

# Kisama Agent 控制技能（操作手册）

本技能只调用本目录 `scripts/kisama_control.py` 一个脚本，不读仓库其他文档。密码学与协议已封装在脚本内，直接给参数、选子命令、读 JSON 结果即可。

只覆盖这些接口：`baseinfo`、`exec`、文件管理（list/cat/mkdir/move/copy/delete/authority/upload/download）、`terminal`。

## 1. 安装（一次性，venv 内）

以下 `<PY>` 表示 venv 内 Python：**Linux/macOS** 为 `/tmp/venv/bin/python`，**Windows** 为 `venv\Scripts\python.exe`（以实际创建路径为准）。先确认本机命令：Linux 用 `python3`，Windows 用 `python` 或 `py -3`。

Linux/macOS：

```bash
python3 -m venv /tmp/venv
/tmp/venv/bin/python -m pip install -r scripts/requirements.txt
/tmp/venv/bin/python -c "import ecdsa, Crypto, ecies, coincurve, noise, websockets; print('all deps OK')"
```

Windows（PowerShell，venv 建在技能目录下）：

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r scripts\requirements.txt
.venv\Scripts\python.exe -c "import ecdsa, Crypto, ecies, coincurve, noise, websockets; print('all deps OK')"
```

- Python 3.14 的 coincurve 编译补丁 `scripts/install_coincurve_py314.sh` 是 **bash 脚本，仅 Linux/macOS 可用**；Windows 上 Python 3.14 需用 MSVC 编译工具，建议改用 Python 3.13 或 3.12（有官方 wheel）。
- 报错见 `docs/install.md`。

## 2. 连接参数

每条命令都带这三个参数（或对应环境变量 `KISAMA_URL`/`KISAMA_ECDSA_KEY`/`KISAMA_ECIES_KEY`）：

| 参数 | 内容 |
| --- | --- |
| `--url` | 代理地址，逐字复制用户给的 `scheme://主机[:端口]`，不加 `/api`、不加尾随 `/` |
| `--ecdsa-key` | ECDSA P-256 私钥 PEM 文件路径或内容 |
| `--ecies-key` | ECIES secp256k1 私钥，64 位 hex 或 Base64(32字节) |

签名时间戳自动与服务器时钟对齐，无需手动设置。密钥不要写进仓库或聊天消息。

**路径规则（平台差异关键）**：`--url`、`--ecdsa-key`、`--ecies-key`、`--local`、`--session-cache` 都是**控制端本机**的路径/参数，按控制端平台写法（Windows 用 `C:\...` 或 `.\...`，Linux 用 `/...`）；`exec` 的 `--cmd`、`--cwd` 与文件接口的 `--path`/`--remote-path` 是**代理端 Linux** 上执行的命令和路径，永远用 Linux 风格（`/home/...`、`uname -a`）。混写会导致文件找不到或命令失败。

## 3. 操作命令

### 连接预检（每次先做）

```bash
<PY> scripts/kisama_control.py --url URL --ecdsa-key KEY --ecies-key KEY baseinfo
```

通过标准：`"status": "ok"` 且含 `version`、`os` 等字段。输出中 `session_key`/`noise_key` 已自动脱敏。**`version` 包含 `php` 时，禁止用 `terminal`，一律改用 `exec`。**

### 执行命令

```bash
<PY> scripts/kisama_control.py ... exec --cmd 'uname -a' --cwd '/tmp'
```

> **Windows cmd.exe 注意**：cmd 不识别单引号。在 cmd 下命令参数用双引号包裹（含空格时）：`exec --cmd "uname -a"`；PowerShell 与 bash 单双引号都可以。含 `$`、`"`、`\` 的复杂命令建议避免手写转义，改用下面的提示方式或直接复制用户提供的原文。

判读：`exitcode == 0` 才算成功；`result` 是输出（混 stdout/stderr，可空）。默认超时 30 秒，`--timeout` 可调。破坏性命令（rm、格式化、重启）执行前先确认。

### 文件操作

```text
list [--path PATH] [--recursive]     查看目录列表
cat --path PATH                      读取文本文件
authority-get PATH [PATH ...]        查询权限
authority-set PATH=MODE [..] [--recursive]   改权限（用户明确要求才做）
mkdir --path PATH                    创建目录（递归）
move FROM=TO [..] / copy FROM=TO [..] 移动/复制
delete PATH [PATH ...]               递归删除（不可逆，先 list 确认）
```

路径以代理端 `FILE_ROOT` 为基准，不是控制端目录；不要用 `..` 穿越。推荐顺序：`list` 父目录 → `authority-get` → 操作 → 再 `list`/`cat` 验证。**删除、覆盖、移动、改权限前必须先向用户确认。**

### 上传 / 下载

本地路径按控制端平台写（Windows 如 `C:\Users\me\package.tar.gz`，Linux 如 `/home/me/package.tar.gz`）；远端路径永远 Linux 风格：

```bash
<PY> scripts/kisama_control.py ... upload --local '本地路径' --remote-path '/tmp/uploads' [--name 改名]
<PY> scripts/kisama_control.py ... download --remote-path '/tmp/result.tar.gz' --local '本地路径'
```

上传自动裸二进制分片，完成后用 `list` 或远端 `exec` 校验大小。

### 超级终端（真实 TTY）

```bash
<PY> scripts/kisama_control.py ... terminal --command 'uname -a'    # 或 --input 发送原始输入
```

需真实 TTY、交互式程序、持续会话时用（`top`/`vim`/`sudo`）；普通一次命令优先 `exec`。**先确认 `baseinfo.version` 不含 `php`。** 协议细节见 `docs/terminal.md`。

## 4. 复用会话

CLI 每次新进程。连续多步可加 `--session-cache` 跨命令复用（缓存文件路径按控制端平台写，Windows 如 `C:\Users\me\kisama_session.json`，Linux 如 `/tmp/kisama_session.json`）：

```bash
<PY> scripts/kisama_control.py ... --session-cache '缓存路径' baseinfo
<PY> scripts/kisama_control.py ... --session-cache '缓存路径' exec --cmd 'uname -a'
```

缓存自动 0600（Windows 上无 POSIX 权限位，仅尽力设置），与目标代理绑定，代理重启后脚本自动重取。也可在 Python 中 `from kisama_control import KisamaClient` 复用连接。

## 5. 帮助

```bash
<PY> scripts/kisama_control.py --help
<PY> scripts/kisama_control.py terminal --help
```

报错排查顺序见 `docs/troubleshooting.md`。